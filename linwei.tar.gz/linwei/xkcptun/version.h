#ifndef	_VERSION_
#define	_VERSION_

#define	VERSION		"0.03"

#endif
