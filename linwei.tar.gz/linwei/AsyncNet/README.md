AsyncNet
========

AsyncNet


Build
=====

```bash
# git clone https://github.com/skywind3000/AsyncNet.git AsyncNet
# cd AsyncNet
# python tools/emake.py build/AsyncNet.mak
```

Demo
====

```bash
python AsyncNet.py
```

check test_async_core() and test_async_notify() in AsyncNet.py for more.

C/C++ Library
===========

use tools/AsyncLoader.h tools/AsyncLoader.c in your code.



