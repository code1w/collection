# gobang

Gobang game with artificial intelligence in 900 Lines !! 

How to play
===========

Download：
> git clone https://github.com/skywind3000/gobang.git gobang

play in normal mode：
> python gobang/gobang.py 

play in hard mode：
> python gobang/gobang.py hard 


Game Rule
=========

Make five or more stones in a in to win. You will make your move by enter the coordinate value (row + column) of the chess-board to defeat the AI competitor.

Play it in the console:

![](https://raw.githubusercontent.com/skywind3000/gobang/master/images/gobang1.png)

Character 'O' - black stone (you)
Character 'X' - white stone (computer)

if you want to make a new move below the white stone 'X', just enter 'JI' (row is 'J', and column is 'I'):

![](https://raw.githubusercontent.com/skywind3000/gobang/master/images/gobang3.png)

After entering 'JI' the computer will think for a few seconds and makes its move too. Then another turn begins, you can input new row-col values to continue playing until someone wins. 









