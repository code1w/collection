#! /bin/sh
./emake.py testmain.c
