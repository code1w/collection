#ifndef __TESTSRC1_H__
#define __TESTSRC1_H__

void foo(void);


#endif


