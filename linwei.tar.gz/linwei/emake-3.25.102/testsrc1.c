#include <stdio.h>
#include "testsrc1.h"

void foo(void)
{
	printf("This is foo\n");
}


