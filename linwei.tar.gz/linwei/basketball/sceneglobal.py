import copy

class SceneGlobal():
    basket1_pos,basket2_pos = [0,0,0],[0,0,0]
    scene_w,scene_h = 0,0
    gravity = -15.0
    fps = 35


sceneParam = SceneGlobal()
