# -*- coding:gb2312 -*-

'''This module defines basketball player class'''
import random
import copy
import animationsprite
import attacksprite
import AI.player


import sys,pygame
import math
import mybasesprite
import ballsprite
import teamsprite
import AI.ai
import basketsprite
import time
import goalscenesprite
import effect
import configp


#index of animation_list
UP_I,DOWN_I,LEFT_I,RIGHT_I = 0,1,2,3
WIN_I,LOSE_I = 0,1

#Enumeration of the internal status of player
FAINT = 0
CONTROL_BALL = 1
NO_BALL = 2
PASSING = 3
SHOOTING = 4
DUNKING = 5


comment_random = [u"%sҪ�����ˣ������Ҫ�����ˣ����Ǿ��˵ĵ�����",
                  u"%s���������������ۣ�����",
                  u"%s�߸�Ծ�������һ�δ�糵������",
                  u"%s���ֿ۽���ɫ����ο�������������չ",
                  u"%s���򱩿ۿ϶��ܽ�����ʮ����"]

class PlayerSprite(mybasesprite.MyBaseSprite):
    '''Basketball Player sprite'''
    #dictionary for convert face orientation to animation orientation
    __convert_lr_dic = {    -1  :   LEFT_I,
                            0   :   -1,
                            1   :   RIGHT_I
                        }
    __convert_ud_dic = {    -1  :   UP_I,
                            0   :   -1,
                            1   :   DOWN_I
                        }
    def __convert(self,orient):
        lr = self.__convert_lr_dic[orient[0]]
        if lr != -1:
            return lr
        else:
            return self.__convert_ud_dic[orient[1]]

    def __init__(self,id,team_id,name,dict,scene,xyz,ani_run,ani_stand,ani_shoot,ani_ending,
                 attack_ani,ani_shadow,type=mybasesprite.ObjType.PlayerSprite):
        '''Construction'''
        lwh = [float(dict['player']['player_length']),
               float(dict['player']['player_width']),
               float(dict['player']['player_height'])
              ]
        #id of team
        self.team_id = team_id
        #id of player
        self.__id = id
        #name of player
        self.name = name
        #animation list of player' running action.
        self.__ani_run = ani_run
        #animation list of player' standing action.
        self.__ani_stand = ani_stand
        #animation list of player' shooting action.
        self.__ani_shoot = ani_shoot
        #animation list of player' ending action.
        self.__ani_ending = ani_ending
        #shadow animation
        self.__ani_shadow = ani_shadow
        self.__ani_shadow.play()
        #attack special animation
        self.__attack_ani = attack_ani[0]
        self.__attack_ani_left = attack_ani[1]
        self.__attack_ani_right = attack_ani[2]
        #current animation
        self.__cur_ani = ani_stand[DOWN_I]
        self.__cur_ani.play()
        #current index of animation
        self.__cur_index = 1
        #effect for showing id
        self.__id_effect = None
        #effect for showing status
        self.__state_effect = None
        self.__state_effect_count_down = 0
        #status to be written
        self.__state_to_write = ''
        #if it have moved in last frame, it will be True
        self.__have_moved = False
        #refernece to the ball
        self.__ball = scene.get_ball()
        #coordinate of baskets
        baskets = scene.get_baskets()
        self.__baskets_pos = [baskets[0].get_center_xyz(),baskets[1].get_center_xyz()]
        #player's internal status
        self.__internal_state = NO_BALL
        #face orientation
        self.__face_orientation = [0,1]
        #faint time
        self.__faint_time = int(dict['player']['faint_time'])
        #faint count down
        self.__faint_count_down = 0
        #speed of player
        self.__normal_speed = float(dict['player']['normal_speed'])
        self.__run_speed = float(dict['player']['run_speed'])
        self.__drible_speed = float(dict['player']['drible_speed'])
        self.__speed = self.__normal_speed
        self.__run_interval = int(dict['player']['run_interval'])
        self.__run_time = int(dict['player']['run_time'])
        #speed of dunking
        self.__dunk_speed = float(dict['player']['dunk_speed'])
        self.__dunk_step = [0,0,0]
        #orientation of dunk
        self.__dunk_orient = [0,0,0]
        #target basket position
        self.__target_basket_pos = []
        #target dunk position
        self.__target_dunk_pos = []
        #min and max of pass ball speed
        self.__pass_speed = [float(dict['player']['min_pass_speed']),
                             float(dict['player']['max_pass_speed'])
                            ]
        #maximum pass count
        self.__max_pass_count = int(dict['player']['max_pass_count'])
        #attack length, width, height
        self.__attack_lwh = [float(dict['player']['attack_length']),
                             float(dict['player']['attack_width']),
                             float(dict['player']['attack_height']),
                            ]
        #probability in successful attack
        self.__attack_probability = float(dict['player']['attack_probability'])
        #probability in being attacked
        self.__be_attacked_probability = float(dict['player']['be_attacked_probability'])
        #v for jumping
        self.__jump_v = 0.0
        #initial jumping v
        self.__init_jump_v = float(dict['player']['init_jump_v'])
        #hit rate of the player
        self.__hit_rate = 1.0
        #is the player pick the ball in last frame,0 means no, 1 means in this frame,
        #2 means in last frame
        self.__pick_ball_just_now = 0
        #when the variable larger than 0, player can not pick the ball
        self.__can_pick_countdown = -1
        #if it is False, it is controlled by computer
        self.is_human_control = False
        #whether it is in the state of speeding-up
        self.is_speed_up = False
        #time it can last
        self.speed_up_time = 0
        #interval of speeding-up action
        self.speed_up_interval = 0
     
        crash_type_list = [mybasesprite.ObjType.BallSprite, mybasesprite.ObjType.AttackSprite]
        mybasesprite.MyBaseSprite.__init__(self,scene,xyz,lwh,type,crash_type_list)
        self.make_id_effect()
        self.make_state_effect()

    def set_const_attrib(self,strategy):
        self.__normal_speed = strategy.normal_speed
        self.__run_speed = strategy.run_speed
        self.__drible_speed = strategy.drible_speed
        self.__attack_probability = strategy.attack_probability
        self.__hit_rate = strategy.hit_rate
        self.__be_attacked_probability = strategy.be_attacked_probability

    def get_const_attrib(self):
        const_attrib = AI.player.PlayerConstAttrib()
        const_attrib.lwh = copy.copy(self.get_lwh())
        const_attrib.faint_time = self.__faint_time
        const_attrib.dunk_speed = self.__dunk_speed
        const_attrib.pass_speed = copy.copy(self.__pass_speed)
        const_attrib.max_pass_count = self.__max_pass_count
        const_attrib.attack_lwh = copy.copy(self.__attack_lwh)
        const_attrib.init_jump_v = self.__init_jump_v
        return const_attrib
    
    def get_attrib(self):
        attrib = AI.player.PlayerAttrib()
        attrib.id = self.__id
        attrib.xyz = copy.copy(self.xyz)
        attrib.internal_status = self.__internal_state
        attrib.speed = self.__speed
        have_ball_set = [CONTROL_BALL,PASSING,SHOOTING,DUNKING]
        if self.__internal_state in have_ball_set:
            attrib.have_ball = True
        else:
            attrib.have_ball = False
        attrib.face_orient = copy.copy(self.__face_orientation)
        attrib.faint_count_down = self.__faint_count_down
        attrib.dunk_step = copy.copy(self.__dunk_step)
        attrib.dunk_orient = copy.copy(self.__dunk_orient)
        attrib.target_basket_pos = copy.copy(self.__target_basket_pos)
        attrib.target_dunk_pos = copy.copy(self.__target_dunk_pos)
        attrib.jump_v = self.__jump_v
        attrib.can_pick_countdown = self.__can_pick_countdown
        attrib.is_human_control = self.is_human_control
        return attrib

    def make_id_effect(self):
        t = self.translate(self.xyz)
        t[0] -= 15
        t[1] -= 45
        self.__id_effect = effect.Effect(self.get_scene(), t, "word")
        self.__id_effect.set_font_size(12,False)
        if self.team_id == 10:
            self.__id_effect.set_col([255,229,18])
        else:
            self.__id_effect.set_col([18,229,255])
        self.__id_effect.write(self.name)#write("No.%d" %(self.__id + 1))
    
    def make_state_effect(self):
        t = self.translate(self.xyz)
        t[0] += 30
        t[1] -= 50
        self.__state_effect = effect.Effect(self.get_scene(), t, "dialog")
        self.__state_to_write = ''
        self.__state_effect.write(self.__state_to_write)
        self.__state_effect_count_down = 0
    
    def set_state_effect(self,to_be_written,frame_count=20):
        self.__state_to_write = to_be_written
        self.__state_effect.write(self.__state_to_write)
        self.__state_effect_count_down = frame_count

    def update_state_effect(self):
        if self.__state_effect_count_down <= 0:
            self.__state_to_write = ''
            self.__state_effect.write('')
        elif self.__state_to_write != '':
            t = self.translate(self.xyz)
            t[0] += 30
            t[1] -= 50
            self.__state_effect.set_pos(t)
            self.__state_effect.update()
            self.__state_effect_count_down -= 1
    
    def render_state_effect(self):
        if self.__state_effect_count_down > 0 and self.__state_to_write != '':
            self.__state_effect.render()

    def get_id(self):
        return self.__id

    def __check_if_cango(self):
        if self.status != mybasesprite.ObjStatus.Active:
            return False
        else:
            return True

    def move(self,direction):
        '''move player. direction is a status tuple'''
        if not self.__check_if_cango(): return
        if self.__internal_state != CONTROL_BALL and\
           self.__internal_state != PASSING and\
           self.__internal_state != NO_BALL:
            return
        if self.xyz[2] != self.get_lwh()[2] / 2.0:
            return
        self.__have_moved = True
        #update orientation status
        tmp_face_orientation = [(direction[mybasesprite.LEFT_I] == 1) and -1 or direction[mybasesprite.RIGHT_I],
                                (direction[mybasesprite.UP_I] == 1) and -1 or direction[mybasesprite.DOWN_I]]
        if self.__face_orientation != tmp_face_orientation or\
            (self.__face_orientation == tmp_face_orientation and self.__cur_ani not in self.__ani_run):
            #update current animation
            index = self.__convert(tmp_face_orientation)
            if index == -1:
                #standing, its face orientation should not be changed
                self.__cur_ani = self.__ani_stand[self.__cur_index]
            else:
                #running
                self.__cur_index = index
                self.__cur_ani = self.__ani_run[self.__cur_index]
            self.__cur_ani.play()
        self.__face_orientation = tmp_face_orientation
        #move this object
        if self.__face_orientation[0] != 0 and self.__face_orientation[1] != 0:
            self.xyz[0] += self.__face_orientation[0] * self.__speed / math.sqrt(2.0)
            self.xyz[1] += self.__face_orientation[1] * self.__speed / math.sqrt(2.0)
        else:
            self.xyz[0] += self.__face_orientation[0] * float(self.__speed)
            self.xyz[1] += self.__face_orientation[1] * float(self.__speed)
        halfL = self.get_lwh()[0] / 2
        halfW = self.get_lwh()[1] / 2
        screenW,screenH = self.get_scene().get_scene_wh()
        if self.xyz[0] < halfL:  self.xyz[0] = halfL
        if self.xyz[0] > screenW - halfL:   self.xyz[0] = screenW - halfL
        if self.xyz[1] < halfW:  self.xyz[1] = halfW
        if self.xyz[1] > screenH - halfW:    self.xyz[1] = screenH - halfW

    def jump(self):
        if not self.__check_if_cango(): return
        if self.__internal_state != NO_BALL: return
        if self.xyz[2] != self.get_lwh()[2] / 2.0: return
        self.__cur_ani = self.__ani_shoot[self.__cur_index]
        self.__cur_ani.play()
        self.__jump_v = self.__init_jump_v + 3

    def abandom_ball(self):
        '''give up controling the ball'''
        self.__internal_state = NO_BALL

    def stop_pick_ball_momently(self,pick_time=5):
        '''stop player from picking the ball momently'''
        self.__can_pick_countdown = pick_time

    def get_max_pass_count(self):
        return self.__max_pass_count

    def __set_ball_pos_with_player(self):
        if self.__face_orientation[0] == 0:
            orient = self.__face_orientation
        else:
            orient = [self.__face_orientation[0],0]
        half_l = self.get_lwh()[0] / 2.0
        half_w = self.get_lwh()[1] / 2.0
        half_h = self.get_lwh()[2] / 2.0
        half_ball_l = self.__ball.get_lwh()[0] / 2.0
        half_ball_w = self.__ball.get_lwh()[1] / 2.0
        scene_l,scene_w = self.get_scene().get_scene_wh()

        ball_x = self.xyz[0] + orient[0] * half_l
        if ball_x < half_ball_l:
            ball_x = half_ball_l
        elif ball_x > scene_l - half_ball_l:
            ball_x = scene_l - half_ball_l
        ball_y = self.xyz[1] + orient[1] * half_w
        if ball_y < half_ball_w:
            ball_y = half_ball_w
        elif ball_y > scene_w - half_ball_w:
            ball_y = scene_w - half_ball_w
        ball_z = self.xyz[2]
        self.__ball.set_xyz([ball_x,ball_y,ball_z])

    def pre_pass_ball(self):
        '''call it when pass ball action begin'''
        if not self.__check_if_cango(): return
        if self.__internal_state != CONTROL_BALL: return
        self.__internal_state = PASSING
        self.get_scene().add_sound(mybasesprite.ObjSound.PassBall,0)

    def pass_ball(self,dest_player,pass_count):
        '''pass the ball to dest_player'''
        if not self.__check_if_cango(): return
        if self.__internal_state != PASSING: return
        dx = dest_player.xyz[0] - self.xyz[0]
        dy = dest_player.xyz[1] - self.xyz[1]
        if random.random() < 0.4 and math.sqrt(dx * dx + dy * dy) < self.get_scene().get_scene_wh()[0] / 3.0:
            #bounce pass
            v = -30 + self.__pass_speed[0] + (self.__pass_speed[1] - self.__pass_speed[0]) * pass_count / self.__max_pass_count
            t = math.sqrt(dx * dx + dy * dy) / v / 2 
            speed_z = (self.xyz[2] + 0.5 * self.__ball.gravity * t * t) / t
        else:
            #pass in the air
            v = self.__pass_speed[0] + (self.__pass_speed[1] - self.__pass_speed[0]) * pass_count / self.__max_pass_count
            t = math.sqrt(dx * dx + dy * dy) / v
            speed_z = -0.5 * self.__ball.gravity * t
        self.__ball.tar_player = dest_player
        self.__ball.set_speed([dx / t, dy / t, speed_z], False, "pass")
        self.__internal_state = NO_BALL
        self.stop_pick_ball_momently()

    def pre_shoot(self):
        '''call it when shoot ball action begin'''
        if not self.__check_if_cango(): return
        if self.__internal_state != CONTROL_BALL: return
        self.__cur_ani = self.__ani_shoot[self.__cur_index]
        self.__cur_ani.play()
        if self.xyz[2] <= self.get_lwh()[2] / 2.0:
            self.__jump_v = self.__init_jump_v
        self.__internal_state = SHOOTING

    def __get_signal(self,x):
        if x > 0:
            return 1
        elif x < 0:
            return -1
        else:
            return 0
        
    def __bad_shoot_basket_pos(self):
        [len, width] = self.get_scene().get_scene_wh()
        if self.__face_orientation[0] > 0:
            x = len
        elif self.__face_orientation[0] < 0:
            x = 0
        else:
            x = self.xyz[0]
        if self.__face_orientation[1] > 0:
            y = width
        elif self.__face_orientation[1] < 0:
            y = 0
        else:
            y = self.xyz[1]
        return [x,y,self.__baskets_pos[0][2]]
    
    def posible_to_shoot(self):
        if self.is_mishit():
            return False
        elif self.in_back_of_basket():
            return False
        else:
            return True
    
    def is_mishit(self):
        [l, w] = self.get_scene().get_scene_wh()
        valid_ratio_x = 0.9
        valid_ratio_y = 0.8
        face_orient_0 = self.__face_orientation[0]
        if (self.xyz[0] < l * (1.0 - valid_ratio_x) and self.__face_orientation[0] < 0 and (self.xyz[1] < w * (1.0 - valid_ratio_y) or self.xyz[1] > w * valid_ratio_y)) or\
            (self.xyz[0] > l * valid_ratio_x and self.__face_orientation[0] > 0 and (self.xyz[1] < w * (1.0 - valid_ratio_y) or self.xyz[1] > w * valid_ratio_y)):
            face_orient_0 = 0
        if self.__face_orientation[1] * (self.xyz[1] - w / 2.0) >= 0 and face_orient_0 == 0:
            return True
        else:
            return False
    
    def in_back_of_basket(self):
        [l, w] = self.get_scene().get_scene_wh()
        valid_ratio_back_y = 0.7
        if (self.xyz[0] < self.__baskets_pos[0][0] or self.xyz[0] > self.__baskets_pos[1][0]) and\
           self.xyz[1] > w * (1.0 - valid_ratio_back_y) and self.xyz[1] < w * valid_ratio_back_y:
            return True
        else:
            return False

    def shoot(self,is_dunk=False):
        '''shoot the ball'''
        if not self.__check_if_cango(): return
        if self.__internal_state != SHOOTING and self.__internal_state != DUNKING:
            return

        if self.__jump_v > 0:
            ratio = (self.__init_jump_v - self.__jump_v) * self.__hit_rate / self.__init_jump_v
        else:
            ratio = (self.__init_jump_v + self.__jump_v) * self.__hit_rate / self.__init_jump_v
        if self.xyz[2] == self.get_lwh()[2] / 2.0:
            ratio = 0
        if ratio < 0:ratio *= -1.0

        [l, w] = self.get_scene().get_scene_wh()
        if self.posible_to_shoot():
            goal = True
        else:
            goal = False
        if self.is_mishit():
            basket = self.__bad_shoot_basket_pos()
        else:
            if self.__face_orientation[0] > 0:
                if self.xyz[0] <= self.__baskets_pos[0][0]:
                    basket = self.__baskets_pos[0]
                else:
                    basket = self.__baskets_pos[1]
            elif self.__face_orientation[0] < 0:
                if self.xyz[0] >= self.__baskets_pos[1][0]:
                    basket = self.__baskets_pos[1]
                else:
                    basket = self.__baskets_pos[0]
            elif self.xyz[0] < l / 2.0:
                basket = self.__baskets_pos[0]
            else:
                basket = self.__baskets_pos[1]
                
        #whether the ball will goal or not, depended on the distance between the player and the basket
        dist_x = basket[0] - self.xyz[0]
        dist_y = basket[1] - self.xyz[1]
        dist_z = basket[2] - self.xyz[2]

        d = math.sqrt(dist_x * dist_x + dist_y * dist_y)
        mlen = math.sqrt(l * l + w * w / 4.0)
        if goal:
            #check if player will dunk
            if self.__internal_state == SHOOTING:
                dist = math.sqrt(dist_x * dist_x +\
                                 dist_y * dist_y +\
                                 dist_z * dist_z
                                )
                if math.fabs(self.__jump_v) <= self.__init_jump_v * 0.3 and dist <= 115:
                    #he is dunking
                    #self.__ball.have_goal_defend = True
                    #self.__ball.have_goal_attack = True
                    self.__ball.is_shot = True
                    self.__internal_state = DUNKING
                    self.__dunk_orient[0] = self.__get_signal(dist_x)
                    self.__dunk_orient[1] = self.__get_signal(dist_y)
                    self.__dunk_orient[2] = self.__get_signal(dist_z)
                    self.__target_basket_pos = [basket[0],basket[1],basket[2]]
                    self.__ball.goal_basket = self.__target_basket_pos
                    self.__target_dunk_pos = [basket[0],basket[1],basket[2]]
                    if basket[0] < self.get_scene().get_scene_wh()[0] / 2.0:
                        signal = 1.0
                    else:
                        signal = -1.0
                    if (dist_x > 0 and dist_x < 40) or (dist_x < 0 and dist_x > -40):
                        self.__target_dunk_pos[1] += -30.0 * self.__dunk_orient[1]
                    else:
                        self.__target_dunk_pos[0] += 30.0 * signal
                    ratio1 = self.__dunk_speed / dist
                    self.__dunk_step[0] = (self.__target_dunk_pos[0] - self.xyz[0]) * ratio1
                    self.__dunk_step[1] = (self.__target_dunk_pos[1] - self.xyz[1]) * ratio1
                    self.__dunk_step[2] = (self.__target_dunk_pos[2] - self.xyz[2]) * ratio1
                    self.set_state_effect(u"����������")
                    return
            #normal shoot
            rand1 = random.random()
            if rand1 * ratio < d / mlen:
                goal = False
        
        if self.__internal_state == DUNKING and is_dunk == True:
            self.__ball.set_xyz([self.__target_basket_pos[0],self.__target_basket_pos[1],self.__target_basket_pos[2] + 10])
            self.__ball.is_dunk = True
            self.__ball.set_speed([0, 0, -10], True, "shoot")
            self.__ball.shooter = self.name
            tmp = comment_random[random.randint(0,len(comment_random) - 1)]
            self.get_scene().speak(tmp %(self.name))
            pygame.time.delay(200)
            self.stop_pick_ball_momently(70)
            self.__internal_state = NO_BALL
            return
        
        g = self.__ball.gravity
        h = basket[2] - self.__ball.xyz[2]
        min_speed_z = math.sqrt(-2.0 * g * h)
        if d < mlen * 1.0 / 3.0:
            v0 = min_speed_z + 10 + 5 * (1 - ratio)
        elif d < mlen * 2.0 / 3:
            v0 = min_speed_z + 13 + 10 * (1 - ratio)
        else:
            v0 = min_speed_z + 15 + 15 * (1 - ratio)
        t = 0.5 * (-2 * v0 / g + math.sqrt(4 * v0 * v0 / g / g + 8 * h / g))
        dx = basket[0] - self.__ball.xyz[0]
        dy = basket[1] - self.__ball.xyz[1]
        self.__ball.shooter = self.name
        self.__ball.set_speed([dx / t, dy / t, v0], goal, "shoot")
        #theorem of momentum, assume that player 5 times heavier than the ball
        self.__jump_v -= v0 * 0.2
        self.stop_pick_ball_momently()
        self.__internal_state = NO_BALL

    def pick_ball(self):
        '''pick the ball'''
        if not self.__check_if_cango(): return
        if self.__internal_state != NO_BALL: return
        if self.__can_pick_countdown < 0 and\
           self.__internal_state == NO_BALL and\
           (self.__ball.internal_status == "free" or self.__ball.internal_status == "stop" or self.__ball.owner is self):
            self.__internal_state = CONTROL_BALL
            self.__pick_ball_just_now = 1

    def attack(self):
        '''create an attack action'''
        if not self.__check_if_cango(): return
        if self.__internal_state != NO_BALL: return
        r = random.random()
        if r > self.__attack_probability: 
            self.set_state_effect(u"��ѽ�������!")
            return
        if self.__face_orientation[0] == 0:
            orient = self.__face_orientation
            attack_lwh = [self.__attack_lwh[1],self.__attack_lwh[0],self.__attack_lwh[2]]
            ani = copy.copy(self.__attack_ani)
        else:
            orient = [self.__face_orientation[0],0]
            attack_lwh = self.__attack_lwh
            if self.__face_orientation[0] == 1:
                ani = copy.copy(self.__attack_ani_right)
            else:
                ani = copy.copy(self.__attack_ani_left)
        a_x = self.xyz[0] + orient[0] * (self.__attack_lwh[0] + self.get_lwh()[0]) / 2.0
        a_y = self.xyz[1] + orient[1] * (self.__attack_lwh[1] + self.get_lwh()[1]) / 2.0
        ani.play()
        attack_s = attacksprite.AttackSprite(self.get_scene(),
                                             self,
                                             [a_x,a_y,self.xyz[2]],
                                             attack_lwh,ani,
                                             2)
        self.get_scene().add_new_item(attack_s)
        self.set_state_effect(u"����!")
    
    def can_faint(self):
        can_faint_set = [CONTROL_BALL,PASSING,SHOOTING,DUNKING]
        if self.__internal_state in can_faint_set:
            return True
        else:
            return False

    def faint(self):
        '''being attacked successfully. Begin to faint'''
        if not self.__check_if_cango(): return
        if not self.can_faint(): return
        self.__faint_count_down = self.__faint_time
        #if it controls the ball, it can not control it anymore.
        #the ball will fall down
        if self.__internal_state == CONTROL_BALL or\
           self.__internal_state == PASSING or\
           self.__internal_state == SHOOTING or\
           self.__internal_state == DUNKING:
            ball_speed = 20
            self.__ball.set_speed([self.__face_orientation[0]*ball_speed,
                                   self.__face_orientation[1]*ball_speed,
                                   0
                                  ],
                                  0, None)
        self.__ball.is_shot = False
        self.__ball.have_goal_defend = False
        self.__ball.have_goal_attack = False
        self.__cur_ani = self.__ani_stand[self.__cur_index]
        self.__cur_ani.play()
        self.__internal_state = FAINT
        self.set_state_effect(u"����...",self.__faint_time)

    def crash(self,obj):
        '''when the obj crash to this object, call it'''
        if obj.get_type() == mybasesprite.ObjType.BallSprite:
            if obj.can_be_caught:
                if obj.tar_team and obj.tar_team != self.team_id:
                    return
                obj.can_be_caught = False
                self.pick_ball()
        elif obj.get_type() == mybasesprite.ObjType.AttackSprite and\
             obj.get_owner().team_id != self.team_id:
            r = random.random()
            if r > self.__be_attacked_probability:
                self.set_state_effect(u'������')
                return
            self.faint()

    def get_internal_state(self):
        '''return the internal status of player'''
        return self.__internal_state

    def get_face_orientation(self):
        '''return the face orientation'''
        return copy.copy(self.__face_orientation)

    def can_pick_ball(self):
        '''If this player can pick up the ball, return True, else return False'''
        if self.__can_pick_countdown < 0 and self.__internal_state == NO_BALL:
            return True
        else:
            return False

    def is_it_pick_ball_justnow(self):
        if self.__pick_ball_just_now == 1 or self.__pick_ball_just_now == 2:
            return True
        else:
            return False

    def update_when_jumping(self):
        if self.__internal_state == DUNKING:
            return
        half_h = self.get_lwh()[2] / 2.0
        if self.__jump_v == 0 and self.xyz[2] == half_h: return
        new_jump_v = self.__jump_v + self.__ball.gravity * self.__ball.frame_time
        dz = (new_jump_v * new_jump_v - self.__jump_v * self.__jump_v) / 2.0 / self.__ball.gravity
        self.__jump_v = new_jump_v
        self.xyz[2] += dz
        if self.xyz[2] <= half_h:
            self.xyz[2] = half_h
            self.__jump_v = 0
    
    def update_when_dunking(self):
        dist_x = self.__target_dunk_pos[0] - self.xyz[0]
        dist_y = self.__target_dunk_pos[1] - self.xyz[1]
        dist_z = self.__target_dunk_pos[2] - self.xyz[2]
        dist = math.sqrt(dist_x * dist_x + dist_y * dist_y + dist_z * dist_z)
        if dist_x * self.__dunk_orient[0] > 0 or\
           dist_y * self.__dunk_orient[1] > 0 or\
           dist_z * self.__dunk_orient[2] > 0 :
            if dist_x * self.__dunk_orient[0] > 0:
                self.xyz[0] += self.__dunk_step[0]
            if dist_y * self.__dunk_orient[1] > 0:
                self.xyz[1] += self.__dunk_step[1]
            if dist_z * self.__dunk_orient[2] > 0:
                self.xyz[2] += self.__dunk_step[2]
        else:
            self.shoot(True)

    def update(self):
        '''update the player's status.'''
        #count position.
        self.speed_update()
        self.update_when_jumping()
        if self.__internal_state == SHOOTING or self.__internal_state == DUNKING:
            self.__set_ball_pos_with_player()

        half_l = self.get_lwh()[0] / 2.0
        half_w = self.get_lwh()[1] / 2.0
        half_h = self.get_lwh()[2] / 2.0
        lt = self.translate([self.xyz[0] - half_l, self.xyz[1], self.xyz[2] + half_h])
        rb = self.translate([self.xyz[0] + half_l, self.xyz[1], self.xyz[2] - half_h])
        w, h = rb[0] - lt[0], rb[1] - lt[1]
        #according to player's position and status, update animation
        if self.__internal_state == FAINT:
            if self.__faint_count_down == 0:
                self.__internal_state = NO_BALL
                #while fainting, stand
                self.__cur_ani = self.__ani_stand[self.__cur_index]
            else:
                self.__faint_count_down -= 1
        if self.__internal_state == NO_BALL or self.__internal_state == CONTROL_BALL or self.__internal_state == PASSING:
            #it can move or stand in these statuses
            if self.__have_moved:
                self.__have_moved = False
            else:
                self.__cur_ani = self.__ani_stand[self.__cur_index]
            if self.__internal_state == CONTROL_BALL:
                if self.xyz[2] <= half_h:
                    if self.__ball.internal_status != "dribbling":
                        self.__ball.internal_status = "dribbling"
                else:
                    self.__set_ball_pos_with_player()

        if self.__internal_state == PASSING:
            self.__set_ball_pos_with_player()
        if self.__internal_state == SHOOTING:
            if self.xyz[2] <= half_h and self.__jump_v <= 0:
                if self.__ball.internal_status == 'control' and self.__internal_state == SHOOTING:
                    #player have not shooted the ball yet, force it to shoot
                    self.shoot()
                else:
                    self.__internal_state = NO_BALL
                    self.__cur_ani = self.__ani_stand[self.__cur_index]
                    self.__cur_ani.play()
                self.xyz[2] = half_h
                self.__jump_v = 0
        if self.__internal_state == DUNKING:
            self.update_when_dunking()

        self.__cur_ani.set_xywh((lt[0],lt[1],w,h))
        self.__cur_ani.update()

        #update the shadow
        shadow_pos = self.translate([self.xyz[0], self.xyz[1], 0])
        shadow_l = self.get_lwh()[0]
        shadow_w = self.get_lwh()[1] / 2.0
        shadow_pos[0] -= shadow_l / 2.0
        shadow_pos[1] -= shadow_w / 2.0
        shadow_pos.extend([shadow_l, shadow_w])
        self.__ani_shadow.set_xywh(shadow_pos)
        self.__ani_shadow.update()

        if self.__can_pick_countdown >= 0:
            self.__can_pick_countdown -= 1

        if self.__pick_ball_just_now == 1:
            self.__pick_ball_just_now = 2
        else:
            self.__pick_ball_just_now = 0
        
        #update state effect
        self.update_state_effect()

        #update id effect
        t = self.translate(self.xyz)
        t[0] += w / 2.0 - len(self.name) * 6 - 15
        t[1] -= 45
        self.__id_effect.set_pos(t)

    def render(self):
        '''render the player'''
        self.__ani_shadow.render()
        self.__cur_ani.render()
        self.__id_effect.render()
        self.render_state_effect()
        #ending animation has not been done. to be continued

    def speed_up(self):
        if not self.__check_if_cango(): return
        if self.__internal_state != CONTROL_BALL: return
        if self.speed_up_interval > 0 or self.is_speed_up: return
        self.speed_up_interval = self.__run_interval
        self.speed_up_time = self.__run_time
        self.is_speed_up = True
        self.__speed = self.__run_speed
        self.set_state_effect(u'����ͻ�ƣ�',25)

    def speed_update(self):
        if self.speed_up_interval > 0:
            self.speed_up_interval -= 1
        if self.is_speed_up and self.speed_up_time <= 0:
            self.__speed = self.__drible_speed
            self.is_speed_up = False
        elif self.speed_up_time > 0:
            self.speed_up_time -= 1
        elif self.__internal_state != CONTROL_BALL:
            self.__speed = self.__normal_speed
        else:
            self.__speed = self.__drible_speed