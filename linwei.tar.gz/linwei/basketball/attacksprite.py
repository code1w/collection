# -*- coding:gb2312 -*-

'''This module defines attack class'''
import mybasesprite
import animationsprite

class AttackSprite(mybasesprite.MyBaseSprite):
    '''Attack sprite'''

    def __init__(self,scene,owner,xyz,lwh,ani,frame_num,
                 type=mybasesprite.ObjType.AttackSprite):
        '''Construction'''
        #owner player of this attack
        self.__owner = owner
        #attack special animation
        self.__ani = ani
        self.__ani.play()
        #if this variable become zero, this object will die
        self.__count_down = frame_num
        crash_type_list = [mybasesprite.ObjType.PlayerSprite]
        mybasesprite.MyBaseSprite.__init__(self,scene,xyz,lwh,type,crash_type_list)
        self.update()

    def __del__(self):
        pass

    def update(self):
        '''update the attack's status.'''
        if self.status != mybasesprite.ObjStatus.Active:
            return
        if self.__count_down >= 0:
            self.__count_down -= 1
        else:
            self.status = mybasesprite.ObjStatus.Killed
        
        half_l = self.get_lwh()[0] / 2.0
        half_w = self.get_lwh()[1] / 2.0
        half_h = self.get_lwh()[2] / 2.0
        lt = self.translate([self.xyz[0] - half_l, self.xyz[1], self.xyz[2] + half_h])
        rb = self.translate([self.xyz[0] + half_l, self.xyz[1], self.xyz[2] - half_h])
        w, h = rb[0] - lt[0], rb[1] - lt[1]
        self.__ani.set_xywh((lt[0],lt[1],w,h))
        self.__ani.update()


    def render(self):
        '''render the attack'''
        if self.status == mybasesprite.ObjStatus.Active:
            #draw attack special animation
            self.__ani.render()

    def get_owner(self):
        return self.__owner