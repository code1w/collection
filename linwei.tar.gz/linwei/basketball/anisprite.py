# -*- coding:gb2312 -*-

'''This module defines basketball player class'''
import random
import copy
import animationsprite
import attacksprite
import AI.player


import sys,pygame
import math
import mybasesprite
import ballsprite
import teamsprite
import AI.ai
import basketsprite
import time
import goalscenesprite
import effect
import configp


#index of animation_list
UP_I,DOWN_I,LEFT_I,RIGHT_I = 0,1,2,3
WIN_I,LOSE_I = 0,1


class AniSprite(mybasesprite.MyBaseSprite):

    def __init__(self,scene,xyz,xy,ani,type=mybasesprite.ObjType.AniSprite):
        '''Construction'''
        self.__ani_dict = ani
        self.__ani_index = -1
        self.__ani_loop = 0
        self.__scene = scene
        self.xywh = xyz[0],xyz[1],xy[0]-xyz[0],xy[1]-xyz[1]
        #animation list of player' running action.
        mybasesprite.MyBaseSprite.__init__(self,scene,xyz,self.xywh,type)
        self.__img = None
        self.__lastPath = ''

    def crash(self,obj):
        '''when the obj crash to this object, call it'''
        pass

    def play (self, index, loop=0):
        self.__ani_index = index
        self.__ani_dict[self.__ani_index].play()
        self.__ani_loop = loop

    def update(self):
        if self.__ani_index>=0:
            ani = self.__ani_dict[self.__ani_index]
            ani.update()
            if ani.get_loop()>self.__ani_loop and self.__ani_loop>=0:
                self.__ani_index = -1
        else:
            for obj in self.__scene.objList:
                if obj.get_type() == mybasesprite.ObjType.TeamSprite:
                    if obj.team_control_ball:
                        player = obj.get_control_ball_player()
                        if player != None:
                            path = u"/data/github/linwei/basketball/images/logo/"+obj.name
                            path += u"/" + player.name
                            path += u".jpg"
                            if self.__lastPath != path:
                                self.__lastPath = path
                                #_path = path.encode('gb2312')
                                _path = path.encode('utf8')
                                img = pygame.image.load(_path).convert()
                                self.__img = pygame.transform.scale(img, (self.xywh[2],self.xywh[3]))


    def render(self):
        '''render the player'''
        if self.__ani_index>=0:
            ani = self.__ani_dict[self.__ani_index]
            ani.set_xywh(self.xywh)
            ani.render()
        elif self.__img != None:
            self.__scene.screen.blit(self.__img, self.xywh)
        #ending animation has not been done. to be continued
