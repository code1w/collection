# -*- coding:gb2312 -*-
import copy
import sceneglobal

'''this module defines base object of basketball game'''
class SoundEffect:
    NoSound = 0
    Smack = 1
    PassBall = 2
    Whistle = 3
    Damm = 4
    Slam1 = 5
    Slam2 = 6
    Cheer = 10
    Dunk1 = 11
    Dunk2 = 12
    Dunk3 = 13

ObjSound = SoundEffect()

class TypeEnum:
    '''Enumeration of the type of objects'''
    MyBaseSprite = -1
    SceneSprite = 0
    BallSprite = 1
    PlayerSprite = 2
    TeamSprite = 3
    AttackSprite = 4
    AnimationSprite = 5
    BasketSprite = 6
    Effect = 7
    AniSprite = 8

#use it to get the enumeration of type
ObjType = TypeEnum()

class StatusEnum:
    '''Enumeration of the status of objects'''
    Killed = 0
    Active = 1

#use it to get the enumeration of status
ObjStatus = StatusEnum()

class VisableEnum:
    '''Enumeration of the status of objects'''
    UnVisable = 0
    Visable = 1

#use it to get the enumeration of visable
ObjVisable = VisableEnum()

class ActiveEnum:
    '''Enumeration of the status of objects'''
    Inactive = 0
    Active = 1

#use it to get the enumeration of visable
ObjActive = ActiveEnum()

#index of keyboard status list
UP_I,DOWN_I,LEFT_I,RIGHT_I,A_I,B_I,C_I,D_I,P1_I,P2_I,P3_I = 0,1,2,3,4,5,6,7,8,9,10

class MyBaseSprite(object):
    '''Base Sprite class declared by myself'''
    def __init__(self,scene,xyz,lwh,type=ObjType.MyBaseSprite,crash_type_list=[]):
        '''Construction'''
        #reference to the scene
        self.__scene = scene
        #position of the center of this object
        self.xyz = [xyz[0],xyz[1],xyz[2]]
        #length, width and height of this object
        self.__lwh = [lwh[0],lwh[1],lwh[2]]
        #valid crash type list
        self.__crash_type_list = crash_type_list
        #type of this class
        self.__type = type
        #status of this object
        self.status = ObjStatus.Active
        #is visable of this object
        self.visable = ObjVisable.Visable
        #is visable of this object
        self.active = ObjActive.Active

    def update(self):
        '''update the object's status. Subclass must implement it'''
        pass
    def render(self):
        '''render the object to the screen. Subclass must implement it'''
        pass
    def get_center_xyz(self):
        '''It will return [x,y,z]'''
        return copy.copy(self.xyz)
    def get_lwh(self):
        '''It will return [l,w,h]'''
        return copy.copy(self.__lwh)
    def get_cube_xyz(self):
        '''It will return the position of this object's cube'''
        half_lwh = [self.__lwh[0] / 2.0, self.__lwh[1] / 2.0, self.__lwh[2] / 2.0]
        return [(self,
                 ([self.xyz[0]-half_lwh[0],self.xyz[1]-half_lwh[1],self.xyz[2]-half_lwh[2]],
                  [self.xyz[0]+half_lwh[0],self.xyz[1]+half_lwh[1],self.xyz[2]+half_lwh[2]]))]
    def get_crash_type_list(self):
        '''It will return a type list. If this object crash with another object,
        whose type is in the list, something special will happen'''
        return copy.copy(self.__crash_type_list)
    def get_scene(self):
        '''It will return the reference of scene'''
        return self.__scene;
    def get_type(self):
        '''It will return the type of this object'''
        return self.__type
    def crash(self,obj):
        '''when the obj crash to this object, call it'''
        pass
    def translate(self, xyz):
        '''translate 3d position to 2d, to be continued'''
        x,y,z = xyz[0],xyz[1],xyz[2]
        bias_x,bias_y,screen_uw,screen_dw,screen_h = self.__scene.get_scene_data()
        scene_w,scene_h = self.__scene.get_scene_wh()
        ratio_h = screen_h / scene_h
        ratio_w = screen_dw / scene_w
        height = screen_dw * screen_h / (screen_dw - screen_uw)
        ratio2 = (ratio_h * y + height - screen_h) / height
        new_x = bias_x + ratio2 * ratio_w * (x - scene_w / 2.0) + screen_dw / 2.0
        new_y = bias_y + ratio_h * y - ratio2 * z
        return [new_x,new_y]

if __name__ == '__main__':
    b = MyBaseSprite(None,[0,0,0],[1,2,3],[ObjType.AnimationSprite,ObjType.AttackSprite])
    b.update()
    b.render()
    print b.get_center_xyz()
    print b.get_lwh()
    print b.get_cube_xyz()
    print b.get_crash_type_list()
    print b.get_scene()
    print b.get_type()
    b.crash(None)