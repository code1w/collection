# -*- coding:gb2312 -*-
import sys, pygame, random,copy
import codecs

import myresource
import mybasesprite
import animationsprite
import teamsprite
import playersprite
import ballsprite
import basketsprite
import configp
import AI.ai
import effect
import gameoversprite
import pausesprite
import sceneglobal
import anisprite

def objCmp (obj1, obj2):
    return cmp(obj1.get_center_xyz()[1], obj2.get_center_xyz()[1])

class Scene(mybasesprite.MyBaseSprite):
    mainClass = None
    screen = None
    bgcolour = 0x0, 0x0, 0x0
    clock = None
    objList = []
    objNewList = []
    aiList = []
    sceneAttribQueueMaxLen = 0
    sceneAttribQueue = []
    sceneAttribInOut = [0,0,0]
    soundEffectList = []
    soundDict = {}
    event = []
    __nTime = 0
    __nLastTime = 0
    param = {}
    __nGameTimeLimit = 0
    lt,lb,rt,rb,basket1_pos,basket2_pos = [0,0],[0,0],[0,0],[0,0],[0,0,0],[0,0,0]
    __bias_x,__bias_y = 0,0
    __screen_uw,__screen_dw,__screen_h = 0,0,0
    __scene_w,__scene_h = 0,0
    pausekeyst = 1
    begin_comment = [u"��λ���ڣ�Ҳ�����ոմ򿪵��ӻ�����������ֱ������%s vs %s�ı���", u"��������̨������Ϊ��ֱ������MBAһ������ʮ���ĳ�������%s vs %s", u"���������ǣ�Ҳ�����ոմ򿪵��ݣ���������ֱ������%s vs %s�ı���", u"���Ų���Աһ�����죬%s vs %s�ı�����ʽ��ʼ��", u"���Ų���Աһ�����ڣ�%s vs %s�ı�����ʼ��"]

    def del_object_list(self):
        self.objList = []
        self.objNewList = []
        self.aiList = []
        self.event = []
        self.param = {}
        self.sceneAttribQueue = []
        self.mainClass = None
        self.screen = None
        self.clock = None
        self.soundEffectList = []

    def __del__(self):
        pass

    def get_scene_data(self):
        return self.__bias_x,self.__bias_y,self.__screen_uw,self.__screen_dw,self.__screen_h

    def __init_scene_data(self):
        scene_param = self.param
        self.lt,self.lb,self.rt,self.rb = [0,0],[0,0],[0,0],[0,0]
        self.__scene_w = float(scene_param['scene']['scene_w'])
        self.__scene_h = float(scene_param['scene']['scene_h'])

        self.lt[0] = float(scene_param['scene']['lt_x'])
        self.lt[1] = float(scene_param['scene']['lt_y'])

        self.rt[0] = float(scene_param['scene']['rt_x'])
        self.rt[1] = float(scene_param['scene']['rt_y'])

        self.rb[0] = float(scene_param['scene']['rb_x'])
        self.rb[1] = float(scene_param['scene']['rb_y'])

        self.lb[0] = float(scene_param['scene']['lb_x'])
        self.lb[1] = float(scene_param['scene']['lb_y'])

        basket1_x = float(scene_param['scene']['basket1_x'])
        basket1_y = float(scene_param['scene']['basket1_y'])

        basket2_x = float(scene_param['scene']['basket2_x'])
        basket2_y = float(scene_param['scene']['basket2_y'])

        self.__bias_x,self.__bias_y = self.lb[0],self.lt[1]
        self.__screen_uw = self.rt[0] - self.lt[0]
        self.__screen_dw = self.rb[0] - self.lb[0]
        self.__screen_h = self.lb[1] - self.lt[1]

        self.basket1_pos = self.__get_basket_pos(basket1_x,basket1_y)
        self.basket2_pos = self.__get_basket_pos(basket2_x,basket2_y)

        sceneglobal.sceneParam.basket1_pos = self.basket1_pos
        sceneglobal.sceneParam.basket2_pos = self.basket2_pos
        sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h = self.__scene_w, self.__scene_h

        #soundDict
        ObjSound = mybasesprite.ObjSound
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/smack.wav'), None]
        self.soundDict[ObjSound.Smack] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/pass.wav'), None]
        self.soundDict[ObjSound.PassBall] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/whistle.wav'), None]
        self.soundDict[ObjSound.Whistle] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/damm.wav'), None]
        self.soundDict[ObjSound.Damm] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/slam1.wav'), None]
        self.soundDict[ObjSound.Slam1] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/slam2.wav'), None]
        self.soundDict[ObjSound.Slam2] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/cheer.ogg'), None]
        self.soundDict[ObjSound.Cheer] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/dunk1.ogg'), None]
        self.soundDict[ObjSound.Dunk1] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/dunk2.ogg'), None]
        self.soundDict[ObjSound.Dunk2] = snd
        snd = [pygame.mixer.Sound('/data/github/linwei/basketball/sound/dunk3.ogg'), None]
        self.soundDict[ObjSound.Dunk3] = snd

    def __get_basket_pos(self,basket_pic_x1,basket_pic_y1):
        bias_x,bias_y = self.__bias_x,self.__bias_y
        scene_w,scene_h = self.__scene_w,self.__scene_h
        screen_uw,screen_dw,screen_h = self.__screen_uw,self.__screen_dw,self.__screen_h
        ratio_h = screen_h / scene_h
        ratio_w = screen_dw / scene_w
        height = screen_dw * screen_h / (screen_dw - screen_uw)
        basket_proj_x,basket_proj_y,basket_proj_z = basket_pic_x1 - bias_x,screen_h / 2.0,screen_h / 2.0 + bias_y - basket_pic_y1
        x = (basket_proj_x - (basket_proj_x - screen_dw / 2.0) / (1.0 - height / (screen_h - basket_proj_y))) / ratio_w
        y = basket_proj_y / ratio_h
        z = basket_proj_z * (screen_dw / 2.0 - x * ratio_w) / (screen_dw / 2.0 - basket_proj_x)
        return [x,y,z]


    def __init__(self, _main, _param):
        mybasesprite.MyBaseSprite.__init__(self,None,[0,0,0],[0,0,0],0,[])
        self.mainClass = None
        self.screen = None
        self.bgcolour = 0x0, 0x0, 0x0
        self.clock = None
        self.objList = []
        self.objNewList = []
        self.aiList = []
        self.event = []
        self.__nTime = 0
        self.__nLastTime = 0
        self.param = {}
        self.__nGameTimeLimit = 0
        self.pausekeyst = 1
        self.sceneAttribQueueMaxLen = 12
        self.sceneAttribQueue = []
        self.sceneAttribInOut = [0,0,0]
        self.initparam = _param

        pygame.init()
        pygame.display.init()
        self.mainClass = _main
        mybasesprite.MyBaseSprite.__init__(self,self,(0,0,0),(0,0,0),mybasesprite.ObjType.SceneSprite)
        self.clock = pygame.time.Clock()
        pygame.key.set_repeat(1,1)
        pygame.mouse.set_visible(0)
        cp = configp.ConfigP('scene.ini')
        self.param = cp.getdic()
        self.__nGameTimeLimit = int(_param['gametime'])
        self.__nTime = 0

        self.__init_scene_data()

        self.sceneAttribQueue = [[] for col in range(self.sceneAttribQueueMaxLen)]

        ani_ball = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'ball.ini')
        ani_touch = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'touch.ini')
        ani_shadow = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'shadow.ini')
        ani_arrow = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'arrow.ini')
        ani_arrow2 = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'arrow.ini')
        self.__bgimg1 = pygame.image.load("/data/github/linwei/basketball/images/background4.png").convert()
        self.__bgimg2 = pygame.image.load("/data/github/linwei/basketball/images/background5.png").convert()
        self.__bgflashtime = 0
        ball = ballsprite.BallSprite([ani_ball, ani_touch, ani_shadow, ani_arrow, ani_arrow2],self, [400, 100, 200], [14, 14, 14])
        ball.internal_status = 'free'

        self.objList.append(ball)

        basket1 = basketsprite.BasketSprite(self, self.basket1_pos, [28, 28, 2], 1)
        basket2 = basketsprite.BasketSprite(self, self.basket2_pos, [28, 28, 2], 2)

        self.objList.append(basket1)
        self.objList.append(basket2)

        score_board = effect.Effect(self, (430, 20), "word")
        score_board.write("0    :    0")
        self.objList.append(score_board)
        self.score_board = score_board

        deepcopy = lambda l:[copy.copy(l[i]) for i in xrange(len(l))]

        ani_run_a = [animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'back.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'front.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'left.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'right.ini')]
        ani_run_b = [animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'back.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'front.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'left.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'right.ini')]

        ani_stand_a = [animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'stand_back.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'stand_front.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'stand_left.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'stand_right.ini')]
        ani_stand_b = [animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'stand_back.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'stand_front.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'stand_left.ini'),
                   animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'stand_right.ini')]

        ani_attack_a = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'attack.ini')
        ani_attack_a.set_alpha(150)
        ani_attack_left_a = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'attack_left.ini')#'attack_left.ini')
        ani_attack_left_a.set_alpha(150)
        ani_attack_right_a = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'attack_right.ini')#'attack_right.ini')
        ani_attack_right_a.set_alpha(150)
        ani_attack_a_list = []
        ani_attack_a_list.append(ani_attack_a)
        ani_attack_a_list.append(ani_attack_left_a)
        ani_attack_a_list.append(ani_attack_right_a)

        ani_attack_b = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'attack.ini')
        ani_attack_b.set_alpha(150)
        ani_attack_left_b = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'attack_left.ini')#'attack_left.ini')
        ani_attack_left_b.set_alpha(150)
        ani_attack_right_b = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'attack_right.ini')#'attack_right.ini')
        ani_attack_right_b.set_alpha(150)
        ani_attack_b_list = []
        ani_attack_b_list.append(ani_attack_b)
        ani_attack_b_list.append(ani_attack_left_b)
        ani_attack_b_list.append(ani_attack_right_b)

        ani_circle_a = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'circle.ini')
        ani_circle_b = animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'circle.ini')


        ani_shoot_a =[animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'shoot_back.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'shoot_front.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'shoot_left.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_a/', 'shoot_right.ini')]
        ani_shoot_b =[animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'shoot_back.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'shoot_front.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'shoot_left.ini'),
                  animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/team_b/', 'shoot_right.ini')]

        player_config = self.get_scene_param('player.ini')
        half_p_h = float(player_config['player']['player_height']) / 2.0

        diff = _param['diff']
        diff1 = diff2 = 'player'
        self.sceneAttribQueueMaxLen = 12
        if diff>3:
            diff1 = diff2 = 'easy'
        elif diff==3:
            diff2 = 'hard'
            #self.sceneAttribQueueMaxLen = 1
        elif diff==2:
            diff2 = 'normal'
            #self.sceneAttribQueueMaxLen = 6
        elif diff==1:
            diff2 = 'easy'
        #load team and player's data
        team1_data_cp = configp.ConfigP(diff1+'_mode.ini')
        team1_data_param = team1_data_cp.getdic()
        rand_index = random.randint(0,len(team1_data_param) - 1)
        i = 0
        for k,v in team1_data_param.items():
            if i == rand_index:
                team_name = k
                player_name_list = v
                break
            i += 1
        #add team 1 data
        self.__player = playersprite.PlayerSprite(0,10,unicode(player_name_list['0'],'gb2312'),player_config,self,
                                     [170,100,half_p_h],
                                     deepcopy(ani_run_a),
                                     deepcopy(ani_stand_a),
                                     deepcopy(ani_shoot_a),
                                     None,
                                     copy.copy(ani_attack_a_list),
                                     copy.copy(ani_shadow)
                                    )
        player2 = playersprite.PlayerSprite(1,10,unicode(player_name_list['1'],'gb2312'),player_config,self,
                               [100,50,half_p_h],
                               deepcopy(ani_run_a),
                               deepcopy(ani_stand_a),
                               deepcopy(ani_shoot_a),
                               None,
                               copy.copy(ani_attack_a_list),
                               copy.copy(ani_shadow)
                              )

        player3 = playersprite.PlayerSprite(2,10,unicode(player_name_list['2'],'gb2312'),player_config,self,
                               [100,150,half_p_h],
                               deepcopy(ani_run_a),
                               deepcopy(ani_stand_a),
                               deepcopy(ani_shoot_a),
                               None,
                               copy.copy(ani_attack_a_list),
                               copy.copy(ani_shadow)
                              )


        self.objList.append(self.__player)
        self.objList.append(player2)
        self.objList.append(player3)

        team = teamsprite.TeamSprite(10,unicode(team_name,'gb2312'),_param['player1'],self,1,[self.__player,player2,player3],copy.copy(ani_circle_a))
        self.aiList.append(AI.ai.AI(self,team,[pygame.K_w,pygame.K_s,pygame.K_a,pygame.K_d,pygame.K_j,pygame.K_k,pygame.K_SPACE,pygame.K_l,pygame.K_u,pygame.K_i,pygame.K_o],diff1))
        self.objList.append(team)

        #load team and player's data
        team2_data_cp = configp.ConfigP(diff2+'_mode.ini')
        team2_data_param = team2_data_cp.getdic()
        rand_index = random.randint(0,len(team2_data_param) - 1)
        is_finish_search = False
        while not is_finish_search:
            i = 0
            for k,v in team2_data_param.items():
                if i == rand_index:
                    if team_name != k:
                        team_name = k
                        player_name_list = v
                        is_finish_search = True
                    else:
                        rand_index = (rand_index + 1) % len(team2_data_param)
                    break
                i += 1
        #add team 2 data
        player4 = playersprite.PlayerSprite(3,11,unicode(player_name_list['0'],'gb2312'),player_config,self,
                               [630,100,half_p_h],
                               deepcopy(ani_run_b),
                               deepcopy(ani_stand_b),
                               deepcopy(ani_shoot_b),
                               None,
                               copy.copy(ani_attack_b_list),
                               copy.copy(ani_shadow)
                              )

        player5 = playersprite.PlayerSprite(4,11,unicode(player_name_list['1'],'gb2312'),player_config,self,
                               [700,50,half_p_h],
                               deepcopy(ani_run_b),
                               deepcopy(ani_stand_b),
                               deepcopy(ani_shoot_b),
                               None,
                               copy.copy(ani_attack_b_list),
                               copy.copy(ani_shadow)
                              )

        player6 = playersprite.PlayerSprite(5,11,unicode(player_name_list['2'],'gb2312'),player_config,self,
                               [700,150,half_p_h],
                               deepcopy(ani_run_b),
                               deepcopy(ani_stand_b),
                               deepcopy(ani_shoot_b),
                               None,
                               copy.copy(ani_attack_b_list),
                               copy.copy(ani_shadow)
                              )


        self.objList.append(player4)
        self.objList.append(player5)
        self.objList.append(player6)

        team2 = teamsprite.TeamSprite(11,unicode(team_name,'gb2312'),_param['player2'],self,-1,[player4,player5,player6],copy.copy(ani_circle_b))
        self.aiList.append(AI.ai.AI(self,team2,[pygame.K_UP,pygame.K_DOWN,pygame.K_LEFT,pygame.K_RIGHT,pygame.K_KP1,pygame.K_KP2,pygame.K_KP0,pygame.K_KP3,pygame.K_KP4,pygame.K_KP5,pygame.K_KP6],diff2))
        self.objList.append(team2)

        ball.internal_status = "free"
        self.word_table = effect.Effect(self, (400, 20), "table")
        self.objList.append(self.word_table)
        tmp = self.begin_comment[random.randint(0,len(self.begin_comment) - 1)] %(team.name, team2.name)
        self.word_table.speak(tmp)

        ani_dict = {'dunk0': animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'dunk0.ini'),\
                    'dunk1': animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'dunk1.ini'),\
                    'dunk2': animationsprite.AnimationSprite(self, '/data/github/linwei/basketball/images/', 'dunk2.ini')}
        xy = self.__bgimg1.get_size()
        ani = anisprite.AniSprite(self, (xy[0]-200,xy[1],0), self.mainClass.screen.get_size(), ani_dict)
        self.objList.append(ani)
        #ani.play('test', -1)

        self.add_sound(mybasesprite.ObjSound.Whistle, 0)
        #ball.owner = self.__player
        #self.__player.pick_ball()


    def get_scene_wh (self):
        return self.__scene_w, self.__scene_h

    def get_ball(self):
        return self.objList[0] ### if first obj is ball

    def get_baskets(self):
        basketList = []
        for obj in self.objList:
            if obj.get_type() == mybasesprite.ObjType.BasketSprite:
                basketList.append(obj)
        return basketList

    def add_new_item (self, obj):
        self.objNewList.append(obj)

    def get_scene_param (self, filename):
        cp = configp.ConfigP(filename)
        return cp.getdic()

    def get_player_attrib(self, id):
        return self.sceneAttribQueue[self.sceneAttribInOut[1]][id]

    def get_ball_attrib(self):
        return self.sceneAttribQueue[self.sceneAttribInOut[2]][6] #if len(players) == 6

    def get_all_attrib(self):
        return self.sceneAttribQueue[self.sceneAttribInOut[1]]

    def get_all_realtime_attrib(self):
        return self.sceneAttribQueue[self.sceneAttribInOut[2]]

    def play_animation (self, item):
        for obj in self.objList:
            if obj.get_type() == mybasesprite.ObjType.AniSprite:
                obj.play(item, 0)

    def crash_test (self, objList):
        randomList = objList[:]
        random.shuffle(randomList)
        for n1 in range(len(randomList)-1):
            obj1 = objList[n1]
            xyrL1 = obj1.get_cube_xyz()
            obj1_status = 0
            for n2 in range(n1+1, len(randomList)):
                obj2 = objList[n2]
                xyrL2 = obj2.get_cube_xyz()
                for xyr1 in xyrL1:
                    for xyr2 in xyrL2:
                        if xyr1[1][0][0] > xyr2[1][1][0] or xyr1[1][0][1] > xyr2[1][1][1] or xyr1[1][0][2] > xyr2[1][1][2] \
                            or xyr2[1][0][0] > xyr1[1][1][0] or xyr2[1][0][1] > xyr1[1][1][1] or xyr2[1][0][2] > xyr1[1][1][2]:
                            pass
                        else:
                            xyr1[0].crash(xyr2[0])
                            xyr2[0].crash(xyr1[0])
                            if obj1.status != mybasesprite.StatusEnum.Active :
                                obj1_status = 1
                                break
                    if obj1_status: break
                if obj1_status: break

    def play_sound (self, event, param):
        ObjSound = mybasesprite.ObjSound
        snd = self.soundDict[event]
        if event == ObjSound.Smack:
            pygame.mixer.Channel(event).queue(snd[0])
        elif event == ObjSound.Dunk1 or event == ObjSound.Dunk2 or event == ObjSound.Dunk3:
            _event = ObjSound.Dunk1
            pygame.mixer.Channel(_event).play(snd[0], *param)
        else:
            pygame.mixer.Channel(event).play(snd[0], *param)

    def add_sound (self, event, delay, param=[]):
        self.soundEffectList.append([event, delay, param])


    def speak(self, word):
        self.word_table.speak(word)

    def update(self, event):
        self.__nTime += 1 #Time control
        if self.__nTime>self.__nGameTimeLimit:
            draw = 0
            if self.get_baskets()[1].get_score() > self.get_baskets()[0].get_score():
                word = 'You win'
            elif self.get_baskets()[1].get_score() == self.get_baskets()[0].get_score():
                word = 'Draw Game'
                draw = 1
            else:
                word = 'You Lose'
            if draw==0:
                if self.initparam['diff']==0:
                    word = 'You win'
                elif self.initparam['diff']==4:
                    word = 'Thanks for playing'
            self.mainClass.objList.append(gameoversprite.GameoverScene(self.mainClass, self.mainClass.screen, word))

        for e in event: #Global Event
            if e.type == pygame.KEYUP and e.key == pygame.K_F2:
                self.pausekeyst = 1
                break
            if e.type == pygame.KEYUP and e.key == pygame.K_ESCAPE:
                self.__nTime = self.__nGameTimeLimit
            if self.pausekeyst>0 and e.type == pygame.KEYDOWN and e.key == pygame.K_F2:
                self.pausekeyst = 0
                self.mainClass.objList.append(pausesprite.PauseScene(self.mainClass, self.mainClass.screen))
                #sys.exit()

        itemAttrib = []
        for obj in self.objList:
            if obj.get_type() == mybasesprite.ObjType.PlayerSprite:
                itemAttrib.append(obj.get_attrib())
        for obj in self.objList:
            if obj.get_type() == mybasesprite.ObjType.BallSprite:
                itemAttrib.append(obj.get_attrib())
                break
        self.sceneAttribInOut[2] = self.sceneAttribInOut[0]
        self.sceneAttribQueue[self.sceneAttribInOut[0]] = itemAttrib
        self.sceneAttribInOut[0] = (self.sceneAttribInOut[0]+1)%self.sceneAttribQueueMaxLen

        if len(self.sceneAttribQueue[self.sceneAttribInOut[0]]) == 0 :
            self.sceneAttribInOut[1] = 0
        else:
            self.sceneAttribInOut[1] = self.sceneAttribInOut[0]
        self.sceneAttribQueue[self.sceneAttribInOut[1]][6] = self.sceneAttribQueue[self.sceneAttribInOut[2]][6]

        for obj in self.aiList: #update
            obj.post_key_event(event);

        self.crash_test(self.objList)

        for obj in self.objList: #update
            obj.update();

        for obj in self.objList[:]: #remove not alive
            if obj.status == mybasesprite.ObjStatus.Killed:
                self.objList.remove(obj)

        self.objList.extend(self.objNewList) #add new object into objList
        self.objNewList = []

        if self.__bgflashtime>=0:
            self.__bgflashtime -= 1
        if self.get_ball().have_goal_defend and self.__bgflashtime<=0:
            self.__bgflashtime = sceneglobal.sceneParam.fps*2
            self.add_sound(mybasesprite.ObjSound.Cheer, 10)
        self.score_board.write("%d  :  %d      Time %d" %(self.get_baskets()[1].get_score(), self.get_baskets()[0].get_score(), (self.__nGameTimeLimit-self.__nTime)/sceneglobal.sceneParam.fps))

        for snd in self.soundEffectList[:]:
            if snd[1]<=1:
                self.play_sound(snd[0], snd[2])
                self.soundEffectList.remove(snd)
            else:
                snd[1] -= 1

    def render_map(self,m):
        self.map_to_be_rendered = m

    def render(self, screen):
        self.screen = screen #��Ⱦ��ʱ������Ļ���󴫽���
        if self.__bgflashtime>0 and (self.__bgflashtime/3)%2==0:
            self.screen.blit(self.__bgimg2, (0,0))
        else:
            self.screen.blit(self.__bgimg1, (0,0))

        if self.__dict__.has_key('map_to_be_rendered') and self.map_to_be_rendered != None:
            self.map_to_be_rendered.render(self)

        _objList = self.objList[:]
        _objList.sort(objCmp)
        for obj in _objList: #render
            obj.render();

