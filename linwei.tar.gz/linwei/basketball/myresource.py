import sys, pygame

class Resource:

    def __init__(self):
        pygame.init()

res = Resource()
