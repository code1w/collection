#======================================================================
#
# fsmbase.py - basic finite state machine
#
# NOTE:
# for more information, please see the readme file
#
#======================================================================
import time
import entbase

#----------------------------------------------------------------------
# state - state interface
#----------------------------------------------------------------------
class state(object):
    can_break = True
    def enter (self, entity):
        pass
    def execute (self, entity):
        pass
    def exit (self, entity):
        pass
    def onmessage (self, entity, telegram):
        return False


#----------------------------------------------------------------------
# telegram - telegram interface
#----------------------------------------------------------------------
class telegram(object):
    def __init__ (self, time = 0, sender = -1, receiver = -1, msg = -1):
        self.time = time
        self.sender = sender
        self.receiver = receiver
        self.msg = msg
        self.info = None
    def setting (self, time, sender, receiver, msg, info = None):
        self.time = time
        self.sender = sender
        self.receiver = receiver
        self.msg = msg
        self.info = info
    def __eq__ (self, tel):
        if (abs(self.time - tel.time) < 0.01) and (self.msg == tel.msg) and \
            (self.sender == tel.sender) and (self.receiver == tel.receiver):
            return True
        return False
    def __lt__ (self, tel):
        return self.time < tel.time
    def __gt__ (self, tel):
        return self.time > tel.time
    def __str__ (self):
        msg = 'time:%.3f sender:%d receiver:%d msg:%d'
        return msg%(self.time, self.sender, self.receiver, self.msg)
    def __repr__ (self):
        msg = 'time:%.3f sender:%d receiver:%d msg:%d'
        return msg%(self.time, self.sender, self.receiver, self.msg)


#----------------------------------------------------------------------
# dispatcher - dispatcher interface
#----------------------------------------------------------------------
SEND_MSG_IMMEDIATELY = 0.0
NO_ADDITIONAL_INFO = None
SENDER_ID_IRRELEVANT = -1

class MessageDispatcher(object):
    instance = None
    @staticmethod
    def get_instance():
        if not MessageDispatcher.instance:
            MessageDispatcher.instance = MessageDispatcher()
        return MessageDispatcher.instance
    def __init__ (self):
        self.queue = []
        self.dirty = False
    def discharge (self, entity, tel):
        #print 'Discharge:', tel
        if not entity.handlemsg(tel):
            return False
        return True
    def dispatch_msg (self, delay, sender, receiver, msg, info = None):
        if not receiver in entbase.EntityMgr:
            print 'Warning! No receiver id=%d in EntityMgr'%receiver
            return
        entity = entbase.EntityMgr.getentity(receiver)
        tel = telegram(0, sender, receiver, msg)
        tel.info = info
        if delay <= 0.0:
            self.discharge(entity, tel)
        else:
            current = time.time()
            tel.time = current + delay
            self.queue.append(tel)
            self.dirty = True
    def dispatch_delayed_msg (self):
        if len(self.queue) == 0:
            return
        current = time.time()
        queue = self.queue
        if self.dirty:
            queue.sort(reverse = True)
            self.dirty = False
            for n in queue: print n, current
        while len(queue) > 0:
            pos = len(queue) - 1
            tel = queue[pos]
            if current >= tel.time:
                id = tel.receiver
                if not id in entbase.EntityMgr:
                    print 'Warning! No receiver id=%d in EntityMgr'%id
                else:
                    entity = entbase.EntityMgr.getentity(id)
                    self.discharge(entity, tel)
                del queue[pos]
            else:
                break
        self.queue = queue

Dispatcher = MessageDispatcher.get_instance()


#----------------------------------------------------------------------
# StateMachine
#----------------------------------------------------------------------
class StateMachine(object):
    def __init__ (self, owner = None):
        self.current_state = None
        self.previous_state = None
        self.global_state = None
        self.owner = owner
    def set_current_state (self, newstate):
        self.current_state = newstate
    def set_global_state (self, newstate):
        self.global_state = newstate
    def set_previous_state (self, newstate):
        self.previous_state = newstate
    def update (self):
        if self.current_state:
            self.current_state.execute(self.owner)
        if self.global_state:
            self.global_state.execute(self.owner)
    def handle_message (self, tel):
        if self.current_state:
            if self.current_state.onmessage(self.owner, tel):
                return True
        if self.global_state:
            if self.global_state.onmessage(self.owner, tel):
                return True
        return False
    def change_state (self, newstate):
        if self.current_state != None and not self.current_state.can_break and not self.owner.is_finish: 
            #print 'should not change',self.current_state,self.current_state.can_break,self.owner.is_finish
            return
        self.previous_state = self.current_state
        if self.current_state:
            self.current_state.exit(self.owner)
        self.current_state = newstate
        if self.current_state:
            self.current_state.enter(self.owner)
    def revert_state (self):
        self.change_state(self.previous_state)
    def instate (self, state_type):
        if isinstance(self.current_state, state_type):
            return True
        return False
    

#----------------------------------------------------------------------
# testing case
#----------------------------------------------------------------------
if __name__ == '__main__':
    # basefsm.py basicfsm.py gamefsm.py fsmbase.py fsmbase.h
    queue = []
    queue.append( telegram(10, 0, 0, 0) )
    queue.append( telegram(8, 0, 0, 0) )
    queue.append( telegram(12, 0, 0, 0) )
    queue.append( telegram(5, 0, 0, 0) )
    queue.append( telegram(20, 0, 0, 0) )
    queue.append( telegram(9, 0, 0, 0) )
    queue.append( telegram(15, 0, 0, 0) )
    queue.sort()
    for n in queue: print n
    ent1 = entbase.BaseGameEntity(10,[0,1,2],[10,11,12])
    ent2 = entbase.BaseGameEntity(11,[100,101,102],[110,111,112])
    entbase.EntityMgr.register(ent1)
    entbase.EntityMgr.register(ent2)
    Dispatcher.dispatch_msg(1.000, 10, 11, 10001)
    Dispatcher.dispatch_msg(2.000, 10, 11, 10002)
    Dispatcher.dispatch_msg(1.500, 10, 11, 10003)
    Dispatcher.dispatch_msg(3.000, 10, 11, 10004)
    Dispatcher.dispatch_msg(1.700, 10, 11, 10005)
    Dispatcher.dispatch_msg(2.200, 10, 11, 10006)
    while True:
        time.sleep(0.1)
        Dispatcher.dispatch_delayed_msg()

