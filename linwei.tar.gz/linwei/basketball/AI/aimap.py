# -*- coding:gb2312 -*-

'''This module defines AIMap class for AI module'''
import sys
import pygame
sys.path.append("..")
import configp

maxint = 1000000


#----------------------------------------------------------------------
# AIMap Class
#----------------------------------------------------------------------
class AIMap(object):
    '''map class for AIMap'''
    def __init__ (self,scene_w,scene_h,forget_ratio):
        self.scene_w,self.scene_h = scene_w,scene_h
        self.forget_ratio = forget_ratio
        cp = configp.ConfigP('AI/aimap.ini')
        param = cp.getdic()
        self.grid_w_num = int(param['aimap']['grid_w_num'])
        self.grid_h_num = int(param['aimap']['grid_h_num'])
        self.x_steps = self.scene_w / float(self.grid_w_num)
        self.y_steps = self.scene_h / float(self.grid_h_num)
        self.__grids = [[0.0 for row in range(self.grid_h_num)] for col in range(self.grid_w_num)] 
        self.__max_grid = -1
        self.__min_grid = maxint
        self.__update_ab()
    
    def set_max_grid(self,max_val):
        self.__max_grid = max_val
        self.__update_ab()
    
    def set_min_grid(self,min_val):
        self.__min_grid = min_val
        self.__update_ab()
    
    
    def get_pos_from_xy(self,scene_x,scene_y):
        '''get the position of the item in grids from its position in scene'''
        return int(scene_x / self.x_steps),int(scene_y / self.y_steps)

    def get_x_range(self,x):
        '''get the xth column's begin and end values in scene'''
        beg = self.x_steps * x
        return int(beg),int(beg + self.x_steps)

    def get_y_range(self,y):
        '''get the yth row's begin and end values in scene'''
        beg = self.y_steps * y
        return int(beg),int(beg + self.y_steps)
    
    def get_raw_grid(self,x,y):
        '''get raw value in grid[x,y]'''
        return self.__grids[x][y]
    
    def get_grid(self,x,y):
        '''get normalized value in grid[x,y]'''
        return float(self.__grids[x][y]) * self.a + self.b
    
    def __update_ab(self):
        if self.__max_grid != self.__min_grid:
            self.a = 1.0 / (self.__max_grid - self.__min_grid)
            self.b = -self.__min_grid / float(self.__max_grid - self.__min_grid)
        else:
            self.a = self.b = 0.0
    
    def __update_max_min(self,val):
        change = False
        if val > self.__max_grid:
            self.__max_grid = val
            change = True
        if val < self.__min_grid:
            self.__min_grid = val
            change = True
        if change:
            self.__update_ab()       
    
    def set_grid(self,xy,val):
        x,y = xy[0],xy[1]
        self.__grids[x][y] = val
        self.__update_max_min(val)
        
    
    def add_to_grid(self,xy,val):
        x,y = xy[0],xy[1]
        new_grid = self.__grids[x][y] + val
        self.__grids[x][y] = new_grid
        self.__update_max_min(new_grid)
    
    def update(self):
        '''it must be invoked in every frame'''
        self.__max_grid = -1
        self.__min_grid = maxint
        self.__update_ab()
        for row in range(self.grid_h_num):
            for col in range(self.grid_w_num):
                new_val = self.__grids[col][row] * self.forget_ratio
                self.__grids[col][row] = new_val
                if self.forget_ratio != 0.0:
                    self.__update_max_min(new_val)
    
    def render(self,scene):
        color = [0,255,0,255]
        for y in range(self.grid_h_num):
            for x in range(self.grid_w_num):
                if self.get_grid(x,y) >= 0.99:
                    color[1] = 0
                    color[0] = 255
                else:
                    color[0] = 0
                    color[1] = int(self.get_grid(x,y) * 255)
                x_range = self.get_x_range(x)
                y_range = self.get_x_range(y)
                pointlist = [scene.translate([x_range[0],y_range[0],0]),
                             scene.translate([x_range[1],y_range[0],0]),
                             scene.translate([x_range[1],y_range[1],0]),
                             scene.translate([x_range[0],y_range[1],0])
                            ]
                polygon_ = pygame.draw.polygon(scene.screen, color, pointlist)
    
    def print_it(self,raw):
        for y in range(self.grid_h_num):
            for x in range(self.grid_w_num):
                if raw:
                    print self.__grids[x][y],' ',
                else:
                    print self.get_grid(x,y),' ',
            print '\n'
        print 'max:',self.__max_grid
        print 'min:',self.__min_grid
        print 'a:',self.a
        print 'b:',self.b
        print 'forget_ratio:',self.forget_ratio


if __name__ == '__main__':
    m = AIMap(800,200,0.5)
    m.print_it(False)
    print m.get_pos_from_xy(250,150)
    print m.get_x_range(5)
    print m.get_y_range(3)
    x,y = m.get_pos_from_xy(250,150)
    m.set_grid([x,y],4)
    m.print_it(False)
    m.update()
    m.print_it(False)
    m.add_to_grid(m.get_pos_from_xy(250,150),0.5)
    m.print_it(True)

