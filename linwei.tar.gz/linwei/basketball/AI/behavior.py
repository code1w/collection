# -*- coding:gb2312 -*-
import random
import math
import pygame
import fsmbase
import player
import copy

state = fsmbase.state
StateMachine = fsmbase.StateMachine



def dist(xy1,xy2):
    '''get distance from xyz1 to xyz2'''
    return math.sqrt((xy1[0] - xy2[0])*(xy1[0] - xy2[0]) +\
                     (xy1[1] - xy2[1])*(xy1[1] - xy2[1]))

class Behavior:
    is_finish = False
    last_frame = 0
    def __init__ (self, player):
        self.player = player
        self.fsm = StateMachine(self)
        self.tar_pos = None
        self.barrier_list = []
        self.ignore_id_list = []
        self.ignore_times = 20

    def update (self):
        self.fsm.update()
        self.player.update()
        new_list = []
        for id_times in self.ignore_id_list:
            if id_times[1] > 0:
                id_times[1] -= 1
                new_list.append(id_times)
        self.ignore_id_list = new_list
        #if self.player.ID() == 2:
        #    self.player.get_player_sprite().set_state_effect(str(self.tar_pos),5)

    def get_fsm(self):
        return self.fsm

    def handlemsg (self, tel):
        self.StateMachine.HandleMessage(tel)

    def set_tar_pos(self, tar_pos):
        pos = copy.copy(tar_pos)
        half_l,half_w = self.player.get_const_attrib().lwh[0] / 2.0, self.player.get_const_attrib().lwh[1] / 2.0
        scene_w,scene_h = self.player.get_scene_wh()
        if pos[0] < half_l:
            pos[0] = half_l
        elif pos[0] >= scene_w - half_l:
            pos[0] = scene_w - half_l - 1
        if pos[1] < half_w:
            pos[1] = half_w
        elif pos[1] >= scene_h - half_w:
            pos[1] = scene_h - half_w - 1
        self.tar_pos = pos

#--------------------------------------------
#behaviours
#--------------------------------------------

class Shoot(state):
    instance = None
    can_break = False
    @staticmethod
    def get_instance():
        if not Shoot.instance:
            Shoot.instance = Shoot()
        return Shoot.instance

    def enter(self, behavior):
        behavior.is_finish = False
        self.shoot_last_frame = random.randint(8,14)
        behavior.player.get_ctrl_fsm().change_state(player.PreShoot.get_instance())

    def execute(self, behavior):
        if self.shoot_last_frame > 0:
            self.shoot_last_frame -= 1
        else:
            behavior.is_finish = True
            behavior.player.get_ctrl_fsm().change_state(player.Wait.get_instance())

    def exit(self, behavior):
        behavior.is_finish = True

class Pass(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Pass.instance:
            Pass.instance = Pass()
        return Pass.instance

    def enter(self, behavior):
        behavior.is_finish = False
        self.last_frame = random.randint(2,10)
        behavior.player.get_ctrl_fsm().change_state(player.PrePass.get_instance())

    def execute(self, behavior):
        self.last_frame -= 1
        if behavior.tar_pos:
            behavior.player.set_direction(behavior.tar_pos)
        else:
            behavior.player.clear_move()
        if self.last_frame == 0:
            behavior.player.get_ctrl_fsm().change_state(player.Wait.get_instance())
            behavior.is_finish = True

    def exit(self, behavior):
        pass

class Hit(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Hit.instance:
            Hit.instance = Hit()
        return Hit.instance

    def enter(self, behavior):
        behavior.last_frame = 2
        behavior.is_finish = False
        behavior.player.get_ctrl_fsm().change_state(player.Attack.get_instance())

    def execute(self, behavior):
        #what should next state be
        if behavior.tar_pos:
            behavior.player.set_direction(behavior.tar_pos)
        else:
            behavior.player.clear_move()
        if behavior.last_frame == 1:
            behavior.player.get_ctrl_fsm().change_state(player.Wait.get_instance())
        elif behavior.last_frame == 0:
            behavior.is_finish = True
            behavior.get_fsm().change_state(StraightMove.get_instance())
        behavior.last_frame -= 1
        #change state to wait?

    def exit(self, behavior):
        pass

class ChaseBall(state):
    instance = None
    @staticmethod
    def get_instance():
        if not ChaseBall.instance:
            ChaseBall.instance = ChaseBall()
        return ChaseBall.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.player.get_ctrl_fsm().change_state(player.Move.get_instance())

    def execute(self, behavior):
        if behavior.tar_pos:
            behavior.player.set_direction(behavior.tar_pos)
        else:
            behavior.player.clear_move()
        #the state will change? change state to stop when he own the ball?

    def exit(self, behavior):
        pass

class StraightMove(state):
    instance = None
    @staticmethod
    def get_instance():
        if not StraightMove.instance:
            StraightMove.instance = StraightMove()
        return StraightMove.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.player.get_ctrl_fsm().change_state(player.Move.get_instance())

    def execute(self, behavior):
        if behavior.tar_pos:
            behavior.player.set_direction(behavior.tar_pos)
        else:
            behavior.player.clear_move()
        if math.sqrt((behavior.tar_pos[0] - behavior.player.xyz[0]) * (behavior.tar_pos[0] - behavior.player.xyz[0]) + (behavior.tar_pos[1] - behavior.player.xyz[1]) * (behavior.tar_pos[1] - behavior.player.xyz[1])) < behavior.player.get_attrib().speed:
            #behavior.get_fsm().change_state(Stop.get_instance())
            behavior.is_finish = True

    def exit(self, behavior):
        pass
        

class AvoidMove(state):
    instance = None
    @staticmethod
    def get_instance():
        if not AvoidMove.instance:
            AvoidMove.instance = AvoidMove()
        return AvoidMove.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.player.get_ctrl_fsm().change_state(player.Move.get_instance())

    def execute(self, behavior):
        if behavior.is_finish: return
        my_face_orient = copy.copy(behavior.player.get_attrib().face_orient)
        if my_face_orient[0] != 0 and my_face_orient[1] != 0:
            my_speed = behavior.player.get_attrib().speed * math.sqrt(2)
        else:
            my_speed = behavior.player.get_attrib().speed
        if behavior.tar_pos:
            is_speed_up = False
            for barrier_attrib,barrier_r in behavior.barrier_list:
                p_id = barrier_attrib.id
                if barrier_attrib.face_orient[0] != 0 and barrier_attrib.face_orient[1] != 0:
                    barrier_speed = barrier_attrib.speed * math.sqrt(2)
                else:
                    barrier_speed = barrier_attrib.speed
                barrier_pos = [0,0]
                barrier_pos[0] = barrier_attrib.xyz[0] + barrier_attrib.face_orient[0] * barrier_speed - my_face_orient[0] * my_speed
                barrier_pos[1] = barrier_attrib.xyz[1] + barrier_attrib.face_orient[1] * barrier_speed - my_face_orient[0] * my_speed
                if dist(behavior.player.xyz,barrier_pos) < barrier_r:
                    ignored = False
                    for id,times in behavior.ignore_id_list:
                        if id == p_id:
                            ignored = True
                            break
                    if ignored:
                        continue
                    speed = behavior.player.get_attrib().speed
                    if behavior.tar_pos[0] - behavior.player.xyz[0] == 0.0:
                        x_bias = 0.0
                    else:
                        x_bias = (behavior.tar_pos[0] - behavior.player.xyz[0]) / math.fabs(behavior.tar_pos[0] - behavior.player.xyz[0])
                    if barrier_pos[1] != behavior.player.xyz[1]:
                        y_bias = -(barrier_pos[1] - behavior.player.xyz[1]) / math.fabs(barrier_pos[1] - behavior.player.xyz[1])
                    else:
                        y_bias = 1
                    scene_w,scene_h = behavior.player.get_scene_wh()
                    new_x = behavior.player.xyz[0] + x_bias * speed
                    new_y = behavior.player.xyz[1] + y_bias * speed
                    player_l,player_w = behavior.player.get_const_attrib().lwh[0] / 2.0,behavior.player.get_const_attrib().lwh[1] / 2.0
                    if new_x >= scene_w - player_l or new_x <= player_l or new_y >= scene_h - player_w or new_y <= player_w:
                        behavior.ignore_id_list.append([p_id,behavior.ignore_times])
                        new_x = behavior.tar_pos[0]
                        new_y = behavior.tar_pos[1]
                    behavior.player.set_direction([new_x,new_y])
                    #behavior.player.get_player_sprite().set_state_effect('barrier' + str([int(barrier_pos[0]),int(barrier_pos[1]),int(behavior.player.xyz[0]),int(behavior.player.xyz[1])]),5)
                    break
                else:
                    behavior.player.set_direction(behavior.tar_pos)
                    #behavior.player.get_player_sprite().set_state_effect('no barrier',5)
        else:
            behavior.player.clear_move()
        if math.sqrt((behavior.tar_pos[0] - behavior.player.xyz[0]) * (behavior.tar_pos[0] - behavior.player.xyz[0]) + (behavior.tar_pos[1] - behavior.player.xyz[1]) * (behavior.tar_pos[1] - behavior.player.xyz[1])) < behavior.player.get_attrib().speed:
            #behavior.get_fsm().change_state(Stop.get_instance())
            behavior.is_finish = True

    def exit(self, behavior):
        pass

class Stop(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Stop.instance:
            Stop.instance = Stop()
        return Stop.instance

    def enter(self, behavior):
        behavior.player.get_ctrl_fsm().change_state(player.Wait.get_instance())

    def execute(self, behavior):
        pass

    def exit(self, behavior):
        pass

class Jump(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Jump.instance:
            Jump.instance = Jump()
        return Jump.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.last_frame = 1
        behavior.player.get_ctrl_fsm().change_state(player.Jump.get_instance())

    def execute(self, behavior):
        if behavior.last_frame == 0:
            behavior.get_fsm().change_state(Stop.get_instance())
        #if the ball back to the ground, change is_finish?
        behavior.last_frame -= 1

    def exit(self, behavior):
        pass

class AskBall(state):
    instance = None
    @staticmethod
    def get_instance():
        if not AskBall.instance:
            AskBall.instance = AskBall()
        return AskBall.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.begin_ask_ball = True
        behavior.player.get_ctrl_fsm().change_state(player.AskForPass.get_instance())

    def execute(self, behavior):
        #if player get the ball, or someone steal the ball
        #    player.get_fsm().change_state(player.Wait.get_instance())
        #set the ball keeper in the team
        #change is_finish?
        if behavior.begin_ask_ball:
            behavior.begin_ask_ball = False
            return
        behavior.player.get_ctrl_fsm().change_state(player.Wait.get_instance())
        if behavior.player.get_attrib().have_ball:
            behavior.is_finish = True
    def exit(self, behavior):
        pass

class SpeedUpRun(state):
    instance = None
    @staticmethod
    def get_instance():
        if not SpeedUpRun.instance:
            SpeedUpRun.instance = SpeedUpRun()
        return SpeedUpRun.instance

    def enter(self, behavior):
        behavior.is_finish = False
        behavior.last_frame = 1
        behavior.player.get_ctrl_fsm().change_state(player.SpeedUpRun.get_instance())

    def execute(self, behavior):
        if behavior.tar_pos:
            behavior.player.set_direction(behavior.tar_pos)
        else:
            behavior.player.clear_move()
        if behavior.last_frame == 0:
            behavior.get_fsm().change_state(StraightMove.get_instance())
        #if the ball back to the ground, change is_finish?
        behavior.last_frame -= 1
        

    def exit(self, behavior):
        pass

if __name__ == "__main__":
    pass