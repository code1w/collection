
# -*- coding:gb2312 -*-
import behavior
import player
import random
import copy
import fsmbase
import sys
import math
import aimap
import sceneglobal

sys.path.append("..")
import sceneglobal

state = fsmbase.state
sceneParam = sceneglobal.sceneParam

class Agent:
    is_finish = False
    offset = 30
    speed_offset_rate = 1.2
    map_dict = {}
    can_jump = 0
    last_frame = 0
    shoot_frame = 0
    positive = False
    counter = 0

    def __init__ (self, behavior, attack_side):
        v = behavior.player.get_const_attrib().init_jump_v / 5
        self.g = sceneParam.gravity / 5
        self.can_jump = - v * v / 2.0 / self.g * 5
        self.behavior = behavior
        self.fsm = fsmbase.StateMachine(self)
        self.attrib = None
        self.attrib_index = -1
        self.defence_enemy_index = -1
        self.attack_side = attack_side
        self.map_dict = {}
        self.ai_map = None
        self.x_range = []
        self.y_range = []
        self.teammate_id_list = []
        self.agent_list = []
        self.enemy_index_list = []
        self.Attack_lastXY = (0,0)
        self.strategy = None
        self.tar_pos = None

        if attack_side == 1:
            self.defend_basket = sceneParam.basket1_pos
            self.attack_basket = sceneParam.basket2_pos
        else:
            self.defend_basket = sceneParam.basket2_pos
            self.attack_basket = sceneParam.basket1_pos

    def update (self):
        self.behavior.update()
        self.fsm.update()

    def get_fsm(self):
        return self.fsm

    def handlemsg (self, tel):
        self.StateMachine.HandleMessage(tel)

    def set_tar_pos(self, tar_pos):
        pos = copy.copy(tar_pos)
        half_l,half_w = self.behavior.player.get_const_attrib().lwh[0] / 2.0,self.behavior.player.get_const_attrib().lwh[1] / 2.0
        scene_w,scene_h = self.behavior.player.get_scene_wh()
        if pos[0] < half_l:
            pos[0] = half_l
        elif pos[0] >= scene_w - half_l:
            pos[0] = scene_w - half_l - 1
        if pos[1] < half_w:
            pos[1] = half_w
        elif pos[1] >= scene_h - half_w:
            pos[1] = scene_h - half_w - 1
        self.tar_pos = pos


def count_time(player_speed, ball_speed, player_pos, ball_pos):
    p1 = player_pos
    p0 = ball_pos
    a = p0[0] - p1[0]
    b = ball_speed[0]
    c = p0[1] - p1[1]
    d = ball_speed[1]
    s = player_speed
    aa = b * b + d * d - s * s
    bb = 2 * a * b + 2 * c * d
    cc = a * a + c * c
    if aa == 0:
        if bb == 0:
            return 10000
        else:
            return cc / bb
    t = 10000
    if bb * bb - 4 * aa * cc >= 0:
        t = (-math.sqrt(bb * bb - 4 * aa * cc) - bb )/ 2.0 / aa
    if t < 0:
        t = 10000
    return t

class Rebound(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Rebound.instance:
            Rebound.instance = Rebound()
        return Rebound.instance

    def enter(self, agent):
        agent.is_finish = False
        p0 = agent.attrib[6].xyz
        ball_speed = [agent.attrib[6].speed[0] / 5, agent.attrib[6].speed[1] / 5, agent.attrib[6].speed[2] / 5]
        agent.speed_offset_rate = 3
        ball_acc = agent.attrib[6].acceleration
        p1 = agent.behavior.player.get_attrib().xyz
        a = p0[0] - p1[0]
        b = ball_speed[0] * agent.speed_offset_rate
        c = p0[1] - p1[1]
        d = ball_speed[1] * agent.speed_offset_rate
        s = agent.behavior.player.get_attrib().speed
        aa = b * b + d * d - s * s
        bb = 2 * a * b + 2 * c * d
        cc = a * a + c * c
        t = -1
        if aa == 0:
            if bb != 0:
                t = cc / bb
        else:
            if bb * bb - 4 * aa * cc >= 0:
                t = (-math.sqrt(bb * bb - 4 * aa * cc) - bb )/ 2.0 / aa
        if t < 0:
            agent.get_fsm().change_state(CatchBall.get_instance())
        else:
            g = agent.g
            v0 = ball_speed[2] * 5
            h = agent.can_jump - p0[2]
            if p0[2] + v0 * t + 0.5 * g * t * t >= agent.can_jump:
                t = 0.5 * (-2 * v0 / g + math.sqrt(4 * v0 * v0 / g / g + 8 * h / g))
            agent.set_tar_pos([p0[0] + ball_speed[0] * t, p0[1] + ball_speed[1] * t])
            agent.behavior.set_tar_pos(agent.tar_pos)
            agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())
#            agent.last_frame = t
            agent.last_frame = 0

    def execute(self, agent):
        if agent.is_finish:
            return
        if agent.behavior.is_finish:
            if agent.behavior.player.get_attrib().have_ball:
                agent.is_finish = True
            elif agent.last_frame < agent.shoot_frame:
                agent.behavior.get_fsm().change_state(behavior.Jump.get_instance())
        agent.last_frame -= 1
        if agent.last_frame < -10:
            agent.get_fsm().change_state(CatchBall.get_instance())

    def exit(self, agent):
        pass

def in_back_of_basket(l,w,xyz,basket_pos,side):
    valid_ratio_back_y = 0.7
    if (basket_pos[0] - xyz[0]) * side < 0 and\
       xyz[1] > w * (1.0 - valid_ratio_back_y) and xyz[1] < w * valid_ratio_back_y:
        return True
    else:
        return False

class Attack(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Attack.instance:
            Attack.instance = Attack()
        return Attack.instance

    def enter(self, agent):
        agent.Attack_lastXY = (-1,-1)
        self.execute(agent)

    def getDictOgnVal (self, agent, key, xy):
        return agent.map_dict[key].get_grid(xy[0], xy[1])

    def getDictVal (self, agent, key, xy):
        return agent.map_dict[key].get_grid(xy[0], xy[1]) * agent.strategy.attack[key]

    def execute(self, agent):
        state = agent.behavior.get_fsm().current_state
        barrier_r = agent.behavior.player.get_const_attrib().attack_lwh[0] + agent.behavior.player.get_const_attrib().lwh[0]
        if state == behavior.AvoidMove.get_instance():
            agent.behavior.barrier_list = []
            for attrib_index in agent.enemy_index_list:
                agent.behavior.barrier_list.append([agent.attrib[attrib_index],barrier_r])
        mapsList = []
        mapsValList = []
        for key,val in agent.map_dict.items():
            if math.fabs(agent.strategy.attack[key]) < 0.001:
                continue
            if key == 'player_dist_map' :
                mapsList.append(agent.map_dict[key][agent.behavior.player.ID()])
                mapsValList.append(agent.strategy.attack[key])
            else:
                mapsList.append(agent.map_dict[key])
                mapsValList.append(agent.strategy.attack[key])

        ai_map = aimap.AIMap(800,200,0.0)
        if agent.x_range[0] > 0 or agent.x_range[1] < 800 or agent.y_range[0] > 0 or agent.y_range[1] < 200:
            ai_map.set_min_grid(0.0)
        maxList = []
        max_x, max_y, max_v = 0,0, -100
        if agent.attack_side == 1: #�޵�ͼʱ�����λ��
            xr, yr = (100,700), (30,170)
        else:
            xr, yr = (100,700), (30,170)
        xyz = agent.behavior.player.xyz #ȡ���λ��
        ai_map_xy = ai_map.get_pos_from_xy(xyz[0], xyz[1])
        if agent.attack_side>0:
            basket_pos = sceneglobal.sceneParam.basket2_pos
        else:
            basket_pos = sceneglobal.sceneParam.basket1_pos
        basket_grid_pos = mapsList[0].get_pos_from_xy(basket_pos[0],basket_pos[1])
        if len(mapsList)>0: #mapͳ��
            x_range = mapsList[0].get_pos_from_xy(agent.x_range[0],agent.x_range[1])
            y_range = mapsList[0].get_pos_from_xy(agent.y_range[0],agent.y_range[1])
            for x in range(x_range[0],x_range[1]):
                for y in range(y_range[0],y_range[1]):
                    x_len_to_basket = math.fabs(basket_grid_pos[0] - x)
                    y_len_to_basket = math.fabs(basket_grid_pos[1] - y)
                    if not(\
                        (x_len_to_basket <= agent.strategy.max_grid_x and y_len_to_basket <= agent.strategy.max_grid_y) and\
                        (x_len_to_basket >= agent.strategy.min_grid_x or y_len_to_basket >= agent.strategy.min_grid_y)\
                          ):
                        v = 0
                        ai_map.set_grid([x,y], v)
                        continue
                    v = 0
                    for id in range(len(mapsList)):
                        v += mapsList[id].get_grid(x,y) * mapsValList[id]
                    if v > max_v:
                        max_x, max_y, max_v = x, y, v
                        maxList = [(max_x, max_y, max_v)]
                    elif v == max_v:
                        maxList.append((max_x, max_y, max_v))
                    ai_map.set_grid([x,y], v)
            ai_map_tar_xy = ai_map.get_pos_from_xy(agent.behavior.tar_pos[0], agent.behavior.tar_pos[1])
            v = 0
            for id in range(len(mapsList)):
                v += mapsList[id].get_grid(ai_map_tar_xy[0],ai_map_tar_xy[1]) * mapsValList[id]
            if math.fabs(v - max_v) < 0.001:
                max_x, max_y = ai_map_tar_xy[0], ai_map_tar_xy[1]
            else:
                sum_val_dict = agent.map_dict['attack_basket_dist_map']
                max_v = 0.0
                for maxitem in maxList:
                    if sum_val_dict.get_grid(maxitem[0],maxitem[1])>max_v:
                        max_x, max_y = maxitem[0], maxitem[1]
            xr = mapsList[0].get_x_range(max_x)
            yr = mapsList[0].get_x_range(max_y)
        #�Ƚϵ�ǰλ������һλ�÷�ֵ
        sum_val_dict = agent.strategy.attack['attack_basket_dist_map']+agent.strategy.attack['enemy_dist_map']
        if sum_val_dict == 0.0: sum_val_dict = 1.0
        cur_v = (self.getDictVal(agent, 'attack_basket_dist_map', ai_map_xy)+self.getDictVal(agent, 'enemy_dist_map', ai_map_xy)) / \
                (sum_val_dict) #��ǰλ��ֵ
        attrib = agent.behavior.player.get_attrib()#���״̬
        const_attrib = agent.behavior.player.get_const_attrib()#���״̬
        next_x,next_y = attrib.xyz[0] + attrib.face_orient[0]*attrib.speed,attrib.xyz[1] + attrib.face_orient[1]*attrib.speed
        ai_map_xy = ai_map.get_pos_from_xy(next_x,next_y)
        if in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,[next_x,next_y,xyz[2]],basket_pos,agent.attack_side):
            next_v = 0.0
        else:
            next_v = (self.getDictVal(agent, 'attack_basket_dist_map', ai_map_xy)+self.getDictVal(agent, 'enemy_dist_map', ai_map_xy)) / \
                     (sum_val_dict)
        dxy = basket_pos[0] - xyz[0], basket_pos[1] - xyz[1]
        face_orient = attrib.face_orient #�������
        if face_orient[0] * agent.attack_side <0:
            cur_v -= 0.2
        state_set = 0
        ai_map_tar_xy = ai_map.get_pos_from_xy(agent.behavior.tar_pos[0],agent.behavior.tar_pos[1])
        if cur_v>agent.strategy.shoot_val and (next_v < cur_v or (ai_map_tar_xy[0] == ai_map_xy[0] and ai_map_tar_xy[1] == ai_map_xy[1])):
            if state != behavior.Shoot.get_instance() and state != behavior.Pass.get_instance():
                if dxy[0] * face_orient[0] < 0 or dxy[1] * face_orient[1] < 0 or\
                   (math.fabs(dxy[0]) < sceneglobal.sceneParam.scene_w * 0.1 and (dxy[0] * face_orient[0] < 0 or dxy[1] * face_orient[1] <= 0)):
                    agent.set_tar_pos([basket_pos[0], basket_pos[1]])
                    agent.behavior.set_tar_pos(agent.tar_pos)
                    agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())
                    return
                else:
                    agent.behavior.get_fsm().change_state(behavior.Shoot.get_instance())
                    state_set = 1
        if state_set == 0:
            #�����ж�
            if agent.attrib[agent.attrib_index].have_ball :
                if state != behavior.Pass.get_instance() and state != behavior.Shoot.get_instance():
                    if agent.map_dict.has_key('pass_map'):
                        #�������������⣬δ�����
                        pass_map = agent.map_dict['pass_map']
                        cxy = ai_map.get_pos_from_xy(xyz[0], xyz[1])
                        cur_score = self.getDictOgnVal(agent, 'attack_basket_dist_map', cxy)*4.0 + \
                                    self.getDictOgnVal(agent, 'enemy_dist_map', cxy)*3.0
                        max_score = cur_score
                        for pid in agent.teammate_id_list:
                            if agent.attrib[pid].is_human_control: continue
                            fxyz = agent.attrib[pid].xyz
                            fxy = ai_map.get_pos_from_xy(fxyz[0], fxyz[1])
                            p_score = self.getDictOgnVal(agent, 'attack_basket_dist_map', fxy)*4.0 + \
                                      self.getDictOgnVal(agent, 'enemy_dist_map', fxy)*3.0
                            if p_score - 1 <= max_score: continue
                            if pass_map.get_grid(*ai_map.get_pos_from_xy(fxyz[0], fxyz[1])) >= agent.strategy.pass_val and \
                                math.fabs(xyz[0]-fxyz[0])+math.fabs(xyz[1]-fxyz[1]) > 0:
                                max_score = p_score
                                be_passed_id = agent.attrib[pid].id
                                state_set = 1
            if state_set == 1:
                for a in agent.agent_list:
                    if a.behavior.player.ID() == be_passed_id:
                        a.get_fsm().change_state(AskBall.get_instance())
                        break
            if agent.Attack_lastXY[0] != max_x or agent.Attack_lastXY[1] != max_y:
                agent.Attack_lastXY = max_x,max_y
                agent.set_tar_pos([random.randint(xr[0],xr[1]), random.randint(yr[0],yr[1])])
                if in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,agent.tar_pos,basket_pos,agent.attack_side):
                    if not in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,[xr[0],yr[0]],basket_pos,agent.attack_side):
                        agent.set_tar_pos([xr[0],yr[0]])
                    elif not in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,[xr[1],yr[0]],basket_pos,agent.attack_side):
                        agent.set_tar_pos([xr[1],yr[0]])
                    elif not in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,[xr[1],yr[1]],basket_pos,agent.attack_side):
                        agent.set_tar_pos([xr[1],yr[1]])
                    elif not in_back_of_basket(sceneglobal.sceneParam.scene_w,sceneglobal.sceneParam.scene_h,[xr[0],yr[1]],basket_pos,agent.attack_side):
                        agent.set_tar_pos([xr[0],yr[1]])
                agent.behavior.set_tar_pos(agent.tar_pos)
                agent.behavior.get_fsm().change_state(behavior.AvoidMove.get_instance())

        agent.ai_map = ai_map

    def exit(self, agent):
        pass

class SupportAttack(state):
    instance = None
    @staticmethod
    def get_instance():
        if not SupportAttack.instance:
            SupportAttack.instance = SupportAttack()
        return SupportAttack.instance

    def enter(self, agent):
        agent.Attack_lastXY = (-1,-1)
        self.execute(agent)

    def execute(self, agent):
        mapsList = []
        mapsValList = []
        for key,val in agent.map_dict.items():
            if key == 'player_dist_map' :
                mapsList.append(agent.map_dict[key][agent.behavior.player.ID()])
                mapsValList.append(agent.strategy.support_attack[key])
            else:
                mapsList.append(agent.map_dict[key])
                mapsValList.append(agent.strategy.support_attack[key])

        ai_map = aimap.AIMap(800,200,0.0)
        if agent.x_range[0] > 0 or agent.x_range[1] < 800 or agent.y_range[0] > 0 or agent.y_range[1] < 200:
            ai_map.set_min_grid(0.0)
        max_x, max_y, max_v = 0,0, -100
        if agent.attack_side == 1:
            xr, yr = (100,700), (30,170)
        else:
            xr, yr = (100,700), (30,170)
        if agent.attack_side>0:
            basket_pos = sceneglobal.sceneParam.basket2_pos
        else:
            basket_pos = sceneglobal.sceneParam.basket1_pos
        basket_grid_pos = mapsList[0].get_pos_from_xy(basket_pos[0],basket_pos[1])
        if len(mapsList)>0:
            x_range = mapsList[0].get_pos_from_xy(agent.x_range[0],agent.x_range[1])
            y_range = mapsList[0].get_pos_from_xy(agent.y_range[0],agent.y_range[1])
            for x in range(x_range[0],x_range[1]):
                for y in range(y_range[0],y_range[1]):
                    x_len_to_basket = math.fabs(basket_grid_pos[0] - x)
                    y_len_to_basket = math.fabs(basket_grid_pos[1] - y)
                    if not(\
                        (x_len_to_basket <= agent.strategy.max_grid_x and y_len_to_basket <= agent.strategy.max_grid_y) and\
                        (x_len_to_basket >= agent.strategy.min_grid_x or y_len_to_basket >= agent.strategy.min_grid_y)\
                          ):
                        v = 0
                        ai_map.set_grid([x,y], v)
                        continue
                    v = 0
                    for id in range(len(mapsList)):
                        v += mapsList[id].get_grid(x,y) * mapsValList[id]
                    if v > max_v:
                        max_x, max_y, max_v = x, y, v
                    ai_map.set_grid([x,y], v)
            xr = mapsList[0].get_x_range(max_x)
            yr = mapsList[0].get_x_range(max_y)
        if (agent.Attack_lastXY[0] != max_x or agent.Attack_lastXY[1] != max_y):
            agent.Attack_lastXY = max_x,max_y
            agent.set_tar_pos([random.randint(xr[0],xr[1]), random.randint(yr[0],yr[1])])
            agent.behavior.set_tar_pos(agent.tar_pos)
            agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())
            agent.counter = 4
        agent.counter -= 1

        agent.ai_map = ai_map

    def exit(self, agent):
        pass

class AskBall(state):
    instance = None
    @staticmethod
    def get_instance():
        if not AskBall.instance:
            AskBall.instance = AskBall()
        return AskBall.instance

    def enter(self, agent):
        agent.is_finish = False
        agent.behavior.get_fsm().change_state(behavior.AskBall.get_instance())

    def execute(self, agent):
        if agent.behavior.is_finish:
            agent.is_finish = True

    def exit(self, agent):
        pass

class ReturnHome(state):
    instance = None
    @staticmethod
    def get_instance():
        if not ReturnHome.instance:
            ReturnHome.instance = ReturnHome()
        return ReturnHome.instance

    def enter(self, agent):
        agent.is_finish = False
        agent.behavior.set_tar_pos(agent.tar_pos)
        agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())

    def execute(self, agent):
        if agent.behavior.is_finish:
            agent.is_finish = True

    def exit(self, agent):
        pass

class FrontDefend(state):
    instance = None
    @staticmethod
    def get_instance():
        if not FrontDefend.instance:
            FrontDefend.instance = FrontDefend()
        return FrontDefend.instance

    def enter(self, agent):
        agent.is_finish = False
        agent.set_tar_pos(agent.attrib[agent.defence_enemy_index].xyz)
        agent.behavior.set_tar_pos(agent.tar_pos)
        agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())

    def execute(self, agent):
        #the tar_pos save the position of the player which the agent should defend
        ball = agent.attrib[6].xyz
        agent.set_tar_pos(agent.attrib[agent.defence_enemy_index].xyz)
        tar_pos = [0, 0]
        dx = agent.tar_pos[0] - ball[0]
        dy = agent.tar_pos[1] - ball[1]
        distance = math.sqrt(dx * dx + dy * dy)
        offsetx = agent.offset * dx / distance
        offsety = agent.offset * dy / distance
        tar_pos[0] = agent.tar_pos[0] - offsetx
        tar_pos[1] = agent.tar_pos[1] - offsety
        agent.behavior.set_tar_pos(tar_pos)

    def exit(self, agent):
        pass

class Defend(state):
    instance = None
    @staticmethod
    def get_instance():
        if not Defend.instance:
            Defend.instance = Defend()
        return Defend.instance

    def enter(self, agent):
        agent.is_finish = False
        agent.set_tar_pos(agent.attrib[agent.defence_enemy_index].xyz)
        agent.behavior.set_tar_pos(agent.tar_pos)
        agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())

    def execute(self, agent):
        #the tar_pos save the position of the player which the agent should defend
        basket = agent.defend_basket
        if agent.positive:
            agent.set_tar_pos(agent.attrib[6].owner_xyz)
        else:
            agent.set_tar_pos(agent.attrib[agent.defence_enemy_index].xyz)
        tar_pos = [0, 0]
        dx = agent.tar_pos[0] - basket[0]
        dy = agent.tar_pos[1] - basket[1]
        distance = math.sqrt(dx * dx + dy * dy)
        if distance == 0 or agent.attrib[agent.defence_enemy_index].have_ball:
            offsetx = 0
            offsety = 0
        else:
            offsetx = agent.offset * dx / distance
            offsety = agent.offset * dy / distance
        tar_pos[0] = agent.tar_pos[0] - offsetx
        tar_pos[1] = agent.tar_pos[1] - offsety
        agent.behavior.set_tar_pos(tar_pos)
        dx = agent.tar_pos[0] - agent.behavior.player.get_attrib().xyz[0]
        dy = agent.tar_pos[1] - agent.behavior.player.get_attrib().xyz[1]
        distance = math.sqrt(dx * dx + dy * dy)
        if distance == 0:
            offsetx = 0
            offsety = 0
        else:
            offsetx = agent.offset * dx / distance
            offsety = agent.offset * dy / distance
        tar_pos[0] = agent.tar_pos[0] + offsetx
        tar_pos[1] = agent.tar_pos[1] + offsety

        if agent.positive and ((get_distance(agent.attrib[6].xyz, agent.behavior.player.get_attrib().xyz) < agent.strategy.attack_ball_dist and agent.behavior.get_fsm().current_state is not behavior.Hit.get_instance())):
            agent.behavior.set_tar_pos(tar_pos)
            agent.behavior.get_fsm().change_state(behavior.Hit.get_instance())

    def exit(self, agent):
        pass

def get_distance(pos, tar_pos):
    return math.sqrt((pos[0] - tar_pos[0])*(pos[0] - tar_pos[0]) + (pos[1] - tar_pos[1]) * (pos[1] - tar_pos[1]))

class CatchBall(state):
    instance = None
    @staticmethod
    def get_instance():
        if not CatchBall.instance:
            CatchBall.instance = CatchBall()
        return CatchBall.instance

    def enter(self, agent):
        agent.is_finish = False
        p0 = agent.attrib[6].xyz
        ball_speed = [agent.attrib[6].speed[0] / 5.0, agent.attrib[6].speed[1] / 5.0, agent.attrib[6].speed[2] / 5.0]
        agent.speed_offset_rate = 3
        ball_acc = agent.attrib[6].acceleration
        p1 = agent.behavior.player.get_attrib().xyz
        a = p0[0] - p1[0]
        b = ball_speed[0]
        c = p0[1] - p1[1]
        d = ball_speed[1]
        s = agent.behavior.player.get_attrib().speed
        aa = b * b + d * d - s * s
        bb = 2 * a * b + 2 * c * d
        cc = a * a + c * c
        t = -1
        if aa == 0:
            if bb != 0:
                t = cc / bb
        else:
            if bb * bb - 4 * aa * cc >= 0:
                t = (-math.sqrt(bb * bb - 4 * aa * cc) - bb )/ 2.0 / aa
        if t < 0:
            agent.set_tar_pos(p0)
            agent.behavior.set_tar_pos(p0)
            agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())
            agent.counter = 0
        else:
            g = agent.g
            v0 = ball_speed[2] * 5
            h = agent.can_jump - p0[2]
            if p0[2] + v0 * t + 0.5 * g * t * t >= agent.can_jump:
                t = 0.5 * (-2 * v0 / g + math.sqrt(4 * v0 * v0 / g / g + 8 * h / g))
            agent.set_tar_pos([p0[0] + ball_speed[0] * t, p0[1] + ball_speed[1] * t])
            agent.behavior.set_tar_pos(agent.tar_pos)
            agent.behavior.get_fsm().change_state(behavior.StraightMove.get_instance())

    def execute(self, agent):
        if agent.is_finish:
            return
        if agent.behavior.player.get_attrib().have_ball:
            agent.is_finish = True
        agent.counter += 1
        if agent.counter >= 5:
            agent.counter = 0
            agent.get_fsm().change_state(CatchBall.get_instance())

    def exit(self, agent):
        agent.counter = 0

#not needed at present
class ChaseHit(state):
    instance = None
    @staticmethod
    def get_instance():
        if not ChaseHit.instance:
            ChaseHit.instance = ChaseHit()
        return ChaseHit.instance

    def enter(self, agent):
        pass

    def execute(self, agent):
        pass

    def exit(self, agent):
        pass
