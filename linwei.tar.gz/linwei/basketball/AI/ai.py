import pygame
import ai

import sys
import copy
import math
import fsmbase
import entbase
import player
import random

sys.path.append("..")
import scenesprite
import mybasesprite
import playersprite

import behavior
import agent
import team

class AI:
    keys = []
    key_sta = []
    __scene = None
    teamObj = None
    ai_playerObj = []

    #----for test
    ai_behaviorObj = []
    ai_teamObj = None
    ai_agentObj = []
    #----

    def __init__(self, scene, teamobj, keys, diff):
        self.__scene = scene
        self.keys = keys
        self.key_sta = []
        self.ai_playerObj = []
        self.ai_behaviorObj = []
        self.ai_agentObj = []
        self.ai_teamObj = None
        self.pre_kick = False
        self.map_index = -2
        for n in range(len(keys)):
            self.key_sta.append(0)
        self.teamObj =  teamobj
        pygame.init()

        pl_list = teamobj.get_player_list()
        for obj in pl_list:
            p = player.Player(self, obj, obj.get_id(), obj.get_center_xyz(), obj.get_lwh(), len(pl_list))
            p.state_setup(player.Wait.get_instance())
            b = behavior.Behavior(p)
            b.get_fsm().change_state(behavior.Stop.get_instance())
            a = agent.Agent(b,teamobj.get_side())
            self.ai_agentObj.append(a)
            self.ai_behaviorObj.append(b)
            self.ai_playerObj.append(p)
            #entbase.EntityMgr.register(p)
        t = team.Team(teamobj.get_id(),self,teamobj.get_side(),diff,self.ai_agentObj)
        self.ai_teamObj = t
        if teamobj.is_human_control:
            self.__cpu = 0
        else:
            self.__cpu = 1
        self.is_human_control = teamobj.is_human_control

    def clear_ball_have_goal_defend(self):
        self.__scene.get_ball().have_goal_defend = False

    def clear_ball_have_goal_attack(self):
        self.__scene.get_ball().have_goal_attack = False

    def __del__(self):
        entbase.EntityMgr.entities = {}

    def render_map(self,m):
        self.__scene.render_map(m)

    def get_scene_wh(self):
        return self.__scene.get_scene_wh()

    def show_map(self,keylist):
        if self.ai_teamObj == None:return
        if keylist[pygame.K_0] == 1:
            self.map_index = -1
        elif keylist[pygame.K_1] == 1:
            self.map_index = 1
        elif keylist[pygame.K_2] == 1:
            self.map_index = 2
        elif keylist[pygame.K_3] == 1:
            self.map_index = 3
        elif keylist[pygame.K_4] == 1:
            self.map_index = 4
        elif keylist[pygame.K_5] == 1:
            self.map_index = 5
        elif keylist[pygame.K_6] == 1:
            self.map_index = 6
        elif keylist[pygame.K_7] == 1:
            self.map_index = 7
        elif keylist[pygame.K_9] == 1:
            self.map_index = -2
        if self.map_index in [-1,6,7]:
            self.ai_teamObj.show_map_index = self.map_index
        elif self.map_index == -2:
            self.ai_teamObj.show_map_index = -2
            self.__scene.map_to_be_rendered = None
        else:
            if self.teamObj.get_id() == 10:
                self.ai_teamObj.show_map_index = self.map_index
            else:
                self.ai_teamObj.show_map_index = -2

    def post_key_event (self, event):
        self.test3()
        keylist = pygame.key.get_pressed()
        for n in range(len(self.keys)):
            key = self.keys[n]
            self.key_sta[n] = int(keylist[self.keys[n]])
        self.show_map(keylist)
        if self.__cpu==0:
            player_key_list = [[self.teamObj.get_cur_player(),self.key_sta]]
        else:
            player_key_list = []
        cur_id = self.teamObj.get_cur_player().get_id()
        for p in self.ai_playerObj:
            if self.__cpu == 1 or p.get_player_sprite() is not self.teamObj.get_cur_player():
                p_keylist = self.get_keylist_from_player(p)
                player_key_list.append([p.get_player_sprite(),p_keylist])
        self.teamObj.press_key(player_key_list)

    def get_move_keys(self,player_):
        key_ud = [0,0]
        key_lr = [0,0]
        if player_.wanna_move_orient[0] == -1: key_lr = [1,0]
        if player_.wanna_move_orient[0] ==  1: key_lr = [0,1]
        if player_.wanna_move_orient[1] == -1: key_ud = [1,0]
        if player_.wanna_move_orient[1] ==  1: key_ud = [0,1]
        return key_ud + key_lr

    def get_keylist_from_player(self,player_):
        fsm = player_.get_ctrl_fsm()
        sta = fsm.current_state
        if sta == player.Wait.get_instance():
            return [0] * len(self.keys)
        elif sta == player.Attack.get_instance():
            return self.get_move_keys(player_) + [0,0,0,1, 0,0,0]
        elif sta == player.Jump.get_instance() or sta == player.SpeedUpRun.get_instance():
            return [0,0,0,0, 0,0,1,0, 0,0,0]
        elif sta == player.InTheAir.get_instance() or sta == player.Faint.get_instance() or sta == player.Dunking.get_instance():
            return [0] * len(self.keys)
        elif sta == player.PreShoot.get_instance():
            return [0,0,0,0, 0,1,0,0, 0,0,0]
        elif sta == player.Move.get_instance():
            return self.get_move_keys(player_) + [0,0,0,0, 0,0,0]
        elif sta == player.PrePass.get_instance() or sta == player.AskForPass.get_instance():
            return self.get_move_keys(player_) + [1,0,0,0, 0,0,0]


    def reset_keys (teamobj, keys):
        self.keys = keys
        self.key_sta = []
        for n in range(len(keys)):
            self.key_sta.append(1)
        self.teamObj =  teamobj

    def get_player_attrib(self, id):
        return self.__scene.get_player_attrib(id);

    def get_all_attrib(self):
        return self.__scene.get_all_attrib();

    def get_all_realtime_attrib(self):
        return self.__scene.get_all_realtime_attrib();

    #just for test, delete it later, to be continued
    def yulinlu_test_init(self):
        self.shoot_x = random.randint(100,700)
        self.shoot_y = random.randint(20,90)
        self.have_attacked = False
        self.wait_count_down = 30
        self.pass_count_down = 10
        self.jump_count_down = 3
        self.tar_pos = [[0,0,0],[0,0,0],[0,0,0]]
        self.run_count_down = [0,0,0]
        self.cur_test_state = [player.Wait.get_instance()] * 3

    def yulinlu_dist(self,xyz1,xyz2):
        '''get distance from xyz1 to xyz2'''
        return math.sqrt((xyz1[0] - xyz2[0])*(xyz1[0] - xyz2[0]) +\
                         (xyz1[1] - xyz2[1])*(xyz1[1] - xyz2[1]) +\
                         (xyz1[2] - xyz2[2])*(xyz1[2] - xyz2[2]))

    def yulinlu_rand_test(self):
        for p in self.ai_playerObj:
            p.update()
            if self.run_count_down[p.ID()%3] > 0:
                self.run_count_down[p.ID()%3] -= 1
                if self.run_count_down[p.ID()%3] == 1:
                    p.get_ctrl_fsm().change_state(player.Wait.get_instance())
                else:
                    p.get_ctrl_fsm().change_state(self.cur_test_state[p.ID()%3])
            else:
                if p.xyz[0] > self.tar_pos[p.ID()%3][0] - 20 and p.xyz[0] < self.tar_pos[p.ID()%3][0] + 20 and\
                   p.xyz[1] > self.tar_pos[p.ID()%3][1] - 20 and p.xyz[1] < self.tar_pos[p.ID()%3][1] + 20:
                    state_list = [player.Wait.get_instance(),player.Attack.get_instance(),player.Jump.get_instance(),player.PreShoot.get_instance(),player.PrePass.get_instance(),player.AskForPass.get_instance()]
                    self.cur_test_state[p.ID()%3] = state_list[random.randint(0,len(state_list)-1)]
                    self.run_count_down[p.ID()%3] = random.randint(5,10)
                    self.tar_pos[p.ID()%3][0] = random.randint(40,840)
                    self.tar_pos[p.ID()%3][1] = random.randint(20,200)
                else:
                    p.set_direction(self.tar_pos[p.ID()%3])
                    p.get_ctrl_fsm().change_state(player.Move.get_instance())



    def yulinlu_test(self):
        for p in self.ai_playerObj:
            p.update()
        ai_p = self.ai_playerObj[2]
        if ai_p.ID() != 5 and ai_p.ID() != 2:
            return
        if self.ai_playerObj[0].ID() == 0:
            if self.jump_count_down <= 0:
                self.ai_playerObj[0].get_ctrl_fsm().change_state(player.Jump.get_instance())
                self.jump_count_down = 3
            else:
                self.jump_count_down -= 1
                if self.jump_count_down == 2:
                    self.ai_playerObj[0].get_ctrl_fsm().change_state(player.AskForPass.get_instance())
                else:
                    self.ai_playerObj[0].get_ctrl_fsm().change_state(player.Wait.get_instance())

        attrib = ai_p.get_attrib()
        ball_xyz = self.__scene.get_ball().xyz

        if not attrib.have_ball:
            ai_p.set_direction([ball_xyz[0],ball_xyz[1]])
            if self.yulinlu_dist(ai_p.xyz,ball_xyz) < 30 and not self.have_attacked:
                ai_p.get_ctrl_fsm().change_state(player.Attack.get_instance())
                self.have_attacked = True
            else:
                self.have_attacked = False
                ai_p.get_ctrl_fsm().change_state(player.Move.get_instance())
        else:
            self.have_attacked = False

        if attrib.have_ball:
            if ai_p.xyz[0] > self.shoot_x - 20 and ai_p.xyz[0] < self.shoot_x + 20 and\
               ai_p.xyz[1] > self.shoot_y - 20 and ai_p.xyz[1] < self.shoot_y + 20:
                if ai_p.ID() == 5:
                    if ai_p.xyz[2] < 70 and self.wait_count_down <= 0:
                        ai_p.get_ctrl_fsm().change_state(player.PreShoot.get_instance())
                    else:
                        if self.wait_count_down > 0:
                            self.wait_count_down -= 1
                        else:
                            self.shoot_x,self.shoot_y = 0,0
                            if random.randint(0,1) == 0:
                                self.wait_count_down = 30
                elif ai_p.ID() == 2:
                    if self.pass_count_down > 0:
                        ai_p.get_ctrl_fsm().change_state(player.PrePass.get_instance())
                    else:
                        ai_p.get_ctrl_fsm().change_state(player.Wait.get_instance())
                        self.pass_count_down = 10
            else:
                if self.shoot_x == 0 and self.shoot_y == 0:
                    self.shoot_x = random.randint(100,700)
                    self.shoot_y = random.randint(20,90)
                ai_p.set_direction([self.shoot_x,self.shoot_y])
                ai_p.get_ctrl_fsm().change_state(player.Move.get_instance())

    last_frame = 1
    def test2(self):
        ball = self.__scene.get_ball().xyz
        for b in self.ai_behaviorObj:
            b.update()
        ai_b = self.ai_behaviorObj[2]
        attrib = ai_b.player.get_attrib()
#chaseball------------------------------------------------
        if not attrib.have_ball:
            ai_b.set_tar_pos([ball[0], ball[1]])
#hit------------------------------------------------------
            if math.sqrt((ai_b.player.xyz[0] - ball[0]) * (ai_b.player.xyz[0] - ball[0]) + (ai_b.player.xyz[1] - ball[1]) * (ai_b.player.xyz[1] - ball[1])) < 30:
                ai_b.get_fsm().change_state(behavior.Hit.get_instance())
            else:
                ai_b.get_fsm().change_state(behavior.ChaseBall.get_instance())

#shoot----------------------------------------------------
#        elif ai_b.player.get_real_fsm().current_state != player.InTheAir.get_instance() and ai_b.player.get_real_fsm().current_state != player.PreShoot.get_instance():
#            ai_b.get_fsm().change_state(behavior.Shoot.get_instance())
#straight move--------------------------------------------
#        elif ai_b.get_fsm().current_state == behavior.Stop.get_instance() or ai_b.get_fsm().current_state == behavior.ChaseBall.get_instance():
#            ai_b.set_tar_pos([random.randint(100, 700), random.randint(20, 90)])
#            ai_b.get_fsm().change_state(behavior.StraightMove.get_instance())
#pass-----------------------------------------------------
#        else:
#            f = self.ai_behaviorObj[1]
#            ai_b.set_tar_pos([f.player.xyz[0],f.player.xyz[1]])
#            ai_b.get_fsm().change_state(behavior.Pass.get_instance())
#askball--------------------------------------------------
        else:
            f = self.ai_behaviorObj[1]
            f.get_fsm().change_state(behavior.AskBall.get_instance())
#jump-----------------------------------------------------
        ai_b2 = self.ai_behaviorObj[0]
        if ai_b2.get_fsm().current_state == behavior.Stop.get_instance() and self.last_frame == 0:
            ai_b2.get_fsm().change_state(behavior.Jump.get_instance())
            self.last_frame = 1
        elif ai_b2.get_fsm().current_state == behavior.Stop.get_instance():
            self.last_frame -= 1


    def test3(self):
        if self.ai_teamObj.get_fsm().current_state is team.PrepareForKickOff.get_instance() and not self.ai_teamObj.is_finish:
            self.pre_kick = True
        else:
            self.pre_kick = False
        if self.pre_kick or not self.is_human_control:
            self.__cpu = 1
        else:
            self.__cpu = 0
        self.ai_teamObj.update()
