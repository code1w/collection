# -*- coding:gb2312 -*-

'''This module defines Team class for AI module'''


import sys
import math
import copy
import player
import behavior
import agent
import fsmbase
import aimap
import random

sys.path.append("..")
import sceneglobal
import configp


state = fsmbase.state
pre_kick_finish = False
maxint = 1000000


def dist(xy1, xy2):
    '''get distance from xyz1 to xyz2'''
    return math.sqrt((xy1[0] - xy2[0]) * (xy1[0] - xy2[0]) +
                     (xy1[1] - xy2[1]) * (xy1[1] - xy2[1]))


def get_nearest_pairs(obj_l1, obj_l2):
    if len(obj_l1) != len(obj_l2):
        return []
    length = len(obj_l1)
    a_list = []
    for i in xrange(length):
        obj = obj_l1[i][0]
        obj_pos = obj_l1[i][1]
        item = []
        for j in xrange(length):
            tmp_dist = dist(obj_pos, obj_l2[j][1])
            item.append([i, j, tmp_dist])
        a_list.append(item)
    return_val = {}
    while len(a_list) != 0:
        min = maxint
        for i in xrange(len(a_list)):
            for j in xrange(len(a_list)):
                if a_list[i][j][2] < min:
                    min, min_i, min_j = a_list[i][j][2], a_list[i][j][0], a_list[i][j][1]
                    min_i_, min_j_ = i, j
        return_val[obj_l1[min_i][0]] = obj_l2[min_j][0]
        del a_list[min_i_]
        for i in xrange(len(a_list)):
            del a_list[i][min_j_]
    return return_val


def gcd(a, b):
    if a < b:
        a, b = b, a
    while b != 0:
        temp = a % b
        a = b
        b = temp
    return a


class AgentStrategy:
    def __init__(self):
        self.name = ''
        self.attack = None
        self.support_attack = None
        self.shoot_val = 0.0
        self.pass_val = 0.0
        self.min_r = 0.0
        self.max_r = 0.0
        self.normal_speed = 0.0
        self.run_speed = 0.0
        self.drible_speed = 0.0
        self.attack_probability = 0.0
        self.hit_rate = 0.0
        self.be_attacked_probability = 0.0
        self.attack_ball_dist = 0.0

    def set_val(self, name, dict, attack_dict):
        self.name = name
        self.attack = attack_dict[dict['attack']]
        self.support_attack = attack_dict[dict['support_attack']]
        self.shoot_val = float(dict['shoot_val'])
        self.pass_val = float(dict['pass_val'])
        self.min_grid_x = float(dict['min_grid_x'])
        self.max_grid_x = float(dict['max_grid_x'])
        self.min_grid_y = float(dict['min_grid_y'])
        self.max_grid_y = float(dict['max_grid_y'])
        self.normal_speed = float(dict['normal_speed'])
        self.run_speed = float(dict['run_speed'])
        self.drible_speed = float(dict['drible_speed'])
        self.attack_probability = float(dict['attack_probability'])
        self.hit_rate = float(dict['hit_rate'])
        self.be_attacked_probability = float(dict['be_attacked_probability'])
        self.attack_ball_dist = float(dict['attack_ball_dist'])


class Team:
    '''Team class.'''

    def __init__(self, id, ai_ref, side, team_mode, agent_list):
        self.id = id
        self.ai_ref = ai_ref
        self.agent_list = agent_list
        self.fsm = fsmbase.StateMachine(self)
        self.return_home_pos = []
        self.attack_return_home_pos = []
        self.defend_return_home_pos = []
        self.a_rebound_pos = []
        self.d_rebound_pos = []
        self.ball_keeper = 0
        self.side = side
        self.attack = False
        self.is_finish = False
        self.scene_w, self.scene_h = ai_ref.get_scene_wh()
        self.deal_rebound = False
        self.team_mode = team_mode
        self.pre_attack_finish = False
        self.pre_defend_finish = False
        cp = configp.ConfigP('AI/team.ini')
        param = cp.getdic()
        for i in xrange(len(agent_list)):
            p_home_x = int(param[str(id)]['player' + str(i) + '_x'])
            p_home_y = int(param[str(id)]['player' + str(i) + '_y'])
            self.return_home_pos.append([p_home_x, p_home_y])
            p_attack_x = int(param[str(id)]['player_attack' + str(i) + '_x'])
            p_attack_y = int(param[str(id)]['player_attack' + str(i) + '_y'])
            self.attack_return_home_pos.append([p_attack_x, p_attack_y])
            p_defend_x = int(param[str(id)]['player_defend' + str(i) + '_x'])
            p_defend_y = int(param[str(id)]['player_defend' + str(i) + '_y'])
            self.defend_return_home_pos.append([p_defend_x, p_defend_y])
            a_r_x = int(param[str(id)]['a_rebound' + str(i) + '_x'])
            a_r_y = int(param[str(id)]['a_rebound' + str(i) + '_y'])
            d_r_x = int(param[str(id)]['d_rebound' + str(i) + '_x'])
            d_r_y = int(param[str(id)]['d_rebound' + str(i) + '_y'])
            self.a_rebound_pos.append([a_r_x, a_r_y])
            self.d_rebound_pos.append([d_r_x, d_r_y])
            agent_list[i].x_range = [0, self.scene_w]
            agent_list[i].y_range = [0, self.scene_h]
            agent_list[i].agent_list = self.agent_list
        self.frame_grap = int(param[str(id)]['frame_grap'])
        self.frame_count_down = 0
        self.fsm.set_current_state(Attack.get_instance())
        self.attrib = None
        self.enemy_index_list = []
        self.player_id_list = [agent_list[i].behavior.player.ID()
                               for i in xrange(len(agent_list))]
        for a in agent_list:
            a.teammate_id_list = copy.copy(self.player_id_list)
        self.defence_pair = None
        if side > 0:
            self.my_basket_pos = sceneglobal.sceneParam.basket1_pos
            self.enemy_basket_pos = sceneglobal.sceneParam.basket2_pos
        else:
            self.my_basket_pos = sceneglobal.sceneParam.basket2_pos
            self.enemy_basket_pos = sceneglobal.sceneParam.basket1_pos
        # dictionary for all maps
        self.maps = {}
        self.map_val_dict = {}
        self.show_map_list = []
        self.show_map_list.append('')
        # map for distance to enemy's basket
        self.attack_basket_dist_map = aimap.AIMap(
            self.scene_w, self.scene_h, 1.0)
        self.maps['attack_basket_dist_map'] = self.attack_basket_dist_map
        self.show_map_list.append(self.attack_basket_dist_map)
        # map for distance to enemy's virtual basket
        self.support_attack_basket_dist_map = aimap.AIMap(
            self.scene_w, self.scene_h, 1.0)
        self.maps['support_attack_basket_dist_map'] = self.support_attack_basket_dist_map
        # map for distance to my basket
        self.defend_basket_dist_map = aimap.AIMap(
            self.scene_w, self.scene_h, 1.0)
        self.maps['defend_basket_dist_map'] = self.defend_basket_dist_map
        self.show_map_list.append(self.defend_basket_dist_map)
        # map for distance to enemies
        self.enemy_dist_map = aimap.AIMap(self.scene_w, self.scene_h, 0.0)
        self.maps['enemy_dist_map'] = self.enemy_dist_map
        self.show_map_list.append(self.enemy_dist_map)
        # map for distance to each of my team's player
        self.player_dist_map = {}
        for a in self.agent_list:
            self.player_dist_map[a.behavior.player.ID()] = aimap.AIMap(
                self.scene_w, self.scene_h, 0.0)
            a.map_dict = self.maps
        self.maps['player_dist_map'] = self.player_dist_map
        self.show_map_list.append(self.player_dist_map)
        # map for distance to all of my team's player
        self.all_player_dist_map = aimap.AIMap(self.scene_w, self.scene_h, 0.0)
        self.maps['all_player_dist_map'] = self.all_player_dist_map
        self.show_map_list.append(self.all_player_dist_map)
        # map for success rate when passing ball
        self.pass_map = aimap.AIMap(self.scene_w, self.scene_h, 0.0)
        self.maps['pass_map'] = self.pass_map
        self.show_map_list.append(self.pass_map)
        # map for support player in passing ball
        self.support_player_map = aimap.AIMap(self.scene_w, self.scene_h, 0.0)
        self.maps['support_player_map'] = self.support_player_map
        self.support_player = False
        self.show_map_list.append(self.support_player_map)
        # initialize const maps
        self.init_const_maps()
        self.init_map_val()
        self.agent_strategy_dict = {}
        self.init_agent_strategy()
        self.enemy_affect_r = int(self.enemy_dist_map.grid_h_num / 2.0) + 1
        self.teammate_affect_r = int(self.enemy_dist_map.grid_h_num / 2.0)
        self.pass_affect_r = int(self.enemy_dist_map.grid_h_num) + 1

        self.show_map_index = -2

    def init_map_val(self):
        cp = configp.ConfigP('AI/' + self.team_mode + '/agent.ini')
        param = cp.getdic()
        for k, v in param.items():
            self.map_val_dict[k] = {}
            for k1, v1 in v.items():
                self.map_val_dict[k][k1] = float(v1)

    def init_agent_strategy(self):
        cp = configp.ConfigP('AI/' + self.team_mode + '/agent_strategy.ini')
        param = cp.getdic()
        for k, v in param.items():
            stra = AgentStrategy()
            stra.set_val(k, v, self.map_val_dict)
            self.agent_strategy_dict[k] = stra
        # ������Щ�ǲ��Դ��룬δ������
        list1 = ['forward', 'normal', 'point_guard']
        i = 0
        for a in self.agent_list:
            a.strategy = self.agent_strategy_dict[list1[i]]
            a.behavior.player.set_const_attrib(a.strategy)
            i += 1

    def get_all_maps(self):
        return self.maps

    def init_const_maps(self):
        '''initialize const maps'''
        # initialize attack_basket_dist_map
        map_x, map_y = self.attack_basket_dist_map.get_pos_from_xy(
            self.enemy_basket_pos[0], self.enemy_basket_pos[1])
        max_val = self.attack_basket_dist_map.grid_w_num + \
            self.attack_basket_dist_map.grid_h_num
        w, h = self.attack_basket_dist_map.grid_w_num, self.attack_basket_dist_map.grid_h_num
        self.attack_basket_dist_map.set_min_grid(0.0)
        if self.side > 0:
            a_min_x, a_max_x = w / 2.0, w
            d_min_x, d_max_x = 0, w / 2.0
        else:
            a_min_x, a_max_x = 0, w / 2.0
            d_min_x, d_max_x = w / 2.0, w
        for x in xrange(int(a_min_x), int(a_max_x)):
            for y in xrange(h):
                if (x - map_x) * self.side > 0 and math.fabs(y - map_y) < h / 4.0:
                    self.attack_basket_dist_map.set_grid(
                        [x, y], math.fabs(x - map_x) + math.fabs(y - map_y))
                else:
                    self.attack_basket_dist_map.set_grid(
                        [x, y], max_val - math.fabs(x - map_x) - math.fabs(y - map_y))
        # initialize support_attack_basket_dist_map
        map_x, map_y = self.support_attack_basket_dist_map.get_pos_from_xy(
            self.enemy_basket_pos[0], self.enemy_basket_pos[1])
        max_val = self.support_attack_basket_dist_map.grid_w_num + \
            self.support_attack_basket_dist_map.grid_h_num
        w, h = self.support_attack_basket_dist_map.grid_w_num, self.support_attack_basket_dist_map.grid_h_num
        self.support_attack_basket_dist_map.set_min_grid(0.0)
        if self.side > 0:
            a_min_x, a_max_x = w / 2.0, w
            d_min_x, d_max_x = 0, w / 2.0
        else:
            a_min_x, a_max_x = 0, w / 2.0
            d_min_x, d_max_x = w / 2.0, w
        for x in xrange(int(a_min_x), int(a_max_x)):
            for y in xrange(h):
                if (x - map_x) * self.side > 0 and math.fabs(y - map_y) < h / 4.0:
                    self.support_attack_basket_dist_map.set_grid(
                        [x, y], math.fabs(x - map_x) + math.fabs(y - map_y))
                else:
                    self.support_attack_basket_dist_map.set_grid(
                        [x, y], max_val - math.fabs(x - map_x) - math.fabs(y - map_y))
        # initialize defend_basket_dist_map
        map_x, map_y = self.defend_basket_dist_map.get_pos_from_xy(
            self.my_basket_pos[0], self.my_basket_pos[1])
        w, h = self.defend_basket_dist_map.grid_w_num, self.defend_basket_dist_map.grid_h_num
        self.defend_basket_dist_map.set_min_grid(0.0)
        for x in xrange(int(d_min_x), int(d_max_x)):
            for y in xrange(h):
                self.defend_basket_dist_map.set_grid(
                    [x, y], max_val - math.fabs(x - map_x) - math.fabs(y - map_y))

    def __update_ent_dist_map(self, m, e_xy_list, affect_r, is_opposite, y_alpha):
        m.update()
        max_val = affect_r + affect_r * y_alpha + 1
        m.set_max_grid(max_val)
        for x in xrange(m.grid_w_num):
            for y in xrange(m.grid_h_num):
                val = 0.0
                tmp_min = maxint
                for xy in e_xy_list:
                    x_l, y_l = math.fabs(x - xy[0]), math.fabs(y - xy[1])
                    if x_l < affect_r and y_l < affect_r:
                        if (x - xy[0]) * self.side <= 0:
                            tmp_v = x_l + y_l * y_alpha
                            if tmp_v < tmp_min:
                                tmp_min = tmp_v
                val = (tmp_min == maxint) and max_val or tmp_min
                if is_opposite:
                    m.set_grid([x, y], max_val - val)
                else:
                    m.set_grid([x, y], val)

    def __update_ent_dist_map1(self, m, e_xy_list, affect_r, is_opposite):
        m.update()
        max_val = affect_r * 2 + 1
        m.set_max_grid(max_val)
        for x in xrange(m.grid_w_num):
            for y in xrange(m.grid_h_num):
                val = 0.0
                tmp_min = maxint
                for xy in e_xy_list:
                    x_l, y_l = math.fabs(x - xy[0]), math.fabs(y - xy[1])
                    if x_l < affect_r and y_l < affect_r:
                        if x_l + y_l < tmp_min:
                            tmp_min = x_l + y_l
                val = (tmp_min == maxint) and max_val or tmp_min
                if is_opposite:
                    m.set_grid([x, y], max_val - val)
                else:
                    m.set_grid([x, y], val)

    def __update_proj_map(self, m, src_l, dest_l):
        m.update()
        m.set_max_grid(0)
        m.set_min_grid(-len(dest_l))
        pos_angle_pair = []
        for src in src_l:
            src_x, src_y = m.get_pos_from_xy(src[0], src[1])
            for dest in dest_l:
                dest_x, dest_y = m.get_pos_from_xy(dest[0], dest[1])
                cosa = math.fabs(src_x - dest_x) / math.sqrt((src_x - dest_x)
                                                             * (src_x - dest_x) + (dest_y - src_y) * (dest_y - src_y) + 1)
                pos_angle_pair.append([[src_x, src_y], [dest_x, dest_y], cosa])
        for x in xrange(m.grid_w_num):
            for y in xrange(m.grid_h_num):
                for pair in pos_angle_pair:
                    x1, y1, x2, y2, x3, y3, a = x, y, pair[1][0], pair[1][1], pair[0][0], pair[0][1], pair[2]
                    vec_x1, vec_y1, vec_x2, vec_y2 = x1 - x2, y1 - y2, x3 - x2, y3 - y2
                    fenmu = math.sqrt(
                        (vec_x1 * vec_x1 + vec_y1 * vec_y1) * (vec_x2 * vec_x2 + vec_y2 * vec_y2))
                    if fenmu != 0.0:
                        cos_a = float(vec_x1 * vec_x2 + vec_y1 *
                                      vec_y2) / float(fenmu)
                        if cos_a < math.cos(math.pi - a):
                            m.add_to_grid([x, y], -1)

    def update_map(self):
        # update enemy_dist_map
        e_xy = [self.enemy_dist_map.get_pos_from_xy(self.attrib[i].xyz[0], self.attrib[i].xyz[1])
                for i in self.enemy_index_list
                ]
        self.__update_ent_dist_map(
            self.enemy_dist_map, e_xy, self.enemy_affect_r, False, 1.0)
        # update player_dist_map
        p_m_list = []
        for a in self.agent_list:
            tmp_m = self.player_dist_map[a.behavior.player.ID()]
            p_m_list.append(tmp_m)
            pos = a.tar_pos
            if pos != None:
                self.__update_ent_dist_map(tmp_m, [tmp_m.get_pos_from_xy(
                    pos[0], pos[1])], self.teammate_affect_r, True, 1.0)
        # update all_player_dist_map
        self.all_player_dist_map.update()
        self.all_player_dist_map.set_max_grid(
            (self.enemy_affect_r * 2 + 1) * (len(p_m_list)))
        for x in xrange(self.all_player_dist_map.grid_w_num):
            for y in xrange(self.all_player_dist_map.grid_h_num):
                sum = 0
                for p_m in p_m_list:
                    sum += p_m.get_raw_grid(x, y)
                self.all_player_dist_map.set_grid([x, y], sum)
        # update pass_map
        src_l = []
        for a in self.agent_list:
            if a.behavior.player.get_attrib().have_ball:
                src_l.append([a.behavior.player.xyz[0],
                              a.behavior.player.xyz[1]])
                break
        dest_l = [[self.attrib[j].xyz[0], self.attrib[j].xyz[1]]
                  for j in self.enemy_index_list]
        self.__update_proj_map(self.pass_map, src_l, dest_l)
        # update support_player_map
        if self.attrib[6].owner_team == self.id:
            # this team is controlling the ball
            a_obj = None
            src_l = []
            for a in self.agent_list:
                a_attrib = a.behavior.player.get_attrib()
                if not a_attrib.have_ball:
                    if a_attrib.is_human_control:
                        a_obj = a
                        break
                    src_l.append([a.behavior.player.xyz[0],
                                  a.behavior.player.xyz[1]])
            if a_obj != None:
                # �������Ҳ����������Ӵ��򣬴�����ԱӦ�þ����ܵ��ܴ��������ҵĵط�
                src_l = [[a_obj.behavior.player.xyz[0],
                          a_obj.behavior.player.xyz[1]]]
                self.support_player = True
            else:
                self.support_player = False
            self.__update_proj_map(self.support_player_map, src_l, dest_l)

        if self.show_map_index == -2:
            return
        elif self.show_map_index == -1:
            for a in self.agent_list:
                if a.get_fsm().current_state == agent.Attack.get_instance():
                    self.ai_ref.render_map(a.ai_map)
        else:
            show_map = self.show_map_list[self.show_map_index]
            if self.player_dist_map is show_map:
                show_map = show_map[self.agent_list[0].behavior.player.ID()]
            if self.show_map_index in [6, 7] and self.attrib[6].owner_team != self.id:
                return
            else:
                self.ai_ref.render_map(show_map)

    def update(self):
        self.attrib = self.ai_ref.get_all_attrib()
        if self.attrib[6].owner_team == self.id:
            self.attrib = self.ai_ref.get_all_realtime_attrib()
        for a in self.agent_list:
            a.attrib = self.attrib
        if len(self.enemy_index_list) == 0:
            for i in xrange(len(self.attrib) - 1):
                # traverse all player, find enemies
                if self.attrib[i].id not in self.player_id_list:
                    self.enemy_index_list.append(i)
                else:
                    for a in self.agent_list:
                        if a.behavior.player.ID() == self.attrib[i].id:
                            a.attrib_index = i
            for a in self.agent_list:
                a.enemy_index_list = self.enemy_index_list
        if self.frame_count_down == 0:
            self.update_map()
        for obj in self.agent_list:
            obj.update()
        if self.frame_count_down == 0:
            self.fsm.update()

        # update frame count down
        if self.frame_count_down == 0:
            self.frame_count_down = self.frame_grap
        else:
            self.frame_count_down -= 1

    def get_fsm(self):
        return self.fsm

    def update_defence_pair(self):
        a_list = [[self.agent_list[i],
                   [self.agent_list[i].behavior.player.xyz[0],
                       self.agent_list[i].behavior.player.xyz[1]]
                   ] for i in xrange(len(self.agent_list))
                  ]
        e_list = [[i, [self.attrib[i].xyz[0], self.attrib[i].xyz[1]]]
                  for i in self.enemy_index_list]
        self.defence_pair = get_nearest_pairs(a_list, e_list)


class Rebound(state):
    instance = None

    @staticmethod
    def get_instance():
        if not Rebound.instance:
            Rebound.instance = Rebound()
        return Rebound.instance

    def enter(self, team):
        if team.attrib[6].owner_team != team.id and team.attrib[6].owner_team > 0:
            # lose the ball, then change to defend state
            team.get_fsm().change_state(ManToManDefence.get_instance())
        elif team.attrib[6].owner_team == team.id:
            # have the ball, then change to attack state
            team.get_fsm().change_state(Attack.get_instance())
        else:
            # no team have the ball, find it
            if team.attrib[6].is_rebound and not team.deal_rebound:
                # the ball is just rebound, decide someone to get the rebound
                team.deal_rebound = True
                ball_speed = [team.attrib[6].speed[0] / 5,
                              team.attrib[6].speed[1] / 5, team.attrib[6].speed[2] / 5]
                for obj in team.agent_list:
                    player_speed = obj.behavior.player.get_attrib().speed
                    ball_pos = team.attrib[6].xyz
                    min_d = maxint
                    for obj in team.agent_list:
                        if not obj.behavior.player.get_attrib().is_human_control:
                            d = agent.count_time(
                                player_speed, ball_speed, obj.behavior.player.get_attrib().xyz, ball_pos)
                            if d < min_d:
                                min_d = d
                                min_obj = obj
                    min_obj.get_fsm().change_state(agent.Rebound.get_instance())
            elif team.attrib[6].is_shot:
                # the ball has been shot, call player to rebound
                ball_attrib = team.attrib[6]
                d_attack = agent.count_time(
                    5, ball_attrib.speed, team.enemy_basket_pos, ball_attrib.xyz)
                d_defence = agent.count_time(
                    5, ball_attrib.speed, team.my_basket_pos, ball_attrib.xyz)
                if d_attack < d_defence:
                    rebound_pos = team.a_rebound_pos
                else:
                    rebound_pos = team.d_rebound_pos
                agent_pos_list = [[team.agent_list[i],
                                   [team.agent_list[i].behavior.player.xyz[0],
                                       team.agent_list[i].behavior.player.xyz[1]]
                                   ] for i in xrange(len(team.agent_list))]
                home_reg_list = [[copy.copy(rebound_pos[i]), copy.copy(
                    rebound_pos[i])] for i in xrange(len(team.agent_list))]
                pairs = get_nearest_pairs(agent_pos_list, home_reg_list)
                for a in team.agent_list:
                    a.set_tar_pos(pairs[a])
                    a.get_fsm().change_state(agent.ReturnHome.get_instance())

    def execute(self, team):
        if team.attrib[6].owner_team != team.id and team.attrib[6].owner_team > 0:
            # lose the ball, then change to defend state
            team.get_fsm().change_state(ManToManDefence.get_instance())
        elif team.attrib[6].owner_team == team.id:
            # have the ball, then change to attack state
            team.get_fsm().change_state(Attack.get_instance())
        else:
            # if the ball have_goal
            if team.attrib[6].have_goal_defend or team.attrib[6].have_goal_attack:
                if team.attrib[6].goal_basket == team.my_basket_pos and team.attrib[6].have_goal_attack:
                    team.attack = True
                    team.attrib[6].have_goal_attack = False
                    team.ai_ref.clear_ball_have_goal_attack()
                    team.get_fsm().change_state(PrepareForKickOff.get_instance())
                elif team.attrib[6].goal_basket == team.enemy_basket_pos and team.attrib[6].have_goal_defend:
                    team.attack = False
                    team.attrib[6].have_goal_defend = False
                    team.ai_ref.clear_ball_have_goal_defend()
                    team.get_fsm().change_state(PrepareForKickOff.get_instance())
            # no team have the ball, find it
            elif team.attrib[6].is_rebound and not team.deal_rebound:
                # the ball is just rebound, decide someone to get the rebound
                team.get_fsm().change_state(Rebound.get_instance())
            else:
                half_w = team.scene_w / 2.0
                have_someone_catchball = False
                for obj in team.agent_list:
                    cur_state = obj.get_fsm().current_state
                    if cur_state == agent.CatchBall.get_instance() and\
                       not obj.behavior.player.get_attrib().is_human_control:
                        have_someone_catchball = True
                    if obj.is_finish and cur_state == agent.ReturnHome.get_instance():
                        if have_someone_catchball:
                            if (obj.behavior.player.xyz[0] - half_w) * team.side > 0:
                                #obj.map_val_dict = team.map_val_dict['support_attack_normal']
                                obj.get_fsm().change_state(agent.SupportAttack.get_instance())
                            else:
                                obj.get_fsm().change_state(agent.Defend.get_instance())
                        else:
                            obj.get_fsm().change_state(agent.CatchBall.get_instance())

    def exit(self, team):
        team.deal_rebound = False


class Attack(state):
    instance = None

    @staticmethod
    def get_instance():
        if not Attack.instance:
            Attack.instance = Attack()
        return Attack.instance

    def enter(self, team):
        pass

    def execute(self, team):
        isLeft = -1
        half_h = team.scene_h / 2.0
        if team.attrib[6].owner_team != team.id and team.attrib[6].owner_team > 0:
            # lose the ball, then change to defend state
            team.get_fsm().change_state(ManToManDefence.get_instance())
        elif team.attrib[6].have_goal_defend or team.attrib[6].have_goal_attack:
            if team.attrib[6].have_goal_defend or team.attrib[6].have_goal_attack:
                if team.attrib[6].goal_basket == team.my_basket_pos and team.attrib[6].have_goal_attack:
                    team.attack = True
                    team.attrib[6].have_goal_attack = False
                    team.ai_ref.clear_ball_have_goal_attack()
                    team.get_fsm().change_state(PrepareForKickOff.get_instance())
                elif team.attrib[6].goal_basket == team.enemy_basket_pos and team.attrib[6].have_goal_defend:
                    team.attack = False
                    team.attrib[6].have_goal_defend = False
                    team.ai_ref.clear_ball_have_goal_defend()
                    team.get_fsm().change_state(PrepareForKickOff.get_instance())
        elif team.attrib[6].owner_team < 0:
            if team.attrib[6].is_shot:
                # the ball is just rebound, then change to rebound state
                team.get_fsm().change_state(Rebound.get_instance())
            else:
                # no team have the ball, persuit the ball and get ready to
                # attack
                min_d = maxint
                min_obj = None
                player_speed = team.agent_list[0].behavior.player.get_attrib(
                ).speed
                ball_speed = [team.attrib[6].speed[0] / 5,
                              team.attrib[6].speed[1] / 5, team.attrib[6].speed[2] / 5]
                ball_pos = team.attrib[6].xyz
                for obj in team.agent_list:
                    if not obj.behavior.player.get_attrib().is_human_control:
                        d = agent.count_time(
                            player_speed, ball_speed, obj.behavior.player.get_attrib().xyz, ball_pos)
                        if d < min_d:
                            min_d = d
                            min_obj = obj
                if min_obj.get_fsm().current_state is not agent.CatchBall.get_instance():
                    min_obj.x_range = [0, team.scene_w]
                    min_obj.y_range = [0, team.scene_h]
                    min_obj.get_fsm().change_state(agent.CatchBall.get_instance())
                for obj in team.agent_list:
                    if obj is not min_obj and\
                       obj.get_fsm().current_state is not agent.SupportAttack.get_instance():
                        self.get_min_max(obj, team)
                        obj.get_fsm().change_state(agent.SupportAttack.get_instance())
        else:
            # it already have the ball
            for obj in team.agent_list:
                cur_state = obj.get_fsm().current_state
                obj_attrib = obj.behavior.player.get_attrib()
                if obj_attrib.is_human_control:
                    continue
                if obj_attrib.have_ball:
                    self.get_min_max(obj, team)
                    if cur_state is not agent.Attack.get_instance():
                        obj.get_fsm().change_state(agent.Attack.get_instance())
                elif cur_state is not agent.SupportAttack.get_instance():
                    self.get_min_max(obj, team)
                    obj.get_fsm().change_state(agent.SupportAttack.get_instance())

    def get_min_max(self, obj, team):
        obj.x_range = [0, team.scene_w]
        obj.y_range = [0, team.scene_h]
        return
        obj_x, obj_y = obj.behavior.player.xyz[0], obj.behavior.player.xyz[1]
        obj_r = team.scene_h / 2.0
        min_x, max_x, min_y, max_y = 0, 0, 0, 0
        if min_x + obj_x - obj_r > 0:
            min_x += (obj_x - obj_r)
        else:
            max_x -= (min_x + obj_x - obj_r)
            if max_x > team.scene_w:
                max_x = team.scene_w - 1
            min_x = 0
        if max_x + obj_x + obj_r < team.scene_w:
            max_x += (obj_x + obj_r)
        else:
            min_x -= (max_x + obj_x + obj_r - team.scene_w + 1)
            if min_x < 0:
                min_x = 0
            max_x = team.scene_w - 1
        if min_y + obj_y - obj_r > 0:
            min_y += (obj_y - obj_r)
        else:
            max_y -= (min_y + obj_y - obj_r)
            if max_y > team.scene_h:
                max_y = team.scene_h - 1
            min_y = 0
        if max_y + obj_y + obj_r < team.scene_h:
            max_y += (obj_y + obj_r)
        else:
            min_y -= (max_y + obj_y + obj_r - team.scene_h + 1)
            if min_y < 0:
                min_y = 0
            max_y = team.scene_h - 1
        obj.x_range = [min_x, max_x]
        obj.y_range = [min_y, max_y]

    def exit(self, team):
        pass


class ManToManDefence(state):
    '''man-to-man defence'''
    instance = None

    @staticmethod
    def get_instance():
        if not ManToManDefence.instance:
            ManToManDefence.instance = ManToManDefence()
        return ManToManDefence.instance

    def enter(self, team):
        # let the agent go to nearest home region
        agent_pos_list = [[team.agent_list[i],
                           [team.agent_list[i].behavior.player.xyz[0],
                               team.agent_list[i].behavior.player.xyz[1]]
                           ] for i in xrange(len(team.agent_list))]
        home_reg_list = [[copy.copy(team.return_home_pos[i]), copy.copy(
            team.return_home_pos[i])] for i in xrange(len(team.agent_list))]
        pairs = get_nearest_pairs(agent_pos_list, home_reg_list)
        for a in team.agent_list:
            a.set_tar_pos(pairs[a])
            a.x_range = [0, team.scene_w]
            a.y_range = [0, team.scene_h]
            if (a.behavior.player.xyz[0] - team.scene_w / 2.0) * team.side > 0:
                # in front court, back to home region
                a.get_fsm().change_state(agent.ReturnHome.get_instance())
            else:
                # in back court, begin to defend
                if team.defence_pair == None:
                    team.update_defence_pair()
                a.defence_enemy_index = team.defence_pair[a]
                a.get_fsm().change_state(agent.Defend.get_instance())

    def execute(self, team):
        if team.attrib[6].have_goal_defend or team.attrib[6].have_goal_attack:
            if team.attrib[6].goal_basket == team.my_basket_pos and team.attrib[6].have_goal_attack:
                team.attack = True
                team.attrib[6].have_goal_attack = False
                team.ai_ref.clear_ball_have_goal_attack()
                team.get_fsm().change_state(PrepareForKickOff.get_instance())
                return
            elif team.attrib[6].goal_basket == team.enemy_basket_pos and team.attrib[6].have_goal_defend:
                team.attack = False
                team.attrib[6].have_goal_defend = False
                team.ai_ref.clear_ball_have_goal_defend()
                team.get_fsm().change_state(PrepareForKickOff.get_instance())
                return
        elif team.attrib[6].is_shot:
            team.get_fsm().change_state(Rebound.get_instance())
            return
        elif team.attrib[6].owner_team == team.id or team.attrib[6].owner_team < 0:
            # change to attack status
            team.get_fsm().change_state(Attack.get_instance())
            return
        # update the newest man-to-man defence pair
        team.update_defence_pair()
        # if agent does not reach home region, keep reaching
        min_dist = 120  # �����Ĳ�������д����δ������
        for i in xrange(len(team.agent_list)):
            obj = team.agent_list[i]
            to_be_defended_index = team.defence_pair[obj]
            to_be_defended = team.attrib[to_be_defended_index]
            if obj.get_fsm().current_state is agent.ReturnHome.get_instance():
                # returning home region
                if obj.is_finish or\
                   dist([obj.behavior.player.xyz[0], obj.behavior.player.xyz[1]],
                        [to_be_defended.xyz[0], to_be_defended.xyz[1]]
                        ) < min_dist:
                    # has returned home or enemy is very close, begin defending
                    if to_be_defended.have_ball:
                        # this enemy has the ball
                        # ����Ҫ�����Ƿ������ͷ�������δ������
                        obj.defence_enemy_index = to_be_defended_index
                        obj.get_fsm().change_state(agent.Defend.get_instance())
                    else:
                        # this enemy does not have the ball
                        obj.defence_enemy_index = to_be_defended_index
                        obj.get_fsm().change_state(agent.Defend.get_instance())
            elif obj.get_fsm().current_state is agent.Defend.get_instance():
                # this player is defending
                if to_be_defended.have_ball:
                    # this enemy has the ball
                    # ����Ҫ�����Ƿ������ͷ�������δ������
                    obj.positive = True
                    obj.defence_enemy_index = to_be_defended_index
                else:
                    # this enemy does not have the ball
                    # update position of target
                    obj.positive = False
                    obj.defence_enemy_index = to_be_defended_index
            else:
                # this player is in other statuses
                if to_be_defended.have_ball:
                    # this enemy has the ball
                    # ����Ҫ�����Ƿ������ͷ�������δ������
                    obj.defence_enemy_index = to_be_defended_index
                else:
                    # this enemy does not have the ball
                    # update position of target
                    obj.defence_enemy_index = to_be_defended_index

    def exit(self, team):
        pass


class PrepareForKickOff(state):
    instance = None

    @staticmethod
    def get_instance():
        if not PrepareForKickOff.instance:
            PrepareForKickOff.instance = PrepareForKickOff()
        return PrepareForKickOff.instance

    def enter(self, team):
        global pre_kick_finish
        global pre_attack_finish
        global pre_defend_finish
        team.is_finish = False
        pre_kick_finish = False
        j = 1
        if team.attack:
            pre_attack_finish = False
            team.ball_keeper = random.randint(0, len(team.agent_list) - 1)
            for i in xrange(len(team.agent_list)):
                obj = team.agent_list[i]
                if i == team.ball_keeper:
                    obj.get_fsm().change_state(agent.CatchBall.get_instance())
                else:
                    rand_x, rand_y = random.randint(
                        0, 50), random.randint(0, 50)
                    obj.set_tar_pos([team.attack_return_home_pos[j][0] +
                                     rand_x, team.attack_return_home_pos[j][1] + rand_y])
                    j += 1
                    obj.get_fsm().change_state(agent.ReturnHome.get_instance())
        else:
            pre_defend_finish = False
            for i in xrange(len(team.agent_list)):
                obj = team.agent_list[i]
                rand_x, rand_y = random.randint(0, 50), random.randint(0, 50)
                obj.set_tar_pos([team.defend_return_home_pos[i][0] +
                                 rand_x, team.defend_return_home_pos[i][1] + rand_y])
                obj.get_fsm().change_state(agent.ReturnHome.get_instance())

    def execute(self, team):
        global pre_attack_finish
        global pre_defend_finish
        global pre_kick_finish
        if team.attack:
            if pre_kick_finish:
                team.get_fsm().change_state(Attack.get_instance())
            elif team.attrib[6].owner_player != -1 and team.attrib[6].owner_player != team.ball_keeper:
                team.agent_list[team.ball_keeper].behavior.get_fsm(
                ).change_state(behavior.AskBall.get_instance())
            # if the ball_keeper chase the ball and catch it or someone pass
            # the ball to the ball_keeper, then return home
            elif (team.agent_list[team.ball_keeper].get_fsm().current_state is agent.CatchBall.get_instance() and team.agent_list[team.ball_keeper].is_finish) or\
                 (team.agent_list[team.ball_keeper].behavior.get_fsm().current_state is behavior.AskBall.get_instance() and team.agent_list[team.ball_keeper].behavior.is_finish):
                # back to the basket
                obj = team.agent_list[team.ball_keeper]
                obj.set_tar_pos(team.attack_return_home_pos[0])
                obj.get_fsm().change_state(agent.ReturnHome.get_instance())
                j = 1
                for i in xrange(len(team.agent_list)):
                    obj = team.agent_list[i]
                    if i != team.ball_keeper:
                        rand_x, rand_y = random.randint(
                            0, 50), random.randint(0, 50)
                        obj.set_tar_pos(
                            [team.attack_return_home_pos[j][0] + rand_x, team.attack_return_home_pos[j][1] + rand_y])
                        j += 1
                        obj.get_fsm().change_state(agent.ReturnHome.get_instance())
            elif team.agent_list[team.ball_keeper].is_finish and pre_defend_finish:
                pre_attack_finish = True
                team.is_finish = True
                if pre_kick_finish:
                    team.get_fsm().change_state(Attack.get_instance())
        else:
            if pre_kick_finish:
                team.get_fsm().change_state(Attack.get_instance())
            pre_defend_finish = True
            for obj in team.agent_list:
                if not obj.is_finish:
                    pre_defend_finish = False
            if pre_attack_finish:
                team.is_finish = True
                pre_kick_finish = True
                team.get_fsm().change_state(ManToManDefence.get_instance())

    def exit(self, team):
        pass
