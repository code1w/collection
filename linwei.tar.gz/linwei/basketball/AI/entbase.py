# -*- coding:gb2312 -*-
#======================================================================
#
# entbase.py - basic entity interface
#
#======================================================================

import copy

class TypeEnum:
    '''Enumeration of the type of objects'''
    BaseGameEntity = -1
    Player = 2

#use it to get the enumeration of type
ObjType = TypeEnum()


#----------------------------------------------------------------------
# Base Game Entity Interface
#----------------------------------------------------------------------
class BaseGameEntity(object):
    __nextid = 0
    def __init__ (self, id, xyz, lwh, type=ObjType.BaseGameEntity):
        self.id = id
        self.xyz = xyz
        self.lwh = lwh
        self.type = ObjType.BaseGameEntity
    def setid(self, val):
        '''set id of this object'''
        if val < BaseGameEntity.__nextid:
            raise Exception('<BaseGameEntity::SetID>: invalid ID')
        self.id = val
        BaseGameEntity.__nextid = val + 1
    def nextid(self):
        '''get next id in entity manager'''
        return BaseGameEntity.__nextid
    def ID(self):
        '''get id of this object'''
        return self.id
    def update(self):
        '''update status of this object'''
        pass
    def render(self):
        '''no need to render, ignore it'''
        pass
    def handlemsg(self, tel):
        '''handle the message which sent to this object'''
        return False
    def pos(self):
        '''get position of this object'''
        return self.xyz
    def setpos(self, pos):
        '''set position of this object'''
        self.xyz = copy.copy(pos)
    def get_lwh(self):
        '''It will return [l,w,h]'''
        return copy.copy(self.lwh)
    def get_type(self):
        '''It will return the type of this object'''
        return self.type


#----------------------------------------------------------------------
# Entity Manager
#----------------------------------------------------------------------
class EntityManager(object):
    instance = None
    @staticmethod
    def get_instance():
        if not EntityManager.instance:
            EntityManager.instance = EntityManager()
        return EntityManager.instance
    def __init__ (self):
        self.entities = {}
    def __contains__ (self, key):
        return key in self.entities
    def __len__ (self):
        return len(self.entities)
    def __getitem__ (self, key):
        return self.entities[key]
    def register (self, entity):
        if not isinstance(entity, BaseGameEntity):
            raise TypeError('entity must be a instance of BaseGameEntity')
        if entity.id in self.entities:
            raise Exception('entity id=%d is already registered'%entity.id)
        self.entities[entity.id] = entity
    def remove (self, entity):
        if not isinstance(entity, BaseGameEntity):
            raise TypeError('entity must be a instance of BaseGameEntity')
        if not entity.id in self.entities:
            raise Exception('entity id=%d has not been registered'%entity.id)
    def getentity (self, id):
        if not id in self.entities:
            raise Exception('entity id=%d has not been registered'%entity.id)
        return self.entities[id]
    def __iter__ (self):
        return self.entities.__iter__()


EntityMgr = EntityManager.get_instance()

#----------------------------------------------------------------------
# testing case
#----------------------------------------------------------------------
if __name__ == '__main__':
    bge = BaseGameEntity(1,[0,0,0],[5,6,7])
    print bge.ID()
    bge.setid(0)
    print bge.nextid()
    bge.setpos([1,1,1])
    print bge.pos(),bge.get_lwh(),bge.get_type()
    EntityMgr.register(bge)
    print EntityMgr.getentity(0)
    print len(EntityMgr)


