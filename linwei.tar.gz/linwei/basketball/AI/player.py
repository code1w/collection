# -*- coding:gb2312 -*-

'''This module defines basketball player class for AI module'''

import sys
import math
import copy
import fsmbase
import entbase
sys.path.append("..")
import mybasesprite
import playersprite

# Messages
MSG_MOVE = 1
MSG_PREPASS = 2
MSG_ASKFORPASS = 3
MSG_ATTACK = 4


class PlayerConstAttrib(object):
    #lwh of player
    lwh = []
    #faint time, default is 30 frames
    faint_time = 30
    #speed of dunking
    dunk_speed = 10.0
    #min and max of pass ball speed
    pass_speed = [50.0, 90.0]
    #maximum pass count
    max_pass_count = 15
    #attack length, width, height
    attack_lwh = [10,34,64]
    #initial jumping v
    init_jump_v = 30.0

class PlayerAttrib(object):
    def __init__(self):
        #id of player
        self.id = -1
        #position of player
        self.xyz = []
        #internal status of player
        self.internal_state = playersprite.NO_BALL
        #whether the player have a ball
        self.have_ball = False
        #speed of player
        self.speed = 0
        #face orientation
        self.face_orient = []
        #move step
        self.move_step = []
        #faint count down
        self.faint_count_down = 0
        #dunk step
        self.dunk_step = []
        #orientation of dunk
        self.dunk_orient = [0,0,0]
        #target basket position
        self.target_basket_pos = []
        #target dunk position
        self.target_dunk_pos = []
        #v for jumping in dimension z
        self.jump_v = 0.0
        #can this player pick the ball
        self.can_pick_countdown = -1
        #if it is true, it is controlled by humanbeing
        self.is_human_control = False
    

#----------------------------------------------------------------------
# Player Class
#----------------------------------------------------------------------
class Player(entbase.BaseGameEntity):
    wanna_move_orient = []
    
    def __init__ (self, ai_ref, p, id, xyz, lwh, team_len, type=entbase.ObjType.Player):
        super (Player, self).__init__ (id,xyz,lwh,type)
        self.__ai_ref = ai_ref
        self.__player_sprite = p
        #state machine for controlling, ai controls this state machines
        self.__ctrl_state_machine = fsmbase.StateMachine(self)
        #state machine in real scene, it can not be changed by ai
        self.__real_state_machine = fsmbase.StateMachine(self)
        self.__player_const_attrib = p.get_const_attrib()
        self.__player_attrib = p.get_attrib()
        self.__player_attrib.move_step = [0,0,0]
        self.__team_len = team_len
        self.wanna_move_orient = [0,0]
        self.key_states = [0] * self.__team_len
        self.__ctrl_state_machine.set_global_state(PlayerGlobalState.get_instance())
    def set_const_attrib(self,strategy):
        self.__player_sprite.set_const_attrib(strategy)
        self.__player_const_attrib = self.get_const_attrib()
    def get_const_attrib(self):
        return self.__player_const_attrib
    def get_attrib(self):
        return self.__player_attrib
    def get_player_sprite(self):
        return self.__player_sprite
    def set_key_states (self,k):
        self.key_states = copy.copy(k)
    def state_setup (self, state):
        self.__ctrl_state_machine.set_current_state(state)
    def get_ctrl_fsm (self):
        return self.__ctrl_state_machine
    def get_real_fsm (self):
        return self.__real_state_machine
    def handle_msg (self, tel):
        self.__ctrl_state_machine.handle_message(tel)
    def update (self):
        self.__ctrl_state_machine.update()
    def __get_state_between_wait_move(self):
        for s in self.__player_attrib.move_step:
            if s != 0:
                return Move.get_instance()
        return Wait.get_instance()
    def get_scene_wh(self):
        return self.__ai_ref.get_scene_wh()
    def set_direction(self, des):
        if des[0] > 800: des[0] = 800
        elif des[0] < 0: des[0] = 0
        if des[1] > 200: des[1] = 200
        elif des[1] < 0: des[1] = 0
        direction = [0, 0]
        speed = self.__player_attrib.speed
        dx = des[0] - self.xyz[0]
        dy = des[1] - self.xyz[1]
        if math.fabs(dx) >= speed / math.sqrt(2) and math.fabs(dy) >= speed / math.sqrt(2):
            direction[0] = dx / math.fabs(dx)
            direction[1] = dy / math.fabs(dy)
        elif math.fabs(dx) >= speed:
            direction[0] = dx / math.fabs(dx)
        elif math.fabs(dy) >= speed:
            direction[1] = dy / math.fabs(dy)
        self.move(direction)

    def update_real_state (self):
        self.__player_attrib = self.__player_sprite.get_attrib()
        self.__player_attrib.move_step = [self.__player_attrib.xyz[0] - self.xyz[0],
                                          self.__player_attrib.xyz[1] - self.xyz[1],
                                          self.__player_attrib.xyz[2] - self.xyz[2]]
        self.xyz = copy.copy(self.__player_attrib.xyz)
        p_state = self.__player_attrib.internal_state
        if p_state == playersprite.FAINT:
            self.__real_state_machine.change_state(Faint.get_instance())
        elif p_state == playersprite.CONTROL_BALL:
            self.__real_state_machine.change_state(self.__get_state_between_wait_move())
        elif p_state == playersprite.NO_BALL:
            if self.xyz[2] > self.get_lwh()[2] / 2.0:
                #in the air
                self.__real_state_machine.change_state(InTheAir.get_instance())
            else:
                self.__real_state_machine.change_state(self.__get_state_between_wait_move())
        elif p_state == playersprite.PASSING:
            self.__real_state_machine.change_state(PrePass.get_instance())
        elif p_state == playersprite.SHOOTING:
            self.__real_state_machine.change_state(PreShoot.get_instance())
        elif p_state == playersprite.DUNKING:
            self.__real_state_machine.change_state(Dunking.get_instance())
    def clear_move(self):
        '''clear the movement orientation'''
        self.wanna_move_orient[0] = 0
        self.wanna_move_orient[1] = 0
    def move (self, orient):
        '''move in one frame'''
        self.wanna_move_orient = copy.copy(orient)


#----------------------------------------------------------------------
# States Classes
#----------------------------------------------------------------------


class PlayerGlobalState(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of PlayerGlobalState'''
        if not PlayerGlobalState.instance:
            PlayerGlobalState.instance = PlayerGlobalState()
        return PlayerGlobalState.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #let player update its real status according to scene
        player.update_real_state()
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass
    def onmessage (self, player, telegram):
        pass

class Wait(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of wait'''
        if not Wait.instance:
            Wait.instance = Wait()
        return Wait.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        player.move([0,0])
        #print player.ID(),'is waiting'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass

class Move(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Move'''
        if not Move.instance:
            Move.instance = Move()
        return Move.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is moving'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass
    

class PrePass(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of PrePass'''
        if not PrePass.instance:
            PrePass.instance = PrePass()
        return PrePass.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is PrePassing'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass



class AskForPass(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of AskForPass'''
        if not AskForPass.instance:
            AskForPass.instance = AskForPass()
        return AskForPass.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is AskForPass'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass



class PreShoot(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of PreShoot'''
        if not PreShoot.instance:
            PreShoot.instance = PreShoot()
        return PreShoot.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is PreShoot'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass


class Dunking(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Dunking'''
        if not Dunking.instance:
            Dunking.instance = Dunking()
        return Dunking.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is Dunking'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass


class Attack(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Attack'''
        if not Attack.instance:
            Attack.instance = Attack()
        return Attack.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is Attacking'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass


class Jump(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Jump'''
        if not Jump.instance:
            Jump.instance = Jump()
        return Jump.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is Jumping'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass


class InTheAir(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of InTheAir'''
        if not InTheAir.instance:
            InTheAir.instance = InTheAir()
        return InTheAir.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is InTheAir'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass

class Faint(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Faint'''
        if not Faint.instance:
            Faint.instance = Faint()
        return Faint.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is Fainting'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass

class SpeedUpRun(fsmbase.state):
    instance = None
    @staticmethod
    def get_instance():
        '''get instance of Faint'''
        if not SpeedUpRun.instance:
            SpeedUpRun.instance = SpeedUpRun()
        return SpeedUpRun.instance
    def enter(self, player):
        '''it will be invoked when player enter this status'''
        pass
    def execute(self, player):
        '''it will be invoked when player is in this status and update'''
        #print player.ID(),'is Fainting'
    def exit(self, player):
        '''it will be invoked when player exit this status'''
        pass
