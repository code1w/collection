import sys, pygame, random, time

import scenesprite
import mybasesprite
import beginscenesprite
import sceneglobal

class Main:
    screen = None
    bgcolour = 0x0, 0x0, 0x0
    clock = None
    objList = []
    __nTime = 0

    #__bgimg = None

    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 2, 1024)
        pygame.init()
        pygame.display.init()
        pygame.mixer.init(44100, -16, 2, 1024)
        pygame.mixer.set_num_channels(16)
        self.__bgimg = pygame.image.load("/data/github/linwei/basketball/images/background4.png")
        #self.screen = pygame.display.set_mode((self.__bgimg.get_rect().width, self.__bgimg.get_rect().height))
        self.screen = pygame.display.set_mode((self.__bgimg.get_rect().width, 580))
        #self.screen.blit(self.__bgimg, self.__bgimg.get_rect())

        self.clock = pygame.time.Clock()
        pygame.key.set_repeat(1,1)
        pygame.mouse.set_visible(0)
        self.objList.append(beginscenesprite.BeginScene(self)) #add scene to  objlist

    def get_screen_wh (self):
        return 800,600

    def game_loop (self, jumpframe=1):
        self.clock.tick(sceneglobal.sceneParam.fps) #Game Setting
        #self.screen.fill(self.bgcolour)
        self.event = pygame.event.get()

        self.__nTime += 1 #Time control

        for e in self.event: #Global Event
            if e.type == pygame.QUIT:
                sys.exit()

        for obj in self.objList[:]: #update
            if obj.active == mybasesprite.ObjActive.Active:
                obj.update(self.event)

        #self.screen.blit(self.__bgimg, (0,0))
        if jumpframe<>0:
            for obj in self.objList[:]: #render
                if obj.visable == mybasesprite.ObjVisable.Visable:
                    obj.render(self.screen)

        for obj in self.objList[:]: #remove not alive
            if obj.status == mybasesprite.ObjStatus.Killed:
                self.objList.remove(obj)

        obj = None
        pygame.display.flip()


def start():
    g = Main()
    jumpframe = 1
    
    while True:
        jumpframe = (jumpframe+1)%4
        g.game_loop()
        time.sleep(0.001)

if __name__ == "__main__":
    start()
