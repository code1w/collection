import pygame
import mybasesprite


class GoalScene(mybasesprite.MyBaseSprite):
    mainClass = None
    surfLast = None
    img_goal = None
    pos_x = 100

    def __init__(self, _main, _screen):
        pygame.init()
        self.mainClass = _main
        self.surfLast = pygame.Surface(_screen.get_size())
        self.surfLast.blit(_screen, (0, 0))

        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Inactive
            objSence.visable = mybasesprite.ObjVisable.UnVisable

        self.img_goal = pygame.image.load("/data/github/linwei/basketball/images/goal.png")

    def __del__(self):
        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Active
            objSence.visable = mybasesprite.ObjVisable.Visable

    def update(self, event):
        self.pos_x += 20
        if self.pos_x > 878:
            self.mainClass.objList.remove(self)

    def render(self, screen):
        screen.blit(self.surfLast, (0, 0))
        screen.blit(self.img_goal, (878 - self.pos_x, 0))
