# -*- coding:gb2312 -*-
import pygame
import scenesprite
import mybasesprite
import effect
import sceneglobal


class BeginScene(mybasesprite.MyBaseSprite):
    mainClass = None
    objList = []
    screen = None

    menuSelect = 1
    flashColor = [(255, 0, 0), (240, 16, 0), (224, 32, 0), (208, 48, 0), (192, 64, 0), (176, 80, 0), (160, 96, 0), (144, 112, 0), (128, 128, 0),
                  (112, 144, 0), (96, 160, 0), (80, 176, 0), (64,
                                                              192, 0), (48, 208, 0), (32, 224, 0), (16, 240, 0),
                  (0, 255, 0), (0, 240, 16), (0, 224, 32), (0, 208, 48), (0, 192,
                                                                          64), (0, 176, 80), (0, 160, 96), (0, 144, 112), (0, 128, 128),
                  (0, 112, 144), (0, 96, 160), (0, 80, 176), (0, 64,
                                                              192), (0, 48, 208), (0, 32, 224), (0, 16, 240),
                  (0, 0, 255), (16, 0, 240), (32, 0, 224), (48, 0, 208), (64, 0,
                                                                          192), (80, 0, 176), (96, 0, 160), (112, 0, 144), (128, 0, 128),
                  (144, 0, 112), (160, 0, 96), (176, 0, 80), (192,
                                                              0, 64), (208, 0, 48), (224, 0, 32), (240, 0, 16),
                  ]
    flashColorIndex = 0

    def __init__(self, _main):
        pygame.init()
        self.mainClass = _main
        self.screen = _main.screen
        mybasesprite.MyBaseSprite.__init__(
            self, None, [0, 0, 0], [0, 0, 0], 0, [])
        self.objList = []
        self.upkey = 1

        self.menu = []
        self.menu.append(
            (effect.Effect(self, (300, 100), "word"), "Player VS. CPU (Easy)"))
        self.menu.append(
            (effect.Effect(self, (300, 150), "word"), "Player VS. CPU (Normal)"))
        self.menu.append(
            (effect.Effect(self, (300, 200), "word"), "Player VS. CPU (Hard)"))
        self.menu.append(
            (effect.Effect(self, (300, 250), "word"), "Player VS. Player"))
        self.menu.append(
            (effect.Effect(self, (300, 300), "word"), "CPU VS. CPU"))
        for obj in self.menu:
            self.objList.append(obj[0])
        self.bgcolour = (0, 0, 0)

        self.__bgimg = pygame.image.load(
            "/data/github/linwei/basketball/images/logo.png").convert()
        self.menuSelect = 0

    def __del__(self):
        pass

    def update(self, event):  # event = pygame.event.get()
        for e in event:
            if e.type == pygame.KEYUP:
                self.upkey = 1
            if e.type == pygame.KEYDOWN and self.upkey == 1:
                if e.key == pygame.K_UP:
                    self.upkey = 0
                    self.menuSelect = (self.menuSelect +
                                       len(self.menu) - 1) % len(self.menu)
                if e.key == pygame.K_DOWN:
                    self.upkey = 0
                    self.menuSelect = (self.menuSelect + 1) % len(self.menu)
                if e.key == pygame.K_RETURN or e.key == pygame.K_KP_ENTER:
                    self.status = mybasesprite.ObjStatus.Killed
                    dif = self.menuSelect + 1
                    if dif == 4:
                        dif = 0
                    param = {'gametime': 120 * sceneglobal.sceneParam.fps,
                             'player1': self.menuSelect < 4, 'player2': self.menuSelect == 3, 'diff': dif}
                    self.mainClass.objList = [scenesprite.Scene(
                        self.mainClass, param)]  # main objlist

        for index in range(len(self.menu)):
            if index == self.menuSelect:
                self.menu[index][0].set_col(
                    self.flashColor[self.flashColorIndex])
            else:
                self.menu[index][0].set_col((192, 0, 192))
            self.menu[index][0].write(self.menu[index][1])
        self.flashColorIndex = (self.flashColorIndex +
                                1) % len(self.flashColor)

    def render(self, screen):
        # screen.fill(self.bgcolour)
        self.screen.blit(self.__bgimg, (0, 0))

        objList = self.objList
        for obj in objList:  # render
            obj.render()
