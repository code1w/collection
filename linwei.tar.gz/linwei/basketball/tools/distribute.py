import sys, os
import distutils, shutil
from distutils.dir_util import *

HOME = os.path.normpath(os.path.abspath(os.path.dirname(sys.argv[0])))
HOME = os.path.normpath(os.path.abspath(os.path.join(HOME, '../')))

path = lambda n: os.path.normpath(os.path.abspath(os.path.join(HOME, n)))
os.chdir(HOME)

DIST = path('dist')
dist = lambda n: os.path.normpath(os.path.abspath(os.path.join(DIST, n)))

def mkdir( path):
	if os.path.exists(path):
		return 0
	name = ''
	part = os.path.abspath(path).replace('\\', '/').split('/')
	if (not sys.platform[:3] != 'win') and (path[1:2] == ':'):
		part[0] += '/'
	for n in part:
		name = os.path.abspath(os.path.join(name, n))
		if not os.path.exists(name):
			os.mkdir(name)
	return 0

def copysvn(srcpath, dstpath, ignore_dir = ['.svn'], ignore_ext = ['.pyc']):
	srcpath = os.path.abspath(srcpath)
	dstpath = os.path.abspath(dstpath)
	savepath = os.getcwd()
	os.chdir(srcpath)
	filelist = []
	for root, dirs, files in os.walk(''):
		for exclude in ignore_dir:
			if exclude in dirs:
				dirs.remove(exclude)
		for f in files: 
			extname = os.path.splitext(f)[-1]
			ignore = False
			if extname in ignore_ext:
				continue
			filelist.append((root, f))
	dirlist = {}
	for dir, fn in filelist:
		if dir: 
			dirlist[dir] = 1
			dirlist[os.path.join(dstpath, dir)] = 1
	for dir in dirlist:
		mkdir(os.path.join(dstpath, dir))
	for dir, fn in filelist:
		nm = os.path.join(dir, fn)
		dd = os.path.join(dstpath, dir)
		mkdir(dd)
		print 'copying', nm
		import shutil 
		shutil.copyfile(nm, os.path.join(dd, fn))
	os.chdir(savepath)
	return 0

def copying(mode = 'BOTH'):
	mkdir(DIST)
	build = dist('build')
	if os.path.exists(build): remove_tree(build)
	mkdir(dist('build/AI'))
	if os.path.exists('runtime'):
		copysvn('runtime', dist('runtime'))
	copysvn('AI', dist('AI'), ['.svn'], ['.pyc', '.py'])
	copysvn('images', dist('images'))
	copysvn('sound', dist('sound'))
	copysvn('font', dist('font'))
	for fn in os.listdir('.'):
		ext = os.path.splitext(fn)[-1].lower()
		if ext in ('.ini', '.INI'):
			print 'copying', fn
			shutil.copyfile(fn, os.path.join(DIST, fn))
		if ext in ('.py', '.pyw'):
			print 'copying', fn
			shutil.copyfile(fn, dist('build/' + fn))
	for fn in os.listdir('AI'):
		ext = os.path.splitext(fn)[-1].lower()
		if ext in ('.py', '.pyw'):
			print 'copying', fn
			srcname = os.path.join('AI', fn)
			dstname = os.path.join(build, 'AI/' + fn)
			shutil.copyfile(srcname, dstname)
	return 0

def compiling():
	def compiledir(n):
		dirname = n.replace('/', '\\').replace('\\', '\\\\')
		cmdline = 'import compileall;compileall.compile_dir(\'%s\')'%dirname
		cmdline = 'runtime\python.exe -OO -c "%s"'%cmdline
		os.system(cmdline)
	compiledir(dist('build'))

def archive():
	import zipfile
	def makezip(fname, dirname):
		z = zipfile.ZipFile(fname, "w", compression = zipfile.ZIP_DEFLATED)
		savedir = os.getcwd()
		os.chdir(dirname)
		for root, dirs, files in os.walk(''):
			for n in files:
				if n[-4:] != '.pyo': continue
				source = os.path.join(root, n)
				z.write(source, source)
		os.chdir(savedir)
		z.close()
	zipname = dist('script.zip')
	makezip(zipname, dist('build'))
	return 0

def distribute():
	copying()
	compiling()
	archive()
	if os.path.exists(dist('build')):
		remove_tree(dist('build'))
	if os.path.exists('tools/START.BAT'):
		shutil.copyfile('tools/START.BAT', dist('START.BAT'))
	return 0

if __name__ == '__main__':
	distribute()
	
