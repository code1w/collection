# -*- coding:gb2312 -*-

import pygame
import mybasesprite
import scenesprite
import beginscenesprite

class PauseScene(mybasesprite.MyBaseSprite):
    mainClass = None
    surfLast = None
    img = None
    pos_x = 280
    keyst = 0
    def __init__(self, _main, _screen):
        pygame.init()
        self.mainClass = _main
        self.surfLast = pygame.Surface(_screen.get_size())
        self.surfLast.blit(_screen, (0,0))

        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Inactive
            objSence.visable = mybasesprite.ObjVisable.UnVisable

        self.img = pygame.image.load("/data/github/linwei/basketball/images/pause.png")
        mybasesprite.MyBaseSprite.__init__(self,None,[0,0,0],[0,0,0],0,[])
        self.keyst = 0

    def __del__(self):
        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Active
            objSence.visable = mybasesprite.ObjVisable.Visable

    def update(self, event):
        _obj = self
        for e in event:
            if e.type == pygame.KEYUP and e.key == pygame.K_F2:
                self.keyst = 1
                break
            if self.keyst>0 and e.type == pygame.KEYDOWN and e.key == pygame.K_F2:
                self.status = mybasesprite.ObjStatus.Killed

    def render(self, screen):
        screen.blit(self.surfLast, (0,0))
        screen.blit(self.img, (self.pos_x , 150))
