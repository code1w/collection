# -*- coding:gb2312 -*-
import pygame
import mybasesprite
import scenesprite
import animationsprite
import sys
import random
defaultencoding = sys.stdout.encoding

class Effect(mybasesprite.MyBaseSprite):
    offsetx = -2
    offsety = -2
    col = (255, 255, 255)
    col_behind = (0, 0, 0)
    font_size = 40
    _str = ""
    internal_type = "word"
    words = None
    lenth = 8
    head = 0
    head2 = 0
    tail = 0
    index = 0
    have_speak = ""
    count = 0
    timer = 0
    comment_random = [u"���������к�������������ע�����尡",
                      u"���Ǵ��Ĳ��������Ǽ�į�����ǿ��Ĳ��������Ǽ�į",
                      u"�ף�����Ҳ�������ˣ������Ͽ�ȥ��ǩ��",
                      u"�з��Ĺ���һ���Ⱥ������ˣ���Ϊ�����ڳ���������������",
                      u"������Ҫѧ������Ϊ��",
                      u"��Ѫ���ǳ����������ϵķɻ������������絽�������ġ�",
                      u"���ڳ��ϻ�ҩζ��Ũ�����Ӷ�Ա�ڳ����������������ӵĽ���Ҳ�ڳ��������Դ�",
                      u"�ո��յ����Ĺ��ڵĶ��ţ��ʣ���Ѫ�˴����ǰ�������",
                      u"���ڳ��������˽��֣�������Ա����վ�����÷֣�",
                      u"��Ѫ�����ߵ�����˹��ս�����÷���ˮ����"]

    def __init__(self, scene, xy, _type):
        self.internal_type = _type
        self.scene = scene
        self.pos = xy
        if _type == "word": self.word_init()
        elif _type == "boom": self.boom_init()
        elif _type == "dialog": self.dialog_init()
        elif _type == "table": self.table_init()
        mybasesprite.MyBaseSprite.__init__(self, self.scene, [0, 0, 0], [0, 0, 0], mybasesprite.ObjType.Effect, None)
        
    def word_init(self):
        self.text = None
        self.text_behind = None
        self.set_font_size(self.font_size)
        self.set_pos(self.pos)

    def boom_init(self):
        self.ani_boom = animationsprite.AnimationSprite(self.scene, '/data/github/linwei/basketball/images/boom/', 'boom.ini')
        self.ani_boom.play()

    def dialog_init(self):
        self.ani_word = animationsprite.AnimationSprite(self.scene, '/data/github/linwei/basketball/images/dialog/', 'dialog.ini')
        self.ani_word.set_alpha(190)
        self.ani_word.play()
        self.ani_word.set_xywh([self.pos[0] - 50, self.pos[1] - 35, 115, 60])
        self.font_size = 12
        self.col = 0, 0, 0
        self.text = None
        self.text_behind = None
        self.font = pygame.font.Font("./font/simsun.ttc", self.font_size)
        self.font.set_bold(True)
        self.set_pos(self.pos)

    def table_init(self):
        self.words = [""] * self.lenth
        self.font_size = 20
        self.col = 255, 255, 255
        self.font = pygame.font.Font("./font/simsun.ttc", self.font_size)

    def write(self, text):
        self._str = text
        self.text = self.font.render(text, 1, self.col)
        if self.internal_type != "dialog":
            self.text_behind = self.font_behind.render(text, 1, self.col_behind)
        #self.offsetx = (self.font_behind.size(text)[0] - self.font.size(text)[0]) / 2.0
        #self.offsety = (self.font_behind.size(text)[1] - self.font.size(text)[1]) / 2.0
        self.set_pos(self.pos)
        if self.internal_type == "dialog":
            self.ani_word.play()

    def set_font_size(self, size, is_bold=True):
        self.font_size = size
        self.font_behind_size = size
        self.offsetx = -size / 15
        self.offsety = -size / 15
        self.font = pygame.font.Font("./font/simsun.ttc", self.font_size)
        self.font.set_bold(is_bold)
        self.font_behind = pygame.font.Font("./font/simsun.ttc", self.font_behind_size)
        self.font_behind.set_bold(is_bold)
        self.write(self._str)

    def set_pos(self, pos):
        if self.internal_type == "word":
            self.pos = pos
            self.pos_behind = (pos[0] - self.offsetx, pos[1] - self.offsety)
        elif self.internal_type == "boom":
            self.ani_boom.set_xywh(pos)
        elif self.internal_type == "dialog":
            self.pos = pos
            self.ani_word.set_xywh([self.pos[0] - 50, self.pos[1] - 35, len(self._str) * self.font_size * 1.2, self.font_size * 2.5])

    def speak(self, words):
        self.timer = 0
        if self.count != 0:
            self.words[self.head2] = self.font.render(self._str, 1, self.col)
        self._str = words
        self.index = 0
        self.have_speak = ""
        if self.count >= self.lenth:
            #self.words[self.head] = self.font.render(words, 1, self.col)
            self.head2 = self.head
            self.head = (self.head + 1) % self.lenth
            self.tail = (self.tail + 1) % self.lenth
        else:
            #self.words[self.tail] = self.font.render(words, 1, self.col)
            self.head2 = self.tail
            self.tail = (self.tail + 1) % self.lenth
        self.count += 1

    def color(self, j):
        if j % 2 == 0:
            return (32, 3, 75)
        else:
            return (9, 71, 40)

    def render(self):
        if self.internal_type == "word":
            self.scene.screen.blit(self.text_behind, self.pos_behind)
            self.scene.screen.blit(self.text, self.pos)
        elif self.internal_type == "boom":
            self.ani_boom.render()
        elif self.internal_type == "dialog":
            self.ani_word.render()
            if self.ani_word.finish():
                self.scene.screen.blit(self.text, (self.pos[0] - 42, self.pos[1] - 30))            
        elif self.internal_type == "table":
            x = 10
            y = 360
            j = 0
            self.scene.screen.fill((0,0,0), pygame.Rect(0, 357, 1000, 400))
            if self.index < len(self._str):
                self.have_speak += self._str[self.index]
                self.words[self.head2] = self.font.render(self.have_speak, 1, self.col)
                self.index += 1
            if self.count >= self.lenth:
                for i in xrange(self.head, self.lenth):
                    self.scene.screen.fill(self.color(j), pygame.Rect(0, 357 + j * 28, 950, 28))
                    self.scene.screen.blit(self.words[i], (x, y))
                    y = y + 28
                    j = j + 1
                for i in xrange(0, self.tail):
                    self.scene.screen.fill(self.color(j), pygame.Rect(0, 357 + j * 28, 950, 28))
                    self.scene.screen.blit(self.words[i], (x, y))
                    j = j + 1
                    y = y + 28
            else:
                for i in xrange(self.head, self.tail):
                    self.scene.screen.fill(self.color(j), pygame.Rect(0, 357 + j * 28, 950, 28))
                    self.scene.screen.blit(self.words[i], (x, y))
                    j = j + 1
                    y = y + 28

    def set_col(self, col, col_behind = None):
        self.col = col
        if col_behind:
            self.col_behind = col_behind

    def update(self):
        if self.internal_type == "boom":
            self.ani_boom.update()
        elif self.internal_type == "dialog":
            if not self.ani_word.finish():
                self.ani_word.update()
        elif self.internal_type == "table":
            self.timer += 1
            if self.timer > 300:
                tmp = self.comment_random[random.randint(0,len(self.comment_random) - 1)]
                self.speak(tmp)


if __name__ == "__main__":
    param = {'gametime': 60*10}
    pygame.init()
    pygame.display.init()
    bgimg = pygame.image.load("/data/github/linwei/basketball/images/background4.png")
    screen = pygame.display.set_mode((bgimg.get_rect().width, bgimg.get_rect().height))
    scene = scenesprite.Scene(None, param)
    scene.screen = screen
    e = Effect(scene, (420, 40), "dialog")
    e.write("hello world")
    e2 = Effect(scene, (420, 150), "dialog")
    e2.write("attack")
    while True:
        e.render()
        e2.render()
        pygame.display.flip()