import string
import pygame
import mybasesprite
import configp


class AnimationSprite(mybasesprite.MyBaseSprite):
    # type of this class
    __type = mybasesprite.ObjType.AnimationSprite
    iniFile = ''
    imgList = []
    timeList = []

    __frame = 0
    __tTime = 0
    __bPlay = 0
    __nLoop = 0

    xywh = 0, 0, 0, 0
    img2 = None
    alpha = None

    def __init__(self, scene, path, filename):
        '''Construction'''
        pygame.init()
        self.__scene = scene
        self.iniFile = configp.ConfigP(path + filename)
        self.imgList = []
        self.timeList = []
        frametime = self.iniFile.get('animation', 'frametime')
        for n in range(128):
            s = 'f' + str(n)
            file = self.iniFile.get('animation', s)
            if file == None:
                break
            img = pygame.image.load(path + file)
            s = 't' + str(n)
            file = self.iniFile.get('animation', s)
            if file == None:
                file = frametime
            self.timeList.append(int(file))
            s = 's' + str(n)
            file = self.iniFile.get('animation', s)
            if file <> None:
                nlist = file.split(',')
                if len(nlist) >= 4:
                    rect = int(nlist[0]), int(nlist[1]), int(
                        nlist[2]), int(nlist[3])
                    img2 = pygame.Surface(
                        (rect[2] - rect[0], rect[3] - rect[1]))
                    img2.blit(img, (0, 0), rect)
                    img = img2
            self.imgList.append(img)
        xywh = 0, 0, self.imgList[0].get_width(), self.imgList[0].get_height()
        self.__nLoop = 0
        self.set_xywh(xywh)
        mybasesprite.MyBaseSprite.__init__(
            self, None, [0, 0, 0], [0, 0, 0], 0, [])

    def get_wh(self, index=0):
        return self.imgList[index].get_size()

    def play(self):
        self.__bPlay = 1
        self.__nLoop = 0

    def stop(self):
        self.__bPlay = 0

    def get_loop(self):
        return self.__nLoop

    def update(self):
        if self.__bPlay:
            self.__tTime += 1
            if self.__tTime >= self.timeList[self.__frame]:
                self.__frame = (self.__frame + 1) % len(self.imgList)
                if self.__frame == 0:
                    self.__nLoop += 1
                img = self.imgList[self.__frame]
                if self.alpha:
                    # smoothscale will change the color in many pixels, this
                    # will make the colorkey not correct
                    self.img2 = pygame.transform.scale(
                        img, (self.xywh[2], self.xywh[3]))
                else:
                    self.img2 = pygame.transform.smoothscale(
                        img, (self.xywh[2], self.xywh[3]))
                self.__tTime = 0

    def set_xywh(self, _xywh):
        self.xywh = int(_xywh[0]), int(_xywh[1]), int(_xywh[2]), int(_xywh[3])
        img = self.imgList[self.__frame]
        if self.alpha:
            self.img2 = pygame.transform.scale(
                img, (self.xywh[2], self.xywh[3]))
        else:
            self.img2 = pygame.transform.smoothscale(
                img, (self.xywh[2], self.xywh[3]))

    def render(self):
        if self.alpha:
            # destroy the alpha imformation in each pixel, or the alpha set by
            # the user and the colorkey will not work
            self.img2 = self.img2.convert()
            self.img2.set_alpha(self.alpha)
            self.img2.set_colorkey(self.img2.get_at(
                (2, self.img2.get_height() - 2)))
        self.__scene.screen.blit(self.img2, self.xywh,
                                 (0, 0, self.xywh[2], self.xywh[3]))
        #self.__scene.screen.blit(img, self.translate(self.xyz), (0,0,img.get_width(),img.get_height()))

    def finish(self):
        return self.__frame == len(self.imgList) - 1

    def set_alpha(self, alpha):
        self.alpha = alpha


if __name__ == "__main__":
    a = AnimationSprite(
        None, '/data/github/linwei/basketball/images/', 'right.ini')
    b = AnimationSprite(
        None, '/data/github/linwei/basketball/images/', 'stand_left.ini')
