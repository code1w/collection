# -*- coding:gb2312 -*-

'''This module defines basketball team class'''

import sys,pygame
import math
import mybasesprite
import playersprite
import sceneglobal


class TeamSprite(mybasesprite.MyBaseSprite):
    '''Basketball Team sprite'''
    
    def __init__(self,id,name,is_human_control,scene,side,player_list,circle_ani,type=mybasesprite.ObjType.TeamSprite):
        '''Construction'''
        #id of team
        self.__id = id
        #name of team
        self.name = name
        #if it is False, it is controlled by computer
        self.is_human_control = is_human_control
        #side of team
        self.__side = side
        #players of this team
        self.__player_list = player_list
        #index of current player
        self.__cur_p_index = 0
        #reference to current player
        self.__cur_player = self.__player_list[0]
        self.update_human_control()
        #reference to player who controls the ball
        self.__control_ball_player = None
        #reference to player who is passing a ball
        self.__passing_player = None
        #reference to player who is nearest the ball
        self.__nearest_player = None
        #reference to the ball
        self.__ball = scene.get_ball()
        self.__key_A_state = [0] * len(player_list)
        #current status of key 'B'
        self.__key_B_state = [0] * len(player_list)
        #current status of key 'C'
        self.__key_C_state = [0] * len(player_list)
        #current status of key 'D'
        self.__key_D_state = [0] * len(player_list)
        #if it is True, action 'pressing A' will be ignored
        self.__ignore_A = [False] * len(player_list)
        #if it is True, action 'pressing B' will be ignored
        self.__ignore_B = [False] * len(player_list)
        #pass count
        self.__pass_count = [0] * len(player_list)
        #is the player going to pass
        self.__going_to_pass = [False] * len(player_list)
        #shoot count
        self.__shoot_count = [0] * len(player_list)
        #stop after attack
        self.__frame_after_attack = [0] * len(player_list)
        #frame_after_attack
        self.__const_frame = 20
        self.team_control_ball = False
        self.control_ball_state_list = [playersprite.CONTROL_BALL,playersprite.PASSING,playersprite.SHOOTING,playersprite.DUNKING]
        self.not_change_cur_player = False
        for p in player_list:
            p.team_id = id
        mybasesprite.MyBaseSprite.__init__(self,scene,[0,0,0],[1,1,1],type)
        #circle animation
        self.__circle_ani = circle_ani
        self.__circle_ani.set_alpha(130)
        self.set_circle_pos()
        #current status of key 'A'
    
    def update_human_control(self):
        for p in self.__player_list:
            if p is self.__cur_player and self.is_human_control:
                p.is_human_control = True
            else:
                p.is_human_control = False
    
    def get_control_ball_player(self):
        return self.__control_ball_player

    def get_side(self):
        return self.__side
    
    def get_id(self):
        return self.__id
    
    def __distance(self,xyz1,xyz2):
        '''get distance from xyz1 to xyz2'''
        return math.sqrt((xyz1[0] - xyz2[0])*(xyz1[0] - xyz2[0]) +\
                         (xyz1[1] - xyz2[1])*(xyz1[1] - xyz2[1]) +\
                         (xyz1[2] - xyz2[2])*(xyz1[2] - xyz2[2]))
    def __get_signal(self,x):
        if x > 0:
            return 1.0
        elif x < 0:
            return -1.0
        else:
            return 0.0
    
    def get_player_id_in_team(self,p):
        return p.get_id() % len(self.__player_list)
    
    def get_player_by_id(self,id):
        p = self.__player_list[id % len(self.__player_list)]
        if p.get_id() == id:
            return p
        else:
            return None
    
    def change_player(self):
        mval, mpos = min([(self.__distance(self.__player_list[i].xyz,self.__ball.xyz), i) for i in xrange(len(self.__player_list))])
        self.__cur_p_index = self.get_player_id_in_team(self.__player_list[mpos])
        self.__cur_player = self.__player_list[mpos]
        self.update_human_control()
    
    def pass_ball(self,obj,count):
        #pass the ball to another player
        orient = obj.get_face_orientation()
        if orient[0] == 0 or orient[1] == 0:
            valid_val = -0.5
        else:
            valid_val = -1.5
        result = [None,valid_val,-1]
        for p in self.__player_list:
            if p is not obj:
                val = self.__get_signal((p.xyz[0] - obj.xyz[0]) * orient[0]) +\
                      self.__get_signal((p.xyz[1] - obj.xyz[1]) * orient[1])
                dist = self.__distance(p.xyz,obj.xyz)
                if val > result[1] or (val == result[1] and dist < result[2]):
                    result = [p,val,dist]
        if result[0] == None:
            #throw the ball
            obj.abandom_ball()
            obj.stop_pick_ball_momently()
            ball_speed = 50 + count
            self.__ball.set_speed([orient[0]*ball_speed,orient[1]*ball_speed,10],0,None)
        else:
            obj.pass_ball(result[0],count)
            #self.__cur_player = result[0]        
    
    def press_key(self,key_state_list):
        '''when a key is pressed, invoke it. Parameter is key board state.
        This function must be invoked before update'''
        
        for i in xrange(len(key_state_list)):
            obj,key_state = key_state_list[i][0],key_state_list[i][1]
            id = self.get_player_id_in_team(obj)

            if self.__frame_after_attack[id] > 0:
                self.__frame_after_attack[id] -= 1
                if self.__frame_after_attack[id] < self.__const_frame - 2:
                    key_state[mybasesprite.A_I] = 0
                    key_state[mybasesprite.B_I] = 0
                    key_state[mybasesprite.C_I] = 0
                    key_state[mybasesprite.D_I] = 0
                    continue

            #check whether pass ball or change player
            if key_state[mybasesprite.A_I] == self.__key_A_state[id]:
                #the key status has not changed.
                key_state[mybasesprite.A_I] = 0
                if self.__key_A_state[id] == 1:
                    #passing force increase
                    self.__pass_count[id] += 1
                    if obj.get_internal_state() == playersprite.PASSING:
                        if self.__pass_count[id] >= obj.get_max_pass_count():
                            #pass count is too large, force player to pass
                            self.pass_ball(obj,obj.get_max_pass_count())
                            self.__ignore_A[id] = True
            else:
                self.__key_A_state[id] = key_state[mybasesprite.A_I]
                if self.__key_A_state[id] == 1:
                    if obj.get_internal_state() == playersprite.CONTROL_BALL:
                        #begin to pass ball
                        obj.pre_pass_ball()
                    if obj.get_internal_state() == playersprite.NO_BALL:
                        if self.__control_ball_player == None:
                            if obj.is_human_control:
                                #change player
                                self.change_player()
                        elif not self.__going_to_pass[id]:
                            #this player call for the ball
                            self.__control_ball_player.pre_pass_ball()
                            self.__passing_player = self.__control_ball_player
                            self.__going_to_pass[id] = True
                else:
                    if self.__ignore_A[id]:
                        self.__ignore_A[id] = False
                    elif obj.get_internal_state() == playersprite.PASSING:
                        #end of passing. the ball will be passed really
                        self.pass_ball(obj,self.__pass_count[id])
                    self.__pass_count[id] = 0

            #check whether shoot
            if key_state[mybasesprite.B_I] == self.__key_B_state[id]:
                #the key status has not changed.
                key_state[mybasesprite.B_I] = 0
                if obj.get_internal_state() == playersprite.SHOOTING:
                    #shooting force increase
                    self.__shoot_count[id] += 1
                elif self.__shoot_count[id] > 0:
                    #key B is pressed too long, it is forced to shoot
                    self.__ignore_B[id] = True
            else:
                self.__key_B_state[id] = key_state[mybasesprite.B_I]
                if obj.get_internal_state() == playersprite.CONTROL_BALL and\
                   self.__key_B_state[id] == 1:
                    #begin to shoot ball
                    self.__shoot_count[id] = 0
                    obj.pre_shoot()
                if self.__key_B_state[id] == 0:
                    if self.__ignore_B[id]:
                        self.__ignore_B[id] = False
                    else:
                        if obj.get_internal_state() == playersprite.SHOOTING:
                            #end of shooting. the ball will be shooted really
                            obj.shoot()
                    self.__shoot_count[id] = 0
            
            #check whether attack
            if key_state[mybasesprite.D_I] == self.__key_D_state[id]:
                #the key status has not changed.
                key_state[mybasesprite.D_I] = 0
            else:
                self.__key_D_state[id] = key_state[mybasesprite.D_I]
                if self.__key_D_state[id] == 1 and\
                   obj.get_internal_state() == playersprite.NO_BALL:
                    #attack
                    obj.attack()
                    self.__frame_after_attack[id] = self.__const_frame

            #check whether change current player
            if obj is self.__cur_player:
                if key_state[mybasesprite.P1_I] != 0:
                    self.__cur_player = self.__player_list[0]
                    self.update_human_control()
                    is_changed = True
                elif key_state[mybasesprite.P2_I] != 0:
                    self.__cur_player = self.__player_list[1]
                    self.update_human_control()
                    is_changed = True
                elif key_state[mybasesprite.P3_I] != 0:
                    self.__cur_player = self.__player_list[2]
                    self.update_human_control()
                    is_changed = True
                else:
                    is_changed = False
                
                if is_changed and self.team_control_ball:
                    if self.__cur_player.get_internal_state() not in self.control_ball_state_list:
                        #player want to control a no-ball player, do not change it until he wants
                        self.not_change_cur_player = True
                    else:
                        self.not_change_cur_player = False

            
            #check whether jump or speed up
            if key_state[mybasesprite.C_I] == self.__key_C_state[id]:
                #the key status has not changed.
                key_state[mybasesprite.C_I] = 0
            else:
                self.__key_C_state[id] = key_state[mybasesprite.C_I]
                if self.__key_C_state[id] == 1:
                    if obj.get_internal_state() == playersprite.NO_BALL:
                        #begin to jump
                        obj.jump()
                    elif obj.get_internal_state() == playersprite.CONTROL_BALL:
                        #begin to speed up
                        obj.speed_up()

            #check whether move this player or not
            if key_state[mybasesprite.UP_I] != 0 or\
               key_state[mybasesprite.DOWN_I] != 0 or\
               key_state[mybasesprite.LEFT_I] != 0 or\
               key_state[mybasesprite.RIGHT_I] != 0 :
                obj.move(key_state)
    
    def get_cur_player(self):
        return self.__cur_player
    
    def get_player_list(self):
        return self.__player_list
    
    def update(self):
        self.team_control_ball = False
        for p in self.__player_list:
            if p.get_internal_state() in self.control_ball_state_list:
                self.team_control_ball = True
            if not self.team_control_ball and self.__ball.tar_player in self.__player_list:
                self.team_control_ball = True
        if not self.team_control_ball: self.not_change_cur_player = False
        #if a player call for the ball, here we should make the ball be passed to him
        self.__passing_player = self.__control_ball_player
        if self.__passing_player != None:
            for id in xrange(len(self.__player_list)):
                if self.__passing_player is not self.__player_list[id] and\
                   self.__going_to_pass[id]:
                    #this player has called for the ball, the ball should be passed
                    self.__player_list[id].set_state_effect(u'�򣡿������')
                    pass_ratio = float(self.__distance(self.__passing_player.xyz,self.__player_list[id].xyz)) / float(self.__distance([sceneglobal.sceneParam.scene_w,0,0],[0,sceneglobal.sceneParam.scene_h,0]))
                    tmp_pass_count = int(self.__player_list[id].get_max_pass_count() * pass_ratio)
                    if tmp_pass_count <= 0:
                        tmp_pass_count = 1
                    self.__passing_player.pass_ball(self.__player_list[id],tmp_pass_count)
                    self.__going_to_pass[id] = False
                    self.__ignore_A[id] = True
        #if someone controls the ball but he is not current player, let him to be
        if self.__cur_player.get_internal_state() != playersprite.CONTROL_BALL:
            self.__control_ball_player = None
            for p in self.__player_list:
                if p.is_it_pick_ball_justnow() and not self.not_change_cur_player and self.is_human_control:
                    self.__key_A_state[self.get_player_id_in_team(p)] = self.__key_A_state[self.get_player_id_in_team(self.__cur_player)]
                    self.__key_B_state[self.get_player_id_in_team(p)] = self.__key_B_state[self.get_player_id_in_team(self.__cur_player)]
                    self.__key_C_state[self.get_player_id_in_team(p)] = self.__key_C_state[self.get_player_id_in_team(self.__cur_player)]
                    self.__ignore_A[self.get_player_id_in_team(p)] = self.__ignore_A[self.get_player_id_in_team(self.__cur_player)]
                    self.__ignore_B[self.get_player_id_in_team(p)] = self.__ignore_B[self.get_player_id_in_team(self.__cur_player)]
                    self.__cur_player = p
                    self.update_human_control()
                if p.get_internal_state() == playersprite.CONTROL_BALL:
                    self.__control_ball_player = p
        else:
            self.__control_ball_player = self.__cur_player
        #update current player's circle
        self.set_circle_pos()
        self.__circle_ani.update()
    
    def set_circle_pos(self):
        half_l = self.__cur_player.get_lwh()[0] / 2.0
        half_w = self.__cur_player.get_lwh()[1] / 2.0
        half_h = self.__cur_player.get_lwh()[2] / 2.0
        x, y = self.translate([self.__cur_player.xyz[0], self.__cur_player.xyz[1], self.__cur_player.xyz[2] - half_h])
        w, h = half_l * 3.6, half_w * 1.6
        self.__circle_ani.set_xywh((x - w/2.0, y - h/2.0, w, h))
        

    def render(self):
        '''render current player's circle.'''
        self.__circle_ani.render()
        
    