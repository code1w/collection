import copy
class ConfigP:
    "Mini ConfigParser"
    dic={}
    def __init__ (self, filename):
        section = ""
        self.dic = {}
        try:
            f = open(filename, 'r')
            for line in f:
                str = line.strip(' \r\n\t')
                if len(str)<=0 or str[0]=='#':
                    continue
                elif str[0]=='[':
                    section = str[1:str.find(']')]
                elif (str.find('='))>0:
                    if not section in self.dic:
                        self.dic[section] = {}
                    self.dic[section][str[0:str.find('=')].strip(' \r\n\t')] = str[str.find('=')+1:].strip(' \r\n\t')
            f.close();
        except IOError:
            raise IOError
        except Exception:
            pass
    def get (self, section, item):
        try:
            return self.dic[section][item]
        except Exception:
            return None

    def getdic (self):
        return copy.deepcopy(self.dic)
