# -*- coding:gb2312 -*-

import pygame
import mybasesprite
import scenesprite
import beginscenesprite
import effect

class GameoverScene(mybasesprite.MyBaseSprite):
    mainClass = None
    surfLast = None
    objList = []
    screen = None

    img = None
    pos_x = 200
    menuSelect = 0
    flashColor = [(255,0,0),(240,16,0),(224,32,0),(208,48,0),(192,64,0),(176,80,0),(160,96,0),(144,112,0),(128,128,0),\
                    (112,144,0),(96,160,0),(80,176,0),(64,192,0),(48,208,0),(32,224,0),(16,240,0),\
                  (0,255,0),(0,240,16),(0,224,32),(0,208,48),(0,192,64),(0,176,80),(0,160,96),(0,144,112),(0,128,128),\
                    (0,112,144),(0,96,160),(0,80,176),(0,64,192),(0,48,208),(0,32,224),(0,16,240),\
                  (0,0,255),(16,0,240),(32,0,224),(48,0,208),(64,0,192),(80,0,176),(96,0,160),(112,0,144),(128,0,128),\
                    (144,0,112),(160,0,96),(176,0,80),(192,0,64),(208,0,48),(224,0,32),(240,0,16),\
                 ]
    flashColorIndex = 0

    def __init__(self, _main, _screen, word):
        pygame.init()
        self.mainClass = _main
        self.surfLast = pygame.Surface(_screen.get_size())
        self.surfLast.blit(_screen, (0,0))
        self.screen = _screen
        self.objList = []

        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Inactive
            objSence.visable = mybasesprite.ObjVisable.UnVisable

        self.img = pygame.image.load("/data/github/linwei/basketball/images/gameover.png")
        mybasesprite.MyBaseSprite.__init__(self,None,[0,0,0],[0,0,0],0,[])
        self.menu = []
        self.menu.append((effect.Effect(self, (200, 250), "word"), "Press ESC return main menu"))
        self.menu.append((effect.Effect(self, (400, 200), "word"), word))
        for obj in self.menu:
            self.objList.append(obj[0])

    def __del__(self):
        for objSence in self.mainClass.objList:
            objSence.active = mybasesprite.ObjActive.Active
            objSence.visable = mybasesprite.ObjVisable.Visable

    def del_object_list(self):
        pass

    def update(self, event):
        _obj = self
        for e in event:
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                #self.status = mybasesprite.ObjStatus.Killed
                #self.mainClass.objList.remove(self)
                for objSence in self.mainClass.objList:
                    #if objSence
                    objSence.del_object_list()
                self.mainClass.objList = []
                self.mainClass.objList = [beginscenesprite.BeginScene(self.mainClass)]
        for index in range(len(self.menu)):
            if index == self.menuSelect:
                self.menu[index][0].set_col(self.flashColor[self.flashColorIndex])
            else:
                self.menu[index][0].set_col((192,0,192))
            self.menu[index][0].write(self.menu[index][1])
        self.flashColorIndex = (self.flashColorIndex+1) % len(self.flashColor)

    def render(self, screen):
        screen.blit(self.surfLast, (0,0))
        screen.blit(self.img, (self.pos_x , 100))
        objList = self.objList
        for obj in objList: #render
            obj.render();
