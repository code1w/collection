import pygame, sys
import mybasesprite

class BasketSprite(mybasesprite.MyBaseSprite):
    score = 0
    teamid = 1
    goal = False
	
    def __init__(self, scene, xyz, lwh, teamid):
        self.teamid = teamid
        crash_type_list = [mybasesprite.ObjType.BallSprite]
        mybasesprite.MyBaseSprite.__init__(self, scene, xyz, lwh, mybasesprite.ObjType.BasketSprite, crash_type_list)

    def add_score(self, num):
        self.score += num
        self.goal = True

    def get_score(self):
        return self.score

    def is_goal(self):
        if self.goal:
            self.goal = False
            return True
        else: return False