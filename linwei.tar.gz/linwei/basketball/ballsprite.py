# -*- coding:gb2312 -*-
import pygame, sys, math
import random
import copy
import mybasesprite
import animationsprite
import scenesprite
import configp
import effect
import sceneglobal

sceneParam = sceneglobal.sceneParam

ObjType = mybasesprite.ObjType
ObjStatus = mybasesprite.ObjStatus

class BallStr:
    owner_player = -1
    owner_team = -1
    xyz = []
    speed = [0.0, 0.0, 0.0]
    acceleration = [0.0, 0.0, 0.0]
    is_rebound = False
    is_passed = False
    is_shot = False
    owner_xyz = []
    have_goal_defend = False
    have_goal_attack = False
    goal_basket = None
    tar_team = None

class BallSprite(mybasesprite.MyBaseSprite):
    is_rebound = False
    speed = [0.0, 0.0, 0.0]
    acceleration = [0.0, 0.0, 0.0]
    owner = None
    goal = False
    dribble = -8.0
    frame_time = 0.2
    dec = 40
    basket_dec = 60
    friction = 0.99
    gravity = sceneParam.gravity
    touch = 1
    internal_status = "free"
    __half_l = -1.0
    __half_w = -1.0
    __half_h = -1.0
    pas = False
    boom_size = 60
    ball_str = BallStr()
    is_passed = False
    is_shot = False
    is_dunk = False
    catch_pass_p = 0.3
    can_be_caught = True
    tar_player = None
    tar_team = None
    have_goal_defend = False
    have_goal_attack = False
    goal_basket = None

    prep_words = [u"", u"������ʱ,", u"��ʱ,", u"��!", u"��!", u"ע��!"]
    adj_words = [u"", u"��ŭ��", u"��ǿ��", u"��˵�е�"]
    bad_adv_words = [u"", u"�Ǳ���", u"ʹ����", u"ҡҡ�λε�", u"�ִٵ�", u"������", u"��ŭ��", u"���е�", u"��ɥ��", u"������", u"������"]
    good_adv_words = [u"", u"�ɿ���", u"���ݵ�", u"���ϵ�", u"���ɵ�", u"רҵ��", u"������", u"���ŵ�", u"���ɵ�", u"������", u"��������", u"���ֵ�", u"����ò��", u"ȫ����ע��", u"̹�ʵ�"]
    v_words = [u"Ͷ��", u"Ͷ����", u"�������˳�ȥ", u"����һ��"]
    conclu_words = [u",���ܰ���ס����ô��", u",�������ǳ��ؼ���", u",������Ŀ�Դ�"]

#    comment_shoot = [u"%sһ������ͻ���˺����ķ��ߣ��߸�Ծ������Ҫ����", u"%s��Ҫ���ˣ�����������ʧ��", u"�������ǳ��ؼ���%s�ܰ���ס������"]
    result_goal = [u"������!!", u"����!!", u"���ģ������ˣ�",u"���򣡣������úð���"]
    result_not_goal = [u"��ƫ��..", u"������������..", u"������Ȧ��������..", u"���Ǵ���..."]
    comment_goal = [u"%s���־���ħ��ʦ���е�ħ����һ��", u"�����ո����ɣ�%s����Ŭ��", u"��%s,�����ǽ̿���һ����Ͷ��", u"%sƾ�Ĳ����������Ƕ�����", u"%s��������������������", u"%s�������總��һ�㣬��������̫����˼����", u"%s�Ѿ���Խ����",u"��Ҫ����%s����ֻ�Ǹ���˵"]
    comment_not_goal = [u"����һ����,�͵���ײײ��,��Ȼû����", u"�����Ļ��ᶼ�˷���", u"�����ԶԷ���˵��û��ʲô��в", u"��ѽ ��Ҳ̫���˰�", u"����Ͷ��ȱ������", u"������Ȼû��������ʶ�ܺ�",u"��Ȼû���򣬵��Ǿ�Ӧ��������",u"���ţ���������������~"]
    shooter = None

    def __init__(self, anilist, scene, xyz, lwh):
        self.read_ini()
        self.ground = scene.get_scene_wh()
        self.ani_ball = anilist[0]
        self.ani_touch = anilist[1]
        self.ani_shadow = anilist[2]
        self.ani_arrow = anilist[3]
        self.ani_arrow.set_alpha(180)
        self.ani_arrow2 = anilist[4]
        self.ani_arrow2.set_alpha(180)
        crash_type_list = [ObjType.PlayerSprite, ObjType.BasketSprite]
        self.__half_l = lwh[0] / 2.0
        self.__half_w = lwh[1] / 2.0
        self.__half_h = lwh[2] / 2.0
        mybasesprite.MyBaseSprite.__init__(self, scene, xyz, lwh, ObjType.BallSprite,crash_type_list)
        self.acceleration[2] = self.gravity
        self.internal_status = "free"
        self.boom_effect = effect.Effect(scene, None, "boom")
        self.make_str()
        self.__con_move_sound = 0
        #Jumping ���ӵĲ���
        self.__is_dunk = 0
        self.__dunk_play = 0

    def get_attrib(self):
        self.make_str()
        return copy.copy(self.ball_str)

    def make_str(self):
        if self.owner != None:
            self.ball_str.owner_player = self.owner.get_id()
            self.ball_str.owner_team = self.owner.team_id
            if self.owner.team_id == 11:
                self.ball_str.owner_player -= 3
        else:
            self.ball_str.owner_player = -1
            self.ball_str.owner_team = -1
        self.ball_str.xyz = self.xyz
        self.ball_str.speed = self.speed
        self.ball_str.acceleration = self.acceleration
        self.ball_str.is_rebound = self.is_rebound
        self.ball_str.is_passed = self.is_passed
        self.ball_str.is_shot = self.is_shot
        self.ball_str.have_goal_defend = self.have_goal_defend
        self.ball_str.have_goal_attack = self.have_goal_attack
        self.ball_str.goal_basket = self.goal_basket
        if self.tar_team:
            self.ball_str.tar_team = self.tar_team
        if self.owner:
            self.ball_str.owner_xyz = self.owner.xyz

    def read_ini(self):
        myfile = configp.ConfigP("ball.ini")
        self.dribble = float(myfile.get('ball', 'dribble'))
        self.frame_time = float(myfile.get('ball', 'frame_time'))
        self.dec = float(myfile.get('ball', 'dec'))
        self.friction = float(myfile.get('ball', 'friction'))
        self.basket_dec = float(myfile.get('ball', 'basket_dec'))
        self.boom_size = float(myfile.get('ball', 'boom_size'))
        self.catch_pass_p = float(myfile.get('ball', 'catch_pass_p'))

    def set_speed(self, speed, goal, _type):
        if _type:
            if _type == "pass":
                self.is_passed = True
            else:
                if not self.is_dunk:
                    if random.random() > 0.5:
                        adv = self.bad_adv_words[random.randint(0,len(self.bad_adv_words) - 1)]
                    else:
                        adv = self.good_adv_words[random.randint(0,len(self.good_adv_words) - 1)]
                    tmp = self.prep_words[random.randint(0,len(self.prep_words) - 1)] + self.adj_words[random.randint(0,len(self.adj_words) - 1)] + self.shooter + adv + self.v_words[random.randint(0,len(self.v_words) - 1)] + self.conclu_words[random.randint(0,len(self.conclu_words) - 1)]
                    if random.random() < 2.0 / 3.0:
                        self.get_scene().speak(tmp)
                    self.__is_dunk = False
                else:
                    self.is_dunk = False
                    self.__is_dunk = True
                self.is_shot = True
        self.pas = False
        self.internal_status = "free"
        self.owner = None
        self.speed = speed
        self.goal = goal
        if random.random() > self.catch_pass_p:
            self.can_be_caught = False
        else:
            self.can_be_caught = True

    def update(self):
        if self.internal_status == "free": self.free_move()
        elif self.internal_status == "dribbling": self.con_move()
        elif self.internal_status == "stop": self.stop_move()
        lwh = mybasesprite.MyBaseSprite.get_lwh(self)
        #update the position of the shadow
        t = self.translate([self.xyz[0], self.xyz[1], 0])
        t[0] -= lwh[0] / 2.0
        t[1] -= lwh[0] / 2.0
        t.extend([lwh[0], lwh[0]])
        self.ani_shadow.set_xywh(t)
        self.ani_shadow.update()
        #update the position of the touch
        t = self.translate(self.xyz)
        t[0] -= lwh[0] / 2.0
        t[1] -= lwh[0] / 2.0
        t.extend([lwh[0], lwh[0]])
        self.ani_ball.set_xywh(t)
        self.ani_ball.update()
        if self.touch == 3:
            self.ani_touch.set_xywh(t)
            self.ani_touch.play()
            self.ani_touch.update()
        elif self.touch != 1:
            self.ani_touch.update()
        #update the position of the boom
        t = self.translate(self.xyz)
        t[0] -= self.boom_size / 2.0
        t[1] -= self.boom_size / 2.0
        t.extend([self.boom_size, self.boom_size])
        self.boom_effect.set_pos(t)
        if self.goal:
            self.boom_effect.update()
        #update the position of the arrow
        if self.owner:
            lwh = mybasesprite.MyBaseSprite.get_lwh(self.owner)
            t = self.translate([self.owner.xyz[0], self.owner.xyz[1], self.xyz[2] + 90])
            t[0] -= lwh[0] / 2.0
            t[1] -= lwh[0] / 2.0
            t.extend([lwh[0], lwh[0]])
            self.ani_arrow.set_xywh(t)
            self.ani_arrow2.set_xywh(t)
            self.ani_arrow.update()
            self.ani_arrow2.update()

    def render(self):
        self.ani_shadow.render()
        if self.goal:
            self.boom_effect.render()
        else:
            self.ani_ball.render()
        if self.touch != 1:
            self.ani_touch.render()
            self.touch -= 1
        if self.owner:
            if self.owner.team_id == 10: self.ani_arrow.render()
            else: self.ani_arrow2.render()

    def crash(self, obj):
        #if the ball is under dribblingled, it will not hit anything
        if self.internal_status != "free" and self.internal_status != "stop":
            return
        #someone who is active will pick the ball
        elif obj.get_type() == ObjType.PlayerSprite and obj.status == ObjStatus.Active and obj.can_pick_ball():
            if self.can_be_caught or obj is self.tar_player or self.tar_player == None:
                if self.tar_team and self.tar_team != obj.team_id:
                    return
                else:
                    self.tar_team = None
                self.internal_status = "dribbling"
                self.is_passed = False
                self.is_shot = False
                self.owner = obj
                self.xyz = copy.copy(obj.xyz)
                self.speed[2] = self.dribble
                self.goal = False
                self.tar_player = None
                self.can_be_caught = True
        elif obj.get_type() == ObjType.BasketSprite:
            #goal
            if self.goal:
                self.is_rebound = False
                self.goal_basket = obj.xyz
                self.tar_team = obj.teamid + 9
                if self.speed[2] < 0:
                    if not self.__is_dunk:
                        self.get_scene().add_sound(mybasesprite.ObjSound.Slam1,0)
                    else:
                        self.get_scene().add_sound(mybasesprite.ObjSound.Slam2,0)
                        ##���� for Jumping
                        item = 'dunk' + str(self.__dunk_play)
                        self.get_scene().play_animation(item)
                    self.__is_dunk = False
                    tmp = self.result_goal[random.randint(0,len(self.result_goal) - 1)] + self.comment_goal[random.randint(0,len(self.comment_goal) - 1)] %(self.shooter)
                    if random.random() < 0.8:
                        self.get_scene().speak(tmp)
                    self.speed[0] *= 0.4
                    self.speed[1] *= 0.4
                    self.speed[2] *= 0.4
                    self.have_goal_defend = True
                    self.have_goal_attack = True
                    self.goal = False
                    ##���� for Jumping
                    self.get_scene().add_sound(mybasesprite.ObjSound.Dunk1 + self.__dunk_play, 20)
                    self.__dunk_play = (self.__dunk_play+1)%3
                    ##end
                    obj.add_score(2)
                    self.pas = True
                    bgcolour = 255, 255, 255
                    self.get_scene().screen.fill(bgcolour)
                    pygame.display.update()
                    pygame.time.delay(50)
            elif not self.pas:
                tmp = self.result_not_goal[random.randint(0,len(self.result_not_goal) - 1)] + self.comment_not_goal[random.randint(0,len(self.comment_not_goal) - 1)]
                if random.random() < 0.8:
                    self.get_scene().speak(tmp)
                self.is_rebound = True
                self.rebound(0, 0, 1, self.basket_dec)
                self.rebound(random.randint(0,1), 0, 0, self.basket_dec)
                self.rebound(0, random.randint(0,1), 0, self.basket_dec)
                self.pas = True
                self.get_scene().add_sound(mybasesprite.ObjSound.Damm,0)

    def stop_move(self):
        for i in range(0, 2):
            self.xyz[i] = self.xyz[i] + self.speed[i] * self.frame_time
            self.speed[i] = self.speed[i] * self.friction
        if math.sqrt(self.speed[0] * self.speed[0] + self.speed[1] * self.speed[1]) < 2:
            self.speed[0] = 0
            self.speed[1] = 0
        if self.xyz[0] > self.ground[0] - self.__half_l:
            self.xyz[0] = self.ground[0] - self.__half_l
            self.rebound(1, 0, 0, self.dec)
        elif self.xyz[0] < self.__half_l:
            self.xyz[0] = self.__half_l
            self.rebound(1, 0, 0, self.dec)
        if self.xyz[1] > self.ground[1] - self.__half_w:
            self.xyz[1] = self.ground[1] - self.__half_w
            self.rebound(0, 1, 0, self.dec)
        elif self.xyz[1] < self.__half_w:
            self.xyz[1] = self.__half_w
            self.rebound(0, 1, 0, self.dec)


    def free_move(self):
        oldz = self.xyz[2]
        oldsz = self.speed[2]
        for i in range(0, 3):
            self.xyz[i] = self.xyz[i] + self.speed[i] * self.frame_time
            self.speed[i] = self.speed[i] + self.acceleration[i] * self.frame_time
        dz = (self.speed[2] * self.speed[2] - oldsz * oldsz) / 2.0 / self.acceleration[2]
        self.xyz[2] = oldz + dz
        #change the speed direction
        if self.xyz[2] < self.__half_h:#self.ground[0] or self.pos[0] <= 0:
            self.is_rebound = False
            self.is_passed = False
            self.is_shot = False
            self.speed[2] = -math.sqrt(2 * -self.acceleration[2] * (oldz - self.__half_h)+ oldsz * oldsz)
            self.xyz[2] = self.__half_h
            self.rebound(0, 0, 1, self.dec)
            if self.speed[2] <= 5:
                self.can_be_caught = True
                self.internal_status = "stop"
            else:
                self.get_scene().add_sound(mybasesprite.ObjSound.Smack,0)
        elif self.xyz[0] > self.ground[0] - self.__half_l:
            self.xyz[0] = self.ground[0] - self.__half_l
            self.rebound(1, 0, 0, self.dec)
            self.touch = 3
        elif self.xyz[0] <  self.__half_l:
            self.xyz[0] = self.__half_l
            self.rebound(1, 0, 0, self.dec)
            self.touch = 3
        elif self.xyz[1] > self.ground[1] - self.__half_w:
            self.xyz[1] = self.ground[1] - self.__half_w
            self.rebound(0, 1, 0, self.dec)
            self.touch = 3
        elif self.xyz[1] < self.__half_w:
            self.xyz[1] = self.__half_w
            self.rebound(0, 1, 0, self.dec)
            self.touch = 3

    def con_move(self):
        self.is_rebound = False
        oldz = self.xyz[2]
        oldsz = self.speed[2]
        half_l = self.owner.get_lwh()[0] / 2.0
        half_w = self.owner.get_lwh()[1] / 2.0
        half_h = self.owner.get_lwh()[2] / 2.0
        owner_orient = self.owner.get_face_orientation()
        if owner_orient[0] == 0:
            owner_orient[0] = -1 * owner_orient[1]
            owner_orient[1] = 0
        else:
            owner_orient[1] = owner_orient[0]
            owner_orient[0] = 0
        ball_x = self.owner.xyz[0] + owner_orient[0] * half_l * 2 / 3.0 + 8 * owner_orient[1]
        ball_y = self.owner.xyz[1] + owner_orient[1] * half_w * 2 / 3.0 - 1 * owner_orient[0]
        ball_z = self.owner.xyz[2] - self.__half_h + 3
        self.xyz[0:2] = [ball_x,ball_y]
        self.speed[2] = self.speed[2] + self.acceleration[2] * self.frame_time
        dz = (self.speed[2] * self.speed[2] - oldsz * oldsz) / 2 / self.acceleration[2]
        self.xyz[2] = oldz + dz
        if self.xyz[2] < self.__half_h:
            self.speed[2] = math.sqrt(2 * -self.acceleration[2] * oldz + oldsz * oldsz)
            self.xyz[2] = self.__half_h
            self.__con_move_sound = (self.__con_move_sound+1)%1
            if self.__con_move_sound==0:
                self.get_scene().add_sound(mybasesprite.ObjSound.Smack, 0, [-1])
        elif self.xyz[2] > ball_z:
            self.xyz[2] = ball_z
            self.speed[2] = self.dribble
        else:
            self.speed[2] = self.speed[2] + self.acceleration[2] * self.frame_time

    def rebound(self, x, y, z, dec):
        self.speed[y + z * 2] = - self.speed[y + z * 2] * (1 - dec / 100.0)

    def get_lwh(self):
        lwh = mybasesprite.MyBaseSprite.get_lwh(self)
        return [lwh[0] * 2.0,lwh[1] * 2.0,lwh[2] * 2.0]


    def set_xyz(self,xyz):
        self.xyz = xyz
        self.internal_status = "control"


if __name__ == "__main__":
    pygame.init()
    pygame.display.init()
    bgimg = pygame.image.load("/data/github/linwei/basketball/images/background4.png")
    screen = pygame.display.set_mode((bgimg.get_rect().width, bgimg.get_rect().height))
    scene = scenesprite.Scene(None)
    scene.screen = screen
    ani_ball = animationsprite.AnimationSprite(scene, '/data/github/linwei/basketball/images/', 'ball.ini')
    ani_touch = animationsprite.AnimationSprite(scene, '/data/github/linwei/basketball/images/', 'touch.ini')
    ani_shadow = animationsprite.AnimationSprite(scene, '/data/github/linwei/basketball/images/', 'shadow.ini')
    ball = BallSprite([ani_ball, ani_touch, ani_shadow], scene, [52,878.0*15.0/56.0,180.0], [10, 10, 10])
#    ball.internal_status = "dribbling"
#    ball.internal_status = "free"
#    ball.acceleration[2] = 0.0001

    ball.owner = mybasesprite.MyBaseSprite(None, [200, 200, 200], [10, 10, 10])
    ball.speed[2] = ball.dribble
    ball.set_speed([30, -20, 30], 0)
    while 1:
        ball.update()
        screen.blit(bgimg, (0, 0))
        ball.render()
        pygame.display.flip()
